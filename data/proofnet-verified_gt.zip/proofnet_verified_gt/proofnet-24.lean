import Mathlib

open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators ENNReal ComplexConjugate



/-Informal Statement

Suppose $U$ is a subspace of $V$. Prove that $U^{\perp}=\{0\}$ if and only if $U=V$
-/

/-Informal Proof

$V=U \bigoplus U^{\perp}$, therefore $U^\perp = \{0\}$ iff $U=V$.
-/

theorem Axler_exercise_6_16 {K V : Type*} [RCLike K] [NormedAddCommGroup V] [InnerProductSpace K V]
  {U : Submodule K V} :
  U.orthogonal = ⊥  ↔ U = ⊤ := by
  sorry

-- NOTE: The naive statement `Uᗮ = ⊥ ↔ U = ⊤` is not valid without additional
-- hypotheses (e.g. closedness of `U`).  See `Axler_exercise_6_16_neg` for an explicit
-- counterexample and `Axler_exercise_6_16_corrected` for a corrected formulation.

/-
Step-by-step diagnosis:
- Step A: The claim as stated fails because `Uᗮ = ⊥` only forces the *closure* of `U` to be all of
  `V`. Without a closedness (or orthogonal projection) assumption, a dense proper subspace produces
  a counterexample.
- Step B: We will show this explicitly inside `ℓ²(ℕ, ℝ)` by taking the span of standard basis
  vectors (finite-support sequences). This subspace is dense, its orthogonal complement is `⊥`,
  yet it is strictly smaller than `ℓ²(ℕ, ℝ)`.
--/

theorem Axler_exercise_6_16_neg : ¬ (∀ (K V : Type*) [RCLike K] [NormedAddCommGroup V] [InnerProductSpace K V]
  (U : Submodule K V), U.orthogonal = ⊥ ↔ U = ⊤) := by
  sorry


/-
The original statement is correct, but as a mathematical claim it’s false in general for inner
product spaces. The informal proof line “V = U ⊕ Uᗮ” only holds when U is closed and the ambient
space is complete (or when V is finite-dimensional, in which case every subspace is closed).
Without these hypotheses one can have a proper dense subspace U with Uᗮ = {0} but U ≠ V.

Fix: require both `(hU : IsClosed (U : Set V))` and `[CompleteSpace V]`, which is weaker than assuming `[FiniteDimensional K V]` or `[U.HasOrthogonalProjection]`.
--/
theorem Axler_exercise_6_16_corrected {K V : Type*} [RCLike K] [NormedAddCommGroup V]
  [InnerProductSpace K V] [CompleteSpace V] {U : Submodule K V}
  (hU : IsClosed (U : Set V)) :
  U.orthogonal = ⊥ ↔ U = ⊤ := by
  classical
  constructor
  · -- Step 1: Assume that the orthogonal complement is trivial and deduce that `U` equals `⊤`.
    intro hOrth
    -- Step 1.1: A closed submodule has dense span precisely when its orthogonal complement vanishes.
    have hClosureTop : U.topologicalClosure = (⊤ : Submodule K V) :=
      (Submodule.topologicalClosure_eq_top_iff).2 hOrth
    -- Step 1.2: Invoke the closedness hypothesis and eliminate the topological closure.
    have hClosedEq : U.topologicalClosure = U := hU.submodule_topologicalClosure_eq
    simpa [hClosedEq] using hClosureTop
  · -- Step 2: Conversely, if `U = ⊤`, its orthogonal complement is clearly `⊥`.
    intro hTop
    simp [hTop]
