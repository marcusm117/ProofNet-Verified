import Mathlib

open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators



/-Informal Statement

Let $A$ be a nonempty set of real numbers which is bounded below. Let $-A$ be the set of all numbers $-x$, where $x \in A$. Prove that $\inf A=-\sup (-A)$.
-/

/-Informal Proof

We need to prove that $-\sup (-A)$ is the greatest lower bound of $A$. For brevity, let $\alpha=-\sup (-A)$. We need to show that $\alpha \leq x$ for all $x \in A$ and $\alpha \geq \beta$ if $\beta$ is any lower bound of $A$.

Suppose $x \in A$. Then, $-x \in-A$, and, hence $-x \leq \sup (-A)$. It follows that $x \geq-\sup (-A)$, i.e., $\alpha \leq x$. Thus $\alpha$ is a lower bound of $A$.

Now let $\beta$ be any lower bound of $A$. This means $\beta \leq x$ for all $x$ in $A$. Hence $-x \leq-\beta$ for all $x \in A$, which says $y \leq-\beta$ for all $y \in-A$. This means $-\beta$ is an upper bound of $-A$. Hence $-\beta \geq \sup (-A)$ by definition of sup, i.e., $\beta \leq-\sup (-A)$, and so $-\sup (-A)$ is the greatest lower bound of $A$.
-/

theorem Rudin_exercise_1_5 (A minus_A : Set ℝ) (hA : A.Nonempty)
  (hA_bdd_below : BddBelow A) (hminus_A : minus_A = {x | -x ∈ A}) :
  sInf A = - sSup minus_A := by
  -- Step 1: Switch to classical logic so that we can choose explicit witnesses from the hypotheses.
  classical
  -- Step 2: Store reusable copies of the nonemptiness and bounded-below hypotheses.
  have hA_nonempty : A.Nonempty := hA
  have hA_bdd_below_copy : BddBelow A := hA_bdd_below
  -- Step 3: Extract an element `a ∈ A` to witness that `minus_A` is nonempty.
  obtain ⟨a, ha⟩ := hA
  -- Step 3.1: Use `a` to produce an element of `minus_A`, proving its nonemptiness.
  have hminus_nonempty : minus_A.Nonempty := by
    refine ⟨-a, ?_⟩
    simpa [hminus_A] using ha
  -- Step 4: Transfer the lower bound on `A` to an upper bound on `minus_A` via negation.
  obtain ⟨m, hm⟩ := hA_bdd_below
  -- Step 4.1: Negating the lower-bound witness gives an upper-bound witness for `minus_A`.
  have hminus_bddAbove : BddAbove minus_A := by
    refine ⟨-m, ?_⟩
    intro y hy
    -- Step 4.1.1: Translate membership in `minus_A` to membership of the negation in `A`.
    have hyA : -y ∈ A := by
      simpa [hminus_A] using hy
    -- Step 4.1.2: Apply the lower-bound inequality and negate it to bound `y` from above.
    have hm_le : m ≤ -y := hm hyA
    simpa [neg_neg] using (neg_le_neg hm_le)
  -- Step 5: Show that `-sSup minus_A` is a lower bound for every element of `A`.
  have hLowerBound : ∀ x ∈ A, -sSup minus_A ≤ x := by
    intro x hx
    -- Step 5.1: Convert `x ∈ A` into a statement about `-x ∈ minus_A`.
    have hx_minus : -x ∈ minus_A := by
      simpa [hminus_A] using hx
    -- Step 5.2: Use the definition of `sSup` as a least upper bound, then negate.
    have hx_le : -x ≤ sSup minus_A := le_csSup hminus_bddAbove hx_minus
    simpa [neg_neg] using (neg_le_neg hx_le)
  -- Step 6: Invoke the greatest-lower-bound property of `sInf` with the previous step.
  have h_le_right : -sSup minus_A ≤ sInf A := le_csInf hA_nonempty hLowerBound
  -- Step 7: Prove that every element of `minus_A` is bounded above by `-sInf A`.
  have hUpperBound : ∀ y ∈ minus_A, y ≤ -sInf A := by
    intro y hy
    -- Step 7.1: Relate `y ∈ minus_A` back to `-y ∈ A`.
    have hyA : -y ∈ A := by
      simpa [hminus_A] using hy
    -- Step 7.2: Apply the defining inequality for `sInf` and negate the result.
    have hInf_le : sInf A ≤ -y := csInf_le hA_bdd_below_copy hyA
    simpa [neg_neg] using (neg_le_neg hInf_le)
  -- Step 8: Apply the least-upper-bound characterization of `sSup` to the previous bound.
  have h_sup_le : sSup minus_A ≤ -sInf A := csSup_le hminus_nonempty hUpperBound
  -- Step 9: Negate the inequality from Step 8 to obtain `sInf A ≤ -sSup minus_A`.
  have h_le_left : sInf A ≤ -sSup minus_A := by
    simpa [neg_neg] using (neg_le_neg h_sup_le)
  -- Step 10: Combine the two opposite inequalities to reach the desired equality.
  exact le_antisymm h_le_left h_le_right
