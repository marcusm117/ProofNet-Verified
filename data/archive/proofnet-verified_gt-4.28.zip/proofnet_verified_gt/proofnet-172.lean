import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Suppose $f^{\prime}(x)>0$ in $(a, b)$. Prove that $f$ is strictly increasing in $(a, b)$, and let $g$ be its inverse function. Prove that $g$ is differentiable, and that $g^{\prime}(f(x))=\frac{1}{f^{\prime}(x)} \quad(a<x<b)$.
-/

/-Informal Proof

For any $c, d$ with $a<c<d<b$ there exists a point $p \in(c, d)$ such that $f(d)-f(c)=f^{\prime}(p)(d-c)>0$. Hence $f(c)<f(d)$

We know from Theorem $4.17$ that the inverse function $g$ is continuous. (Its restriction to each closed subinterval $[c, d]$ is continuous, and that is sufficient.) Now observe that if $f(x)=y$ and $f(x+h)=y+k$, we have
$$
\frac{g(y+k)-g(y)}{k}-\frac{1}{f^{\prime}(x)}=\frac{1}{\frac{f(x+h)-f(x)}{h}}-\frac{1}{f^{\prime}(x)}
$$
Since we know $\lim \frac{1}{\varphi(t)}=\frac{1}{\lim \varphi(t)}$ provided $\lim \varphi(t) \neq 0$, it follows that for any $\varepsilon>0$ there exists $\eta>0$ such that
$$
\left|\frac{1}{\frac{f(x+h)-f(x)}{h}}-\frac{1}{f^{\prime}(x)}\right|<\varepsilon
$$
if $0<|h|<\eta$. Since $h=g(y+k)-g(y)$, there exists $\delta>0$ such that $0<|h|<\eta$ if $0<|k|<\delta$. The proof is now complete.
-/


theorem Rudin_exercise_5_2 {a b : ℝ}
  {f g : ℝ → ℝ} (hf : ∀ x ∈ Set.Ioo a b, deriv f x > 0)
  (hg : g = f⁻¹)
  (hg_diff : DifferentiableOn ℝ g (Set.Ioo a b)) :
  DifferentiableOn ℝ g (Set.Ioo a b) ∧
  ∀ x ∈ Set.Ioo a b, deriv g x = 1 / deriv f x := by
  sorry

/-! ## Refutation
The original statement `Rudin_exercise_5_2` is false: `Rudin_exercise_5_2_neg` proves the negation of its elaborated type. -/
/-!
### Why the formalized statement is false

The hypothesis `hg : g = f⁻¹` does **not** say that `g` is the compositional
inverse of `f`.  For `f : ℝ → ℝ`, the notation `f⁻¹` elaborates through
`Pi.instInv` to the *pointwise reciprocal* `fun x => (f x)⁻¹`.  So the
conclusion `deriv g x = 1 / deriv f x` asserts the (false) claim that the
derivative of the pointwise reciprocal of `f` equals the reciprocal of the
derivative of `f`.

Counterexample: `a = 0`, `b = 1`, `f = fun x => x`, `g = fun x => x⁻¹`.
Then `deriv f = 1 > 0` on `Ioo 0 1`, `g` is differentiable there (no zero in
range), but at `x = 1/2` we get `deriv g x = -(x^2)⁻¹ = -4 ≠ 1 = 1 / deriv f x`.
-/

/-- Step A: the derivative of the identity function is `1`, in particular positive. -/
private theorem pn172_hf : ∀ x ∈ Set.Ioo (0:ℝ) 1, deriv (fun x : ℝ => x) x > 0 := by
  intro x _
  simp

/-- Step B: `fun x => x⁻¹` really *is* `(fun x : ℝ => x)⁻¹` — the `Inv` instance on
    `ℝ → ℝ` is pointwise, so this holds by `rfl`. -/
private theorem pn172_hgdef : (fun x : ℝ => x⁻¹) = (fun x : ℝ => x)⁻¹ := rfl

/-- Step C: the reciprocal function is differentiable on `Ioo 0 1`, since `x ≠ 0` there. -/
private theorem pn172_hgd :
    DifferentiableOn ℝ (fun x : ℝ => x⁻¹) (Set.Ioo (0:ℝ) 1) := by
  intro x hx
  exact (differentiableAt_inv (ne_of_gt hx.1)).differentiableWithinAt

theorem Rudin_exercise_5_2_neg : ¬ (type_of% @Rudin_exercise_5_2) := by
  -- Step 1: assume the statement holds for all `a b f g`.
  intro H
  -- Step 2: specialise to `a = 0`, `b = 1`, `f = id`, `g = fun x => x⁻¹`,
  -- discharging the three hypotheses with Steps A, B, C, and evaluate the
  -- conclusion at the point `x = 1/2 ∈ Ioo 0 1`.
  have h := (H pn172_hf pn172_hgdef pn172_hgd).2 (1/2) (by constructor <;> norm_num)
  -- Step 3: `deriv (fun x => x⁻¹) (1/2) = -((1/2)^2)⁻¹ = -4`, while
  -- `1 / deriv (fun x => x) (1/2) = 1 / 1 = 1`.  Contradiction.
  rw [deriv_inv] at h
  norm_num at h

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

/-!
Corrected statement:
If `deriv f x > 0` on `(a, b)` and `g` is the functional inverse of `f` (i.e., `g (f x) = x`
for all `x ∈ (a, b)`), then `f` is strictly increasing on `(a, b)`, `g` is differentiable on
`f '' (a, b)`, and `deriv g (f x) = 1 / deriv f x`.
-/

theorem Rudin_exercise_5_2_corrected :
    ∀ (a b : ℝ) (f g : ℝ → ℝ),
      (∀ x ∈ Set.Ioo a b, deriv f x > 0) →
      (∀ x ∈ Set.Ioo a b, g (f x) = x) →
      StrictMonoOn f (Set.Ioo a b) ∧
        DifferentiableOn ℝ g (f '' Set.Ioo a b) ∧
          ∀ x ∈ Set.Ioo a b, deriv g (f x) = 1 / deriv f x := by
  -- Step 1: Introduce the data: interval endpoints, functions, and hypotheses.
  intro a b f g hf hleft
  -- Step 2: Establish differentiability of f on (a, b).
  -- Step 2.1: Pointwise differentiability from nonzero derivative.
  have hf_diff_at : ∀ x ∈ Set.Ioo a b, DifferentiableAt ℝ f x := fun x hx =>
    differentiableAt_of_deriv_ne_zero (ne_of_gt (hf x hx))
  -- Step 2.2: Upgrade to DifferentiableOn.
  have hf_diff_on : DifferentiableOn ℝ f (Set.Ioo a b) :=
    fun x hx => (hf_diff_at x hx).differentiableWithinAt
  -- Step 2.3: Differentiability implies continuity on (a, b).
  have hf_cont : ContinuousOn f (Set.Ioo a b) := hf_diff_on.continuousOn
  -- Step 3: Prove f is strictly monotone on (a, b) via the mean value theorem.
  -- Since (a, b) is convex, f is continuous on it, and deriv f > 0 on its interior (which is
  -- itself since (a, b) is open), strictMonoOn_of_deriv_pos applies.
  have hmono : StrictMonoOn f (Set.Ioo a b) :=
    strictMonoOn_of_deriv_pos (convex_Ioo a b) hf_cont (by simp only [interior_Ioo]; exact hf)
  -- Step 4: Show f '' (a, b) is open.
  -- Strategy: for any f(x) in the image, find an open interval (f(c), f(d)) around it that is
  -- contained in the image, using the intermediate value theorem on a sub-interval [c, d].
  have himage_open : IsOpen (f '' Set.Ioo a b) := by
    rw [isOpen_iff_mem_nhds]
    rintro y ⟨x, hx, rfl⟩
    -- Step 4.1: Pick c and d with a < c < x < d < b using density of ℝ.
    obtain ⟨c, hca, hcx⟩ := exists_between hx.1
    obtain ⟨d, hxd, hdb⟩ := exists_between hx.2
    -- Step 4.2: Record that c and d lie in (a, b).
    have hc_mem : c ∈ Set.Ioo a b := ⟨hca, lt_trans hcx (lt_trans hxd hdb)⟩
    have hd_mem : d ∈ Set.Ioo a b := ⟨lt_trans hca (lt_trans hcx hxd), hdb⟩
    -- Step 4.3: Show (f(c), f(d)) is a neighborhood of f(x) contained in f '' (a, b).
    -- f(c) < f(x) < f(d) by strict monotonicity, so f(x) ∈ (f(c), f(d)).
    refine mem_nhds_iff.mpr ⟨Set.Ioo (f c) (f d), ?_, isOpen_Ioo,
      ⟨hmono hc_mem hx hcx, hmono hx hd_mem hxd⟩⟩
    -- Step 4.4: Show (f(c), f(d)) ⊆ f '' (a, b) via the intermediate value theorem.
    -- IVT gives (f(c), f(d)) ⊆ f '' (c, d), and (c, d) ⊆ (a, b) gives the inclusion of images.
    calc Set.Ioo (f c) (f d)
        ⊆ f '' Set.Ioo c d := intermediate_value_Ioo (lt_trans hcx hxd).le
            (hf_cont.mono (Set.Icc_subset_Ioo hc_mem.1 hd_mem.2))
      _ ⊆ f '' Set.Ioo a b := Set.image_mono (Set.Ioo_subset_Ioo hc_mem.1.le hd_mem.2.le)
  -- Step 5: Derive the local right-inverse property: f(g(y)) = y for y near f(x).
  -- Since f '' (a, b) is open and contains f(x), it is a neighborhood of f(x).
  -- For any y = f(z) with z ∈ (a, b), we have f(g(y)) = f(g(f(z))) = f(z) = y.
  have hlocal : ∀ x ∈ Set.Ioo a b, ∀ᶠ y in 𝓝 (f x), f (g y) = y := fun x hx =>
    Filter.eventually_of_mem (himage_open.mem_nhds ⟨x, hx, rfl⟩)
      (fun y ⟨z, hz, hfz⟩ => by rw [← hfz, hleft z hz])
  -- Step 6: Show g is strictly monotone on f '' (a, b).
  -- If f(p) < f(q) for p, q ∈ (a, b), then p < q by strict mono of f,
  -- so g(f(p)) = p < q = g(f(q)).
  have mono_g : StrictMonoOn g (f '' Set.Ioo a b) := by
    rintro u ⟨p, hp, rfl⟩ v ⟨q, hq, rfl⟩ huv
    rw [hleft p hp, hleft q hq]
    exact (hmono.lt_iff_lt hp hq).mp huv
  -- Step 7: Prove g is continuous at each f(x) for x ∈ (a, b).
  -- We use: a strictly monotone function is continuous at a point if it maps some neighborhood
  -- to a neighborhood (StrictMonoOn.continuousAt_of_image_mem_nhds).
  -- Step 7.1: The set f '' (a, b) is a neighborhood of f(x) (since it is open, Step 4).
  -- Step 7.2: The image g '' (f '' (a, b)) ⊇ (a, b) (since g(f(z)) = z for z ∈ (a, b)),
  --   and (a, b) is a neighborhood of x = g(f(x)). So g maps nhds to nhds.
  have hg_cont_at : ∀ x ∈ Set.Ioo a b, ContinuousAt g (f x) := by
    intro x hx
    refine mono_g.continuousAt_of_image_mem_nhds
      (himage_open.mem_nhds ⟨x, hx, rfl⟩) ?_
    rw [hleft x hx]
    exact Filter.mem_of_superset (isOpen_Ioo.mem_nhds hx)
      (fun z hz => ⟨f z, ⟨z, hz, rfl⟩, hleft z hz⟩)
  -- Step 8: Compute the derivative of g at f(x) using the inverse function theorem.
  -- HasDerivAt.of_local_left_inverse requires:
  --   (a) ContinuousAt g (f x)           — established in Step 7
  --   (b) HasDerivAt f (deriv f x) x     — from differentiability (Step 2), noting g(f(x)) = x
  --   (c) deriv f x ≠ 0                  — from deriv f x > 0
  --   (d) ∀ᶠ y in 𝓝 (f x), f (g y) = y — the local right-inverse (Step 5)
  -- Conclusion: HasDerivAt g (deriv f x)⁻¹ (f x).
  have hg_hasDeriv : ∀ x ∈ Set.Ioo a b, HasDerivAt g ((deriv f x)⁻¹) (f x) := by
    intro x hx
    exact HasDerivAt.of_local_left_inverse (hg_cont_at x hx)
      (by simpa [hleft x hx] using (hf_diff_at x hx).hasDerivAt)
      (ne_of_gt (hf x hx)) (hlocal x hx)
  -- Step 9: Assemble the three conclusions.
  refine ⟨hmono, fun y hy => ?_, fun x hx => ?_⟩
  -- Step 9.1: g is differentiable on f '' (a, b) — immediate from HasDerivAt (Step 8).
  · obtain ⟨x, hx, rfl⟩ := hy
    exact (hg_hasDeriv x hx).differentiableAt.differentiableWithinAt
  -- Step 9.2: deriv g (f x) = 1 / deriv f x — read off from HasDerivAt and rewrite ⁻¹ as 1/.
  simpa [one_div] using (hg_hasDeriv x hx).deriv
