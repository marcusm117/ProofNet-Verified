import Mathlib


open Fintype Set Real Ideal Polynomial
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $T$ be the group of $2\times 2$ matrices $A$ with entries in the field $\mathbb{Z}_2$ such that $\det A$ is not equal to 0. Prove that $T$ is isomorphic to $S_3$, the symmetric group of degree 3.
-/

/-Informal Proof

The order of $T$ is $2^4-2^3-2^2+2=6$; we now find those six matrices:
$$
\begin{array}{ll}
A_1=\left(\begin{array}{ll}
1 & 0 \\
0 & 1
\end{array}\right), & A_2=\left(\begin{array}{ll}
0 & 1 \\
1 & 0
\end{array}\right) \\
A_3=\left(\begin{array}{ll}
1 & 0 \\
1 & 1
\end{array}\right), & A_4=\left(\begin{array}{ll}
1 & 1 \\
0 & 1
\end{array}\right) \\
A_5=\left(\begin{array}{ll}
0 & 1 \\
1 & 1
\end{array}\right), & A_6=\left(\begin{array}{ll}
1 & 1 \\
1 & 0
\end{array}\right)
\end{array}
$$
with orders $1,2,2,2,3,3$ respectively.
Note that $S_3$ is composed of elements
$$
\text{ id, (1 2), (1 3), (2 3), (1 2 3), (1 3 2)} 
$$
with orders 1, 2, 2, 2, 3, 3 respectively. Also note that, by Problem 17 of generate $S_3$. We also have that $\left(\begin{array}{llll}1 & 3 & 2\end{array}\right)=\left(\begin{array}{llll}1 & 2 & 3\end{array}\right)\left(\begin{array}{lll}1 & 2 & 3\end{array}\right)$, that $\left(\begin{array}{lll}1 & 3\end{array}\right)=\left(\begin{array}{lll}1 & 2 & 3\end{array}\right)\left(\begin{array}{ll}1 & 2\end{array}\right)$, $\left(\begin{array}{ll}1 & 2\end{array}\right)\left(\begin{array}{lll}1 & 2 & 3\end{array}\right)=\left(\begin{array}{ll}2 & 3\end{array}\right)$ and $\left(\begin{array}{lll}1 & 2\end{array}\right)\left(\begin{array}{ll}1 & 2\end{array}\right)=\mathrm{id}$

Now we can check that $\tau\left(A_2\right)=\left(\begin{array}{ll}1 & 2\end{array}\right), \tau\left(A_5\right)=\left(\begin{array}{lll}1 & 2 & 3\end{array}\right)$ induces an isomorphism. We compute
$$
\begin{aligned}
& \tau\left(A_1\right)=\tau\left(A_2 A_2\right)=\tau\left(A_2\right) \tau\left(A_2\right)=\mathrm{id} \\
& \tau\left(A_3\right)=\tau\left(A_5 A_2\right)=\tau\left(A_5\right) \tau\left(A_2\right)=\left(\begin{array}{llll}
1 & 2 & 3
\end{array}\right)\left(\begin{array}{lll}
1 & 2
\end{array}\right)=\left(\begin{array}{ll}
1 & 3
\end{array}\right) \\
& \tau\left(A_4\right)=\tau\left(A_2 A_5\right)=\tau\left(A_2\right) \tau\left(A_5\right)=\left(\begin{array}{lll}
1 & 2
\end{array}\right)\left(\begin{array}{lll}
1 & 2 & 3
\end{array}\right)=\left(\begin{array}{ll}
2 & 3
\end{array}\right) \\
& \tau\left(A_6\right)=\tau\left(A_5 A_5\right)=\tau\left(A_5\right) \tau\left(A_5\right)=\left(\begin{array}{lll}
1 & 3 & 2
\end{array}\right)
\end{aligned}
$$
Thus we see that $\tau$ extendeds to an isomorphism, since $A_2$ and $A_5$ generate $T$, so that $\tau\left(A_i A_j\right)=\tau\left(A_i\right) \tau\left(A_j\right)$ follows from writing $A_i$ and $A_j$ in terms of $A_2$ and $A_5$ and using the equlities and relations shown above.
-/

/- ### Strategy

`GL 2 (ZMod 2)` acts (simply transitively on bases, hence) faithfully on the three *nonzero*
vectors of `(ZMod 2)²`, and every permutation of those three vectors is realised by a matrix.
We build the isomorphism in the direction `S₃ → GL 2 (ZMod 2)` explicitly:

* enumerate the three nonzero vectors as `H4134_V 0 = (1,0)`, `H4134_V 1 = (0,1)`,
  `H4134_V 2 = (1,1)`;
* to a permutation `σ` of `Fin 3` associate the matrix `H4134_M σ` whose `j`-th column
  (`j = 0, 1`) is `H4134_V (σ j)`.  Since the first two vectors form the standard basis, this
  matrix maps `H4134_V m` to `H4134_V (σ m)` for *all* three `m` — for `m = 2` this uses the
  characteristic-two identity `H4134_V a + H4134_V b = H4134_V c` for `{a,b,c} = {0,1,2}`.
* multiplicativity is then immediate, injectivity follows from injectivity of `H4134_V`,
  and surjectivity from a cardinality count (`|S₃| = 6 = |GL 2 (ZMod 2)|`).
-/

/-- Step 1: the three nonzero vectors of `(ZMod 2)²`, indexed by `Fin 3`. -/
private def H4134_V : Fin 3 → Fin 2 → ZMod 2 := ![![1, 0], ![0, 1], ![1, 1]]

/-- Step 1.1: the three vectors are pairwise distinct (a finite check). -/
private lemma H4134_V_injective : Function.Injective H4134_V := by decide

/-- Step 1.2: in characteristic two, the sum of two of the three nonzero vectors is the third. -/
private lemma H4134_V_add :
    ∀ a b c : Fin 3, a ≠ b → a ≠ c → b ≠ c → H4134_V a + H4134_V b = H4134_V c := by decide

/-- Step 1.3: consequently, for any permutation `ρ` of `Fin 3`,
`V (ρ 0) + V (ρ 1) = V (ρ 2)`. -/
private lemma H4134_col_add (ρ : Equiv.Perm (Fin 3)) :
    H4134_V (ρ 0) + H4134_V (ρ 1) = H4134_V (ρ 2) :=
  H4134_V_add _ _ _
    (fun h => absurd (ρ.injective h) (by decide))
    (fun h => absurd (ρ.injective h) (by decide))
    (fun h => absurd (ρ.injective h) (by decide))

/-- Step 2: the matrix attached to a permutation `σ`: its `j`-th column is `V (σ j)`
(here `j : Fin 2` is viewed inside `Fin 3` via `Fin.castSucc`). -/
private def H4134_M (σ : Equiv.Perm (Fin 3)) : Matrix (Fin 2) (Fin 2) (ZMod 2) :=
  Matrix.of fun i j => H4134_V (σ (Fin.castSucc j)) i

/-- Step 2.1: `H4134_M σ` sends the vector `V m` to `V (σ m)`, for every `m : Fin 3`.
Written out as an explicit sum, this is exactly the `i`-th coordinate of `(M σ) *ᵥ (V m)`. -/
private lemma H4134_key (σ : Equiv.Perm (Fin 3)) (m : Fin 3) (i : Fin 2) :
    ∑ j : Fin 2, H4134_V (σ (Fin.castSucc j)) i * H4134_V m j = H4134_V (σ m) i := by
  -- Step 2.1.1: expand the two-term sum and normalise the indices `castSucc 0 = 0`,
  -- `castSucc 1 = 1`.
  rw [Fin.sum_univ_two]
  have h0 : (Fin.castSucc (0 : Fin 2)) = (0 : Fin 3) := by decide
  have h1 : (Fin.castSucc (1 : Fin 2)) = (1 : Fin 3) := by decide
  rw [h0, h1]
  -- Step 2.1.2: case on `m`.  For `m = 0, 1` the vector `V m` is a standard basis vector
  -- and the sum collapses to a single column.
  fin_cases m
  · show H4134_V (σ 0) i * (1 : ZMod 2) + H4134_V (σ 1) i * (0 : ZMod 2) = H4134_V (σ 0) i
    ring
  · show H4134_V (σ 0) i * (0 : ZMod 2) + H4134_V (σ 1) i * (1 : ZMod 2) = H4134_V (σ 1) i
    ring
  -- Step 2.1.3: for `m = 2` we get the sum of the two columns, which is the third vector.
  · show H4134_V (σ 0) i * (1 : ZMod 2) + H4134_V (σ 1) i * (1 : ZMod 2) = H4134_V (σ 2) i
    have := congrFun (H4134_col_add σ) i
    simpa using this

/-- Step 2.2: the identity permutation gives the identity matrix. -/
private lemma H4134_M_one : H4134_M 1 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> decide

/-- Step 2.3: multiplicativity, `M σ * M τ = M (σ * τ)`.
The `(i, j)` entry of the product is the `i`-th coordinate of `(M σ) *ᵥ (V (τ j))`, which by
Step 2.1 is `V (σ (τ j)) i`, i.e. the `(i, j)` entry of `M (σ * τ)`. -/
private lemma H4134_M_mul (σ τ : Equiv.Perm (Fin 3)) :
    H4134_M σ * H4134_M τ = H4134_M (σ * τ) := by
  ext i j
  rw [Matrix.mul_apply]
  exact H4134_key σ (τ (Fin.castSucc j)) i

/-- Step 3: the resulting monoid homomorphism into `GL 2 (ZMod 2)`.
The inverse of `M σ` is `M σ⁻¹`, by Steps 2.2 and 2.3. -/
private def H4134_F : Equiv.Perm (Fin 3) →* Matrix.GeneralLinearGroup (Fin 2) (ZMod 2) where
  toFun σ :=
    { val := H4134_M σ
      inv := H4134_M σ⁻¹
      val_inv := by rw [H4134_M_mul, mul_inv_cancel, H4134_M_one]
      inv_val := by rw [H4134_M_mul, inv_mul_cancel, H4134_M_one] }
  map_one' := Units.ext H4134_M_one
  map_mul' σ τ := Units.ext (H4134_M_mul σ τ).symm

/-- Step 4: injectivity.  If `M σ = M τ` then the two matrices have the same columns, so
`V (σ x) = V (τ x)` for `x = 0, 1`; for `x = 2` use Step 1.3; then apply injectivity of `V`. -/
private lemma H4134_F_injective : Function.Injective H4134_F := by
  intro σ τ h
  -- Step 4.1: equality of the underlying matrices, entrywise.
  have hm : H4134_M σ = H4134_M τ := congrArg Units.val h
  have hcol : ∀ (j : Fin 2) (i : Fin 2),
      H4134_V (σ (Fin.castSucc j)) i = H4134_V (τ (Fin.castSucc j)) i := fun j i =>
    congrFun (congrFun hm i) j
  have h0 : H4134_V (σ 0) = H4134_V (τ 0) := by
    funext i
    have := hcol 0 i
    simpa using this
  have h1 : H4134_V (σ 1) = H4134_V (τ 1) := by
    funext i
    have := hcol 1 i
    simpa using this
  -- Step 4.2: the third column is determined by the first two.
  have h2 : H4134_V (σ 2) = H4134_V (τ 2) := by
    rw [← H4134_col_add σ, ← H4134_col_add τ, h0, h1]
  -- Step 4.3: conclude by injectivity of `V`.
  ext x
  fin_cases x
  · exact congrArg Fin.val (H4134_V_injective h0)
  · exact congrArg Fin.val (H4134_V_injective h1)
  · exact congrArg Fin.val (H4134_V_injective h2)

/-- Step 5: both groups have exactly `6` elements. -/
private lemma H4134_card_perm : Nat.card (Equiv.Perm (Fin 3)) = 6 := by
  rw [Nat.card_perm, Nat.card_eq_fintype_card, Fintype.card_fin]
  decide

private lemma H4134_card_GL :
    Nat.card (Matrix.GeneralLinearGroup (Fin 2) (ZMod 2)) = 6 := by
  -- Step 5.1: `|GL n F| = ∏ i, (q ^ n - q ^ i)`, here `(4 - 1) * (4 - 2) = 6`.
  have := Matrix.card_GL_field (𝔽 := ZMod 2) 2
  rw [this, Fin.prod_univ_two]
  simp [ZMod.card]

instance Herstein_exercise_4_1_34 : Equiv.Perm (Fin 3) ≃* Matrix.GeneralLinearGroup (Fin 2) (ZMod 2) := by
  -- Step 6: an injective homomorphism between finite groups of equal cardinality is bijective.
  refine MulEquiv.ofBijective H4134_F ?_
  refine (Nat.bijective_iff_injective_and_card H4134_F).mpr ⟨H4134_F_injective, ?_⟩
  rw [H4134_card_perm, H4134_card_GL]

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Set Real Ideal Polynomial
open scoped BigOperators

noncomputable section

open Matrix

local notation "V₂" => Fin 2 → ZMod 2
local notation "NZ₂" => { v : V₂ // v ≠ (0 : V₂) }

/-!
We prepare a detailed dictionary between the six invertible `2 × 2` matrices over `ℤ₂` and the
six permutations of three objects.  The key steps are counted and explained in the comments in each
lemma so that the formal proof mirrors the informal reasoning step by step.
-/

lemma card_nonzero_vectors : Fintype.card NZ₂ = 3 := by
  classical
  change Fintype.card { v : V₂ // v ≠ (0 : V₂) } = 3
  -- Step 1: compute the total number `4` of vectors in `(Fin 2 → ZMod 2)` via the fun-card lemma.
  have hTotal : Fintype.card V₂ = 4 := by
    simp [Fintype.card_fin, ZMod.card]
  -- Step 2: the zero vector is unique, so the corresponding subtype has cardinality `1`.
  have hZero : Fintype.card { v : V₂ // v = (0 : V₂) } = 1 := by
    simp
  -- Step 3: subtract the zero vector from the full set to get the three nonzero vectors.
  simp [hTotal, Fintype.card_subtype_compl]

@[simp] lemma card_perm_nonzero : Fintype.card (Equiv.Perm NZ₂) = 6 := by
  classical
  -- Step 1: rewrite the permutation cardinality as the factorial of `|NZ₂| = 3`.
  have hCard : Fintype.card NZ₂ = 3 := card_nonzero_vectors
  have hFact : Nat.factorial 3 = 6 := by decide
  calc
    Fintype.card (Equiv.Perm NZ₂)
        = Nat.factorial (Fintype.card NZ₂) := by simp [Fintype.card_perm]
    _ = Nat.factorial 3 := by simp [hCard]
    _ = 6 := hFact

def nzEquivFin3 : NZ₂ ≃ Fin 3 :=
  Fintype.equivFinOfCardEq card_nonzero_vectors

private def permOfLinearEquiv (e : V₂ ≃ₗ[ZMod 2] V₂) : Equiv.Perm NZ₂ :=
  -- Step 1: transport the linear equivalence to a permutation of the nonzero vectors.
  { toFun := fun v => ⟨e v, by
      -- Step 1.1: injectivity of `e` ensures nonzero vectors stay nonzero.
      simpa using (e.map_ne_zero_iff).2 v.property⟩
    , invFun := fun v => ⟨e.symm v, by
      -- Step 1.2: the inverse linear equivalence has the same preservation property.
      simpa using (e.symm.map_ne_zero_iff).2 v.property⟩
    , left_inv := by
      -- Step 1.3: restricting to the subtype keeps the standard left inverse property.
      intro v; ext i; simp
    , right_inv := by
      -- Step 1.4: similarly for the right inverse direction.
      intro v; ext i; simp }

@[simp] lemma permOfLinearEquiv_apply (e : V₂ ≃ₗ[ZMod 2] V₂) (v : NZ₂) :
    (permOfLinearEquiv e v : V₂) = e v := rfl

def linearEquivAction : (V₂ ≃ₗ[ZMod 2] V₂) →* Equiv.Perm NZ₂ where
  -- Step 1: package the permutation construction into a monoid homomorphism.
  toFun := permOfLinearEquiv
  map_one' := by
    -- Step 1.1: the identity linear map induces the identity permutation.
    ext v i; simp [permOfLinearEquiv]
  map_mul' e₁ e₂ := by
    -- Step 1.2: composition of linear equivalences matches multiplication of permutations.
    ext v i; simp [permOfLinearEquiv, Function.comp]

lemma linearEquivAction_injective : Function.Injective linearEquivAction := by
  classical
  -- Step 1: suppose two linear equivalences induce the same permutation.
  intro e₁ e₂ h
  -- Step 2: compare their values on every vector by splitting into `0` and nonzero cases.
  ext v i
  by_cases hv : v = (0 : V₂)
  -- Step 2.1: both linear equivalences send `0` to `0`.
  · subst hv
    simp
  -- Step 2.2: evaluate the equality of permutations on the nonzero vector `v`.
  · have := congrArg Subtype.val (congrArg (fun f => f ⟨v, hv⟩) h)
    -- Step 2.3: erase subtype wrappers to obtain equality of the underlying coordinates.
    have := congrArg (fun w => w i) this
    simpa [linearEquivAction, permOfLinearEquiv] using this

def glLinearEquiv :
    Matrix.GeneralLinearGroup (Fin 2) (ZMod 2) ≃* (V₂ ≃ₗ[ZMod 2] V₂) :=
  (Matrix.GeneralLinearGroup.toLin (n := Fin 2) (R := ZMod 2)).trans
    (LinearMap.GeneralLinearGroup.generalLinearEquiv (ZMod 2) V₂)

def glAction : Matrix.GeneralLinearGroup (Fin 2) (ZMod 2) →* Equiv.Perm NZ₂ :=
  -- Step 1: compose the matrix-to-linear-equivalence isomorphism with the permutation action.
  linearEquivAction.comp glLinearEquiv.toMonoidHom

lemma glAction_injective : Function.Injective glAction := by
  -- Step 1: composition of the injective action with the injective `MulEquiv` remains injective.
  refine linearEquivAction_injective.comp ?_
  intro A B hAB
  exact glLinearEquiv.injective hAB

lemma card_GL_two :
    Fintype.card (Matrix.GeneralLinearGroup (Fin 2) (ZMod 2)) = 6 := by
  classical
  -- Step 1: apply the general cardinal formula for `GL₂` over a finite field.
  have h := Matrix.card_GL_field (n := 2) (𝔽 := ZMod 2)
  -- Step 2: translate `Nat.card` into the standard `Fintype.card`.
  have h' := by
    simpa [Nat.card_eq_fintype_card] using h
  -- Step 3: explicitly compute the product `(4 - 1) * (4 - 2) = 6`.
  have : ∏ i : Fin 2, ((2 : ℕ) ^ 2 - (2 : ℕ) ^ (i : ℕ)) = 6 := by
    classical
    simp [Fin.prod_univ_two, pow_zero, pow_one]
  -- Step 4: simplify the powers of `2` and conclude `|GL₂(ℤ₂)| = 6`.
  simpa [ZMod.card, this] using h'

theorem Herstein_exercise_4_1_34_corrected :
    Nonempty (Equiv.Perm (Fin 3) ≃* Matrix.GeneralLinearGroup (Fin 2) (ZMod 2)) := by
  classical
  -- Step 1: record the cardinalities of `GL₂(ℤ₂)` and of permutations of the three nonzero vectors.
  have hGL := card_GL_two
  have hPerm := card_perm_nonzero
  -- Step 2: turn these counts into an explicit bijection witness between the two underlying sets.
  have hCardEq : Fintype.card (Matrix.GeneralLinearGroup (Fin 2) (ZMod 2)) =
      Fintype.card (Equiv.Perm NZ₂) := by
    simp [hGL, hPerm]
  obtain ⟨e⟩ := (Fintype.card_eq).1 hCardEq
  -- Step 3: the counting argument upgrades the injective action to a bijective homomorphism.
  have hSurj : Function.Surjective glAction :=
    Function.Injective.surjective_of_finite (e := e) glAction_injective
  -- Step 4: convert the bijective homomorphism into a multiplicative equivalence.
  have isoGLPermNZ :
      Matrix.GeneralLinearGroup (Fin 2) (ZMod 2) ≃* Equiv.Perm NZ₂ :=
    MulEquiv.ofBijective glAction ⟨glAction_injective, hSurj⟩
  -- Step 5: shuttle the action along the canonical equivalence between `NZ₂` and `Fin 3`.
  let nzIso := nzEquivFin3
  have isoGLPermFin3 :
      Matrix.GeneralLinearGroup (Fin 2) (ZMod 2) ≃* Equiv.Perm (Fin 3) :=
    isoGLPermNZ.trans nzIso.permCongrHom
  -- Step 6: take the symmetric of the obtained isomorphism to match the goal statement.
  exact ⟨isoGLPermFin3.symm⟩

end
