import Mathlib


open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators InnerProductSpace

/-Informal Statement

Suppose $U$ is a subspace of $V$. Prove that $U^{\perp}=\{0\}$ if and only if $U=V$
-/

/-Informal Proof

$V=U \bigoplus U^{\perp}$, therefore $U^\perp = \{0\}$ iff $U=V$.
-/

theorem Axler_exercise_6_16 {K V : Type*} [RCLike K] [NormedAddCommGroup V] [InnerProductSpace K V]
  {U : Submodule K V} :
  U.orthogonal = ⊥  ↔ U = ⊤ := by
  sorry

/-! ### Refutation

Axler works with *finite-dimensional* inner product spaces, where `V = U ⊕ Uᗮ` and hence
`Uᗮ = ⊥ ↔ U = ⊤`.  The formalization drops every completeness / finite-dimensionality
hypothesis (Mathlib's `Submodule.orthogonal_eq_bot_iff` needs `[K.HasOrthogonalProjection]`),
and without such a hypothesis `Uᗮ = ⊥` only says that `U` is *dense*.  So any proper dense
subspace of an infinite-dimensional inner product space refutes the statement.

**Counterexample.**  `V = ℓ²(ℕ, ℝ) = lp (fun _ : ℕ => ℝ) 2` over `K = ℝ`, and
`U = {x ∈ ℓ² | x has finite support}`.
* `Uᗮ = ⊥`: if `x ⊥ U`, then for every `i` the standard basis vector `lp.single 2 i 1`
  lies in `U`, so `0 = ⟪single i 1, x⟫ = x i` by `lp.inner_single_left`; hence `x = 0`.
* `U ≠ ⊤`: the geometric sequence `n ↦ (1/2)^n` lies in `ℓ²` but has full support.

Since the negated statement is universe polymorphic (`K : Type u_1`, `V : Type u_2`) while the
only `RCLike` fields in Mathlib are `ℝ` and `ℂ` (both in `Type 0`), the counterexample has to be
transported into arbitrary universes with `ULift`.  Mathlib has no `RCLike (ULift ℝ)` instance
and no `InnerProductSpace` instance on a `ULift`, so both are built below (as plain `def`s, so
that no ambient instance is added to the file). -/

/-- Step A: the (trivial) star structure on `ULift ℝ`, needed as a parent of `RCLike`. -/
def pn24Star.{u} : StarRing (ULift.{u} ℝ) where
  star x := x
  star_involutive := fun _ => rfl
  star_mul := fun a b => mul_comm a b
  star_add := fun _ _ => rfl

/-- Step B: `ULift ℝ` is a normed field.  Everything is inherited from the existing `Field` and
`NormedRing` instances on `ULift ℝ`; only multiplicativity of the norm has to be supplied. -/
noncomputable def pn24NF.{u} : NormedField (ULift.{u} ℝ) :=
  { (inferInstance : Field (ULift.{u} ℝ)), (inferInstance : NormedRing (ULift.{u} ℝ)) with
    norm_mul := fun a b => abs_mul a.down b.down }

/-- Step C: the norm on `ULift ℝ` has dense range, since the norm on `ℝ` does. -/
noncomputable def pn24DNF.{u} : DenselyNormedField (ULift.{u} ℝ) :=
  { pn24NF.{u} with
    lt_norm_lt := fun x y h0 hxy => by
      obtain ⟨a, ha1, ha2⟩ := DenselyNormedField.lt_norm_lt (α := ℝ) x y h0 hxy
      exact ⟨ULift.up a, ha1, ha2⟩ }

/-- Step D: `ULift ℝ` is an `RCLike` field, with `re = ULift.down`, `im = 0` and `I = 0`
(the "real" shape of `RCLike`).  The `NormedAlgebra ℝ`, `CompleteSpace` and `PartialOrder`
parents already exist in Mathlib for `ULift`. -/
noncomputable def pn24RCLike.{u} : RCLike (ULift.{u} ℝ) :=
  { pn24DNF.{u}, pn24Star.{u}, (inferInstance : NormedAlgebra ℝ (ULift.{u} ℝ)),
    (inferInstance : CompleteSpace (ULift.{u} ℝ)),
    (inferInstance : PartialOrder (ULift.{u} ℝ)) with
    re := { toFun := ULift.down, map_zero' := rfl, map_add' := fun _ _ => rfl }
    im := 0
    I := 0
    I_re_ax := rfl
    I_mul_I_ax := Or.inl rfl
    re_add_im_ax := fun z => by ext; simp
    ofReal_re_ax := fun r => rfl
    ofReal_im_ax := fun r => rfl
    mul_re_ax := fun z w => by simp
    mul_im_ax := fun z w => by simp
    conj_re_ax := fun z => rfl
    conj_im_ax := fun z => by simp
    conj_I_ax := by simp
    norm_sq_eq_def_ax := fun z => by
      -- `‖z‖ = |z.down|`, so this is `|r| * |r| = r * r`.
      have hz : ‖z‖ * ‖z‖ = z.down * z.down := abs_mul_abs_self z.down
      simpa [sq] using hz
    mul_im_I_ax := fun z => by simp
    le_iff_re_im := by
      -- the order on `ULift ℝ` is the order on `ℝ`, and the imaginary parts are both `0`
      intro z w
      exact ⟨fun h => ⟨h, rfl⟩, fun h => h.1⟩
    toDecidableEq := Classical.decEq _ }

/-- Step E: `ULift ℓ²(ℕ, ℝ)` is an inner product space over `ULift ℝ`, with the inner product
lifted coordinatewise from the standard one on `lp (fun _ : ℕ => ℝ) 2`.  The scalar action is
the standard `ULift` one, and the norm is the standard (lifted) `ℓ²` norm. -/
noncomputable def pn24IPS.{u, v} :
    @InnerProductSpace (ULift.{u} ℝ) (ULift.{v} (lp (fun _ : ℕ => ℝ) 2))
      pn24RCLike.{u} inferInstance :=
  letI := pn24RCLike.{u}
  { toNormedSpace :=
      { __ := (inferInstance : Module (ULift.{u} ℝ) (ULift.{v} (lp (fun _ : ℕ => ℝ) 2)))
        norm_smul_le := fun a b => norm_smul_le a.down b.down }
    inner := fun x y => ULift.up (inner ℝ x.down y.down)
    norm_sq_eq_re_inner := fun x => by
      show ‖x.down‖ ^ 2 = inner ℝ x.down x.down
      exact (real_inner_self_eq_norm_sq x.down).symm
    conj_inner_symm := fun x y => by
      show ULift.up (inner ℝ y.down x.down) = ULift.up (inner ℝ x.down y.down)
      exact congrArg ULift.up (real_inner_comm _ _)
    add_left := fun x y z => by
      show ULift.up (inner ℝ (x.down + y.down) z.down)
        = ULift.up (inner ℝ x.down z.down + inner ℝ y.down z.down)
      exact congrArg ULift.up (inner_add_left _ _ _)
    smul_left := fun x y r => by
      show ULift.up (inner ℝ (r.down • x.down) y.down)
        = ULift.up (r.down * inner ℝ x.down y.down)
      exact congrArg ULift.up (real_inner_smul_left _ _ _) }

/-- Step F: the geometric sequence `n ↦ (1/2)^n` lies in `ℓ²(ℕ, ℝ)`.
It is even in `ℓ¹`, and `ℓ¹ ⊆ ℓ²`. -/
theorem pn24_geom_mem : Memℓp (fun n : ℕ => (1/2 : ℝ) ^ n) 2 := by
  -- Step F.1: `∑ ‖(1/2)^n‖ ^ 1` is a convergent geometric series.
  have hs : Summable fun n : ℕ => ‖((1/2 : ℝ)) ^ n‖ ^ (1 : ENNReal).toReal := by
    simp only [ENNReal.toReal_one, Real.rpow_one, norm_pow, Real.norm_eq_abs]
    simpa using summable_geometric_of_lt_one (r := |(1/2 : ℝ)|) (by positivity) (by norm_num)
  -- Step F.2: membership in `ℓ¹` upgrades to membership in `ℓ²` since `1 ≤ 2`.
  exact (memℓp_gen (p := 1) hs).of_exponent_ge (by norm_num)

/-- Step G: each standard basis vector `lp.single 2 i 1` is finitely supported,
i.e. it belongs to `ℓ⁰`. -/
theorem pn24_single_mem (i : ℕ) : Memℓp (⇑(lp.single (E := fun _ : ℕ => ℝ) 2 i (1 : ℝ))) 0 := by
  -- Step G.1: the coefficients are `Pi.single i 1`, supported in `{i}`.
  rw [lp.coeFn_single]
  refine memℓp_zero ((Set.finite_singleton i).subset ?_)
  intro j hj
  simp only [Set.mem_setOf_eq] at hj
  by_contra hne
  exact hj (Pi.single_eq_of_ne (by simpa [Set.mem_singleton_iff] using hne) _)

theorem Axler_exercise_6_16_neg : ¬ (type_of% @Axler_exercise_6_16) := by
  -- Step 1: assume the universally quantified statement.
  intro h
  -- Step 2: install the counterexample structures of Steps D and E as local instances:
  -- `K = ULift ℝ` and `V = ULift ℓ²(ℕ, ℝ)`, in the universes the statement quantifies over.
  letI instK := pn24RCLike.{u_1}
  letI instI := pn24IPS.{u_1, u_2}
  -- Step 3: `U` is the subspace of finitely supported elements of `ℓ²`
  -- (`Memℓp · 0` *is* finiteness of the support); it is a submodule because finite supports
  -- are stable under addition and scalar multiplication.
  let U : Submodule (ULift.{u_1} ℝ) (ULift.{u_2} (lp (fun _ : ℕ => ℝ) 2)) :=
    { carrier := {x | Memℓp (⇑x.down) 0}
      add_mem' := by
        intro a b ha hb
        simpa [lp.coeFn_add] using ha.add hb
      zero_mem' := by
        simpa [lp.coeFn_zero] using (zero_memℓp (E := fun _ : ℕ => ℝ) (p := 0))
      smul_mem' := by
        intro c x hx
        simpa [lp.coeFn_smul] using hx.const_smul c.down }
  -- Step 4: every standard basis vector lies in `U` (Step G).
  have hsingle : ∀ i : ℕ,
      (ULift.up (lp.single (E := fun _ : ℕ => ℝ) 2 i (1 : ℝ)) : ULift.{u_2} _) ∈ U :=
    fun i => pn24_single_mem i
  -- Step 5: `Uᗮ = ⊥`, i.e. `U` is dense: a vector orthogonal to all basis vectors vanishes.
  have horth : U.orthogonal = ⊥ := by
    rw [Submodule.eq_bot_iff]
    intro x hx
    rw [Submodule.mem_orthogonal] at hx
    -- Step 5.1: all coordinates of `x` vanish.
    have hco : ∀ i : ℕ, (x.down : lp (fun _ : ℕ => ℝ) 2) i = 0 := by
      intro i
      -- Step 5.2: pair `x` with the `i`-th basis vector; the inner product on `ULift`
      -- is the lifted one, so its `down` is the honest real inner product.
      have h0 := hx _ (hsingle i)
      have h1 : (inner ℝ (lp.single (E := fun _ : ℕ => ℝ) 2 i (1 : ℝ)) x.down : ℝ) = 0 :=
        congrArg ULift.down h0
      -- Step 5.3: `⟪single i 1, x⟫ = ⟪1, x i⟫ = x i`.
      rw [lp.inner_single_left] at h1
      simpa [RCLike.inner_apply] using h1
    -- Step 5.4: a vector of `ℓ²` with all coordinates `0` is `0`.
    have hx0 : (x.down : lp (fun _ : ℕ => ℝ) 2) = 0 :=
      lp.eq_zero_iff_coeFn_eq_zero.mpr (funext hco)
    exact ULift.ext _ _ hx0
  -- Step 6: the assumed statement now forces `U = ⊤`, i.e. every element of `ℓ²` is
  -- finitely supported.
  have htop : U = ⊤ := (@h _ _ instK inferInstance instI U).mp horth
  -- Step 7: apply this to the geometric sequence of Step F, which lies in `ℓ²`.
  have hgU : (ULift.up (⟨fun n => (1/2 : ℝ) ^ n, pn24_geom_mem⟩ :
      lp (fun _ : ℕ => ℝ) 2) : ULift.{u_2} _) ∈ U := htop ▸ Submodule.mem_top
  have hfin : Set.Finite {n : ℕ | (1/2 : ℝ) ^ n ≠ 0} := memℓp_zero_iff.mp hgU
  -- Step 8: but `(1/2)^n ≠ 0` for every `n`, so that support is all of `ℕ`: contradiction.
  have huniv : {n : ℕ | (1/2 : ℝ) ^ n ≠ 0} = Set.univ := by
    ext n
    simp
  rw [huniv] at hfin
  exact Set.infinite_univ hfin


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators ENNReal ComplexConjugate

/-
The original statement is correct, but as a mathematical claim it’s false in general for inner
product spaces. The informal proof line “V = U ⊕ Uᗮ” only holds when U is closed and the ambient
space is complete (or when V is finite-dimensional, in which case every subspace is closed).
Without these hypotheses one can have a proper dense subspace U with Uᗮ = {0} but U ≠ V.

Fix: require both `(hU : IsClosed (U : Set V))` and `[CompleteSpace V]`, which is weaker than assuming `[FiniteDimensional K V]` or `[U.HasOrthogonalProjection]`.
--/
theorem Axler_exercise_6_16_corrected {K V : Type*} [RCLike K] [NormedAddCommGroup V]
  [InnerProductSpace K V] [CompleteSpace V] {U : Submodule K V}
  (hU : IsClosed (U : Set V)) :
  U.orthogonal = ⊥ ↔ U = ⊤ := by
  classical
  constructor
  · -- Step 1: Assume that the orthogonal complement is trivial and deduce that `U` equals `⊤`.
    intro hOrth
    -- Step 1.1: A closed submodule has dense span precisely when its orthogonal complement vanishes.
    have hClosureTop : U.topologicalClosure = (⊤ : Submodule K V) :=
      (Submodule.topologicalClosure_eq_top_iff).2 hOrth
    -- Step 1.2: Invoke the closedness hypothesis and eliminate the topological closure.
    have hClosedEq : U.topologicalClosure = U := hU.submodule_topologicalClosure_eq
    simpa [hClosedEq] using hClosureTop
  · -- Step 2: Conversely, if `U = ⊤`, its orthogonal complement is clearly `⊥`.
    intro hTop
    simp [hTop]
