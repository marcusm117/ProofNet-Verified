import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $X$ be a metric space in which every infinite subset has a limit point. Prove that $X$ is separable.
-/

/-Informal Proof

We observe that if the process of constructing $x_j$ did not terminate, the result would be an infinite set of points $x_j, j=1,2, \ldots$, such that $d\left(x_i, x_j\right) \geq \delta$ for $i \neq j$. It would then follow that for any $x \in X$, the open ball $B_{\frac{\delta}{2}}(x)$ contains at most one point of the infinite set, hence that no point could be a limit point of this set, contrary to hypothesis. Hence $X$ is totally bounded, i.e., for each $\delta>0$ there is a finite set $x_1, \ldots, x_{N\delta}$such that $X=\bigcup_{j / 1}^{N\delta} B_\delta\left(x_j\right)$

Let $x_{n_1}, \ldots, x_{n N_n}$ be such that $X=\bigcup_{j / 1}^{N_n} B_{\frac{1}{n}}\left(x_{n j}\right), n=1,2, \ldots$ We claim that $\left\{x_{n j}: 1 \leq j \leq N_n ; n=1,2, \ldots\right\}$ is a countable dense subset of $X$. Indeed
25
if $x \in X$ and $\delta>0$, then $x \in B_{\frac{1}{n}}\left(x_{n j}\right)$ for some $x_{n j}$ for some $n>\frac{1}{\delta}$, and hence $d\left(x, x_{n j}\right)<\delta$. By definition, this means that $\left\{x_{n j}\right\}$ is dense in $X$.
-/

theorem Rudin_exercise_2_24 {X : Type*} [MetricSpace X]
  (hX : ∀ (A : Set X), Infinite A → ∃ (x : X), x ∈ closure A) :
  SeparableSpace X := by
  sorry

/-!
## Why the formalization is false

The informal hypothesis is "every infinite subset has a *limit point*", i.e. for every
infinite `A` there is `x` with `x ∈ closure (A \ {x})` (an accumulation point of `A`).
What got formalized is `∀ A, Infinite A → ∃ x, x ∈ closure A`, which drops the
`\ {x}` and is therefore **vacuous**: an infinite set `A` is nonempty, and
`A ⊆ closure A`, so any element of `A` witnesses the existential in *every* metric space.

Consequently the formalized statement says that *every* metric space is separable,
which is false.  The counterexample below is `ULift ℝ` (an uncountable type, lifted so
that it lives in the same universe as the quantified `X`) equipped with the **discrete
metric** `dist x y = if x = y then 0 else 1`.  In that space closure is the identity, so
the only dense set is the whole space, which is uncountable; hence there is no countable
dense set.
-/

/-- Auxiliary lemma: no uncountable type can satisfy the (vacuous) hypothesis-to-separability
implication, because the discrete metric turns it into a non-separable metric space. -/
theorem Rudin_exercise_2_24_aux.{u} (α : Type u) [Uncountable α]
    (h : ∀ (X : Type u) [MetricSpace X],
      (∀ (A : Set X), Infinite A → ∃ (x : X), x ∈ closure A) → SeparableSpace X) : False := by
  classical
  -- Step 1: equip `α` with the discrete metric `dist x y = if x = y then 0 else 1`.
  -- (We use `letI` rather than a global `instance`, so nothing else in the file is affected.)
  letI : MetricSpace α :=
    { dist := fun x y => if x = y then 0 else 1
      -- Step 1.1: `dist x x = 0` since the `if` takes the `then` branch.
      dist_self := by simp
      -- Step 1.2: symmetry, by case-splitting on `x = y`.
      dist_comm := by
        intro x y
        obtain hxy | hxy := eq_or_ne x y
        · simp [hxy]
        · simp [hxy, hxy.symm]
      -- Step 1.3: the triangle inequality, by brute-force case analysis on the three
      -- possible equalities (all resulting numeric goals are among `0 ≤ 0`, `1 ≤ 1`,
      -- `1 ≤ 0 + 1`, `1 ≤ 1 + 1`, ...).
      dist_triangle := by
        intro x y z
        by_cases hxy : x = y <;> by_cases hxz : x = z <;> by_cases hyz : y = z <;>
          simp_all
      -- Step 1.4: `dist x y = 0` forces the `then` branch, i.e. `x = y`.
      eq_of_dist_eq_zero := by simp }
  -- Step 2: the formalized hypothesis holds *vacuously* in this (indeed in any) space:
  -- an infinite subset `A` is nonempty, and `A ⊆ closure A`.
  have hvac : ∀ (A : Set α), Infinite A → ∃ (x : α), x ∈ closure A := by
    intro A hA
    -- Step 2.1: `Infinite ↥A` gives `Nonempty ↥A`, so pick `a ∈ A`.
    obtain ⟨a, ha⟩ := (inferInstance : Nonempty ↥A)
    -- Step 2.2: `a ∈ A ⊆ closure A`.
    exact ⟨a, subset_closure ha⟩
  -- Step 3: apply the (false) universal statement to get separability of `α`.
  haveI : SeparableSpace α := h α hvac
  obtain ⟨s, hcount, hdense⟩ := TopologicalSpace.exists_countable_dense α
  -- Step 4: in the discrete metric, closure is the identity, so a dense set is everything.
  have hsub : (Set.univ : Set α) ⊆ s := by
    intro x _
    -- Step 4.1: density gives a point `b ∈ s` with `dist x b < 1`.
    obtain ⟨b, hbs, hlt⟩ := Metric.mem_closure_iff.mp (hdense x) 1 one_pos
    -- Step 4.2: unfold the discrete distance; `dist x b < 1` rules out `x ≠ b`.
    change (if x = b then 0 else 1) < 1 at hlt
    by_cases hxb : x = b
    · -- Step 4.3: hence `x = b ∈ s`.
      exact hxb ▸ hbs
    · -- Step 4.4: otherwise `dist x b = 1`, contradicting `dist x b < 1`.
      rw [if_neg hxb] at hlt
      exact absurd hlt (lt_irrefl 1)
  -- Step 5: therefore `Set.univ` is countable, contradicting `Uncountable α`.
  exact Set.not_countable_univ (Set.Countable.mono hsub hcount)

/-! ## Refutation
The original statement `Rudin_exercise_2_24` is false: `Rudin_exercise_2_24_neg` proves the negation of its elaborated type. -/
theorem Rudin_exercise_2_24_neg : ¬ (type_of% @Rudin_exercise_2_24) := by
  -- Step 6: instantiate the universally quantified statement at the uncountable discrete
  -- space `ULift ℝ` (lifted into the universe of the quantified type variable).
  intro h
  refine Rudin_exercise_2_24_aux (ULift ℝ) ?_
  intro X i hX
  exact @h X i hX

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

namespace Exercise224

open Classical

open Exercise224

/-
Corrected statement: the faithful translation of "every infinite subset has a limit
point" uses `AccPt` (genuine accumulation), not "lies in some closure" (which is
vacuously true for any nonempty set). With this real hypothesis, separability follows
by Rudin's argument: limit-point compactness implies total boundedness, and total
boundedness in a metric space implies separability.
-/

section Corrected

variable {X : Type*} [MetricSpace X]

/-- A totally bounded metric space is separable. -/
lemma separable_of_totallyBounded
    (hTB : TotallyBounded (Set.univ : Set X)) :
    SeparableSpace X := by
  classical
  -- Step 1: choose a finite `1/(n+1)`-net for every natural number `n`.
  choose t ht using fun n : ℕ =>
    (Metric.finite_approx_of_totallyBounded hTB) (1 / (n + 1 : ℝ)) (by
      have : (0 : ℝ) < n + 1 := by exact_mod_cast Nat.succ_pos _
      exact one_div_pos.2 this)
  refine ⟨⟨⋃ n : ℕ, t n, ?_, ?_⟩⟩
  · exact Set.countable_iUnion fun n => (ht n).2.1.countable
  · intro x
    refine Metric.mem_closure_iff.2 ?_
    intro ε εpos
    obtain ⟨n, hn⟩ := exists_nat_one_div_lt (ε := ε) εpos
    have hx := (ht n).2.2 (Set.mem_univ x)
    rcases Set.mem_iUnion.1 hx with ⟨y, hy⟩
    rcases Set.mem_iUnion.1 hy with ⟨hy', hball⟩
    refine ⟨y, Set.mem_iUnion.2 ⟨n, hy'⟩, ?_⟩
    exact lt_trans hball hn

/-- Limit-point compactness implies total boundedness in a metric space (Rudin 2.37). -/
lemma totallyBounded_of_BW
    (hBW : ∀ A : Set X, A.Infinite → ∃ p : X, AccPt p (𝓟 A)) :
    TotallyBounded (Set.univ : Set X) := by
  classical
  rw [Metric.totallyBounded_iff]
  intro ε εpos
  by_contra hntb
  push_neg at hntb
  -- Step 1: For every finite `F`, there is a point of `X` at distance `≥ ε` from all of `F`.
  have hex : ∀ (F : Set X), F.Finite → ∃ z, ∀ y ∈ F, ε ≤ dist z y := by
    intro F hF
    have hcov : ¬ (Set.univ : Set X) ⊆ ⋃ y ∈ F, Metric.ball y ε := hntb F hF
    rw [Set.not_subset] at hcov
    obtain ⟨z, _, hz⟩ := hcov
    refine ⟨z, fun y hyF => ?_⟩
    by_contra hlt
    push_neg at hlt
    exact hz (Set.mem_iUnion₂.mpr ⟨y, hyF, Metric.mem_ball.mpr hlt⟩)
  -- Step 2: Recursively build a strictly growing chain of `ε`-separated finsets `G n`.
  let next : Finset X → Finset X := fun s =>
    insert (Classical.choose (hex (s : Set X) s.finite_toSet)) s
  let G : ℕ → Finset X := fun n => next^[n] ∅
  let z : ℕ → X := fun n => Classical.choose (hex (G n : Set X) (G n).finite_toSet)
  have hz_prop : ∀ n, ∀ y ∈ G n, ε ≤ dist (z n) y := fun n =>
    Classical.choose_spec (hex (G n : Set X) (G n).finite_toSet)
  have hG_succ : ∀ n, G (n + 1) = insert (z n) (G n) := by
    intro n
    show next^[n + 1] ∅ = insert (z n) (next^[n] ∅)
    rw [Function.iterate_succ_apply']
  have hG_mono : ∀ {m n : ℕ}, m ≤ n → G m ⊆ G n := by
    intro m n hmn
    induction n with
    | zero =>
        have : m = 0 := Nat.eq_zero_of_le_zero hmn
        subst this; exact fun _ h => h
    | succ k ih =>
        rcases Nat.lt_or_ge m (k + 1) with hlt | hge
        · have hmk : m ≤ k := Nat.lt_succ_iff.mp hlt
          intro x hx
          rw [hG_succ]
          exact Finset.mem_insert.mpr (Or.inr (ih hmk hx))
        · have : m = k + 1 := le_antisymm hmn hge
          subst this; exact fun _ h => h
  have hz_in_G : ∀ n, z n ∈ G (n + 1) := by
    intro n; rw [hG_succ]; exact Finset.mem_insert_self _ _
  -- Step 3: `z` is injective and pairwise `ε`-separated.
  have hz_pairwise : ∀ {i j : ℕ}, i < j → ε ≤ dist (z i) (z j) := by
    intro i j hij
    have hzi_in_Gj : z i ∈ G j := hG_mono hij (hz_in_G i)
    have h := hz_prop j (z i) hzi_in_Gj
    rw [dist_comm] at h
    exact h
  have hz_inj : Function.Injective z := by
    intro i j hij
    rcases lt_trichotomy i j with hlt | heq | hgt
    · exfalso
      have h := hz_pairwise hlt
      rw [hij, dist_self] at h; linarith
    · exact heq
    · exfalso
      have h := hz_pairwise hgt
      rw [← hij, dist_self] at h; linarith
  -- Step 4: The range of `z` is infinite, so by `BW` it has an accumulation point.
  have hrange_inf : (Set.range z).Infinite := Set.infinite_range_of_injective hz_inj
  obtain ⟨p, hp⟩ := hBW (Set.range z) hrange_inf
  rw [accPt_iff_nhds] at hp
  -- Step 5: Extract two distinct points of `range z` inside `ball p (ε/2)`.
  obtain ⟨y₁, ⟨hy₁_ball, hy₁_range⟩, hy₁_ne⟩ :=
    hp (Metric.ball p (ε / 2)) (Metric.ball_mem_nhds p (by linarith))
  have hU2_open : IsOpen (Metric.ball p (ε / 2) \ {y₁}) := by
    rw [Set.diff_eq]
    exact Metric.isOpen_ball.inter isClosed_singleton.isOpen_compl
  have hp_in_U2 : p ∈ Metric.ball p (ε / 2) \ {y₁} :=
    ⟨Metric.mem_ball_self (by linarith),
      by simpa [Set.mem_singleton_iff] using hy₁_ne.symm⟩
  obtain ⟨y₂, ⟨⟨hy₂_ball, hy₂_ne_y₁⟩, hy₂_range⟩, _hy₂_ne⟩ :=
    hp (Metric.ball p (ε / 2) \ {y₁}) (hU2_open.mem_nhds hp_in_U2)
  -- Step 6: But two distinct elements of `range z` have distance `≥ ε` — contradiction.
  obtain ⟨i, rfl⟩ := hy₁_range
  obtain ⟨j, rfl⟩ := hy₂_range
  have hij : i ≠ j := fun h => hy₂_ne_y₁ (by simp [h])
  have hdist_ge : ε ≤ dist (z i) (z j) := by
    rcases lt_or_gt_of_ne hij with h | h
    · exact hz_pairwise h
    · rw [dist_comm]; exact hz_pairwise h
  have h1 : dist (z i) p < ε / 2 := hy₁_ball
  have h2 : dist (z j) p < ε / 2 := hy₂_ball
  have hdist_lt : dist (z i) (z j) < ε := by
    calc dist (z i) (z j)
        ≤ dist (z i) p + dist p (z j) := dist_triangle _ _ _
      _ = dist (z i) p + dist (z j) p := by rw [dist_comm p (z j)]
      _ < ε / 2 + ε / 2 := by linarith
      _ = ε := by ring
  linarith

/-- Corrected version of Rudin's exercise 2.24 (faithful to the informal statement):
a metric space in which every infinite subset has a limit point is separable. -/
theorem _root_.Rudin_exercise_2_24_corrected
    {X : Type*} [MetricSpace X]
    (hBW : ∀ A : Set X, A.Infinite → ∃ p : X, AccPt p (𝓟 A)) :
    SeparableSpace X :=
  separable_of_totallyBounded (totallyBounded_of_BW hBW)

end Corrected

end Exercise224
