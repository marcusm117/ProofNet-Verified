import Mathlib


open Filter Real Function
open scoped Topology
noncomputable section

/-Informal Statement

Prove that $\sum 1/k(\log(k))^p$ diverges when $p \leq 1$.
-/

/-Informal Proof

Using the integral test, for a set $a$, we see
$$
\lim _{b \rightarrow \infty} \int_a^b \frac{1}{x \log (x)^c} d x=\lim _{b \rightarrow \infty}\left(\frac{\log (b)^{1-c}}{1-c}-\frac{\log (a)^{1-c}}{1-c}\right)
$$
which goes to infinity if $c \leq 1$ and converges if $c>1$. Thus,
$$
\sum_{n=2}^{\infty} \frac{1}{n \log (n)^c}
$$
converges if and only if $c>1$.
-/

theorem Pugh_exercise_3_63b (p : ℝ) (f : ℕ → ℝ) (hp : p ≤ 1)
  (h : f = λ (k : ℕ) => (1 : ℝ) / (k * (log k) ^ p)) :
  ¬ ∃ l, Tendsto f atTop (𝓝 l) := by
  sorry

/-! ### Helper lemmas for the refutation

The formalization asserts that the *term sequence* `k ↦ 1/(k * (log k)^p)` has no limit,
whereas the informal exercise asserts that the *series* `∑ 1/(k (log k)^p)` diverges.
The terms of a divergent series may perfectly well tend to `0`, and here they always do:
for every real `p` the sequence tends to `0`, so `l = 0` witnesses the existential that the
theorem denies. The simplest instance is `p = 0`, for which the sequence is just `1/k`. -/

/-- **Step 1.** For every real exponent `p`, `x * (log x) ^ p → ∞` as `x → ∞` over `ℝ`.

This is where the "the terms go to zero" fact really comes from: the logarithmic factor,
whatever its (possibly negative) exponent, is dominated by any positive power of `x`. -/
theorem Pugh_exercise_3_63b_aux (p : ℝ) :
    Tendsto (fun x : ℝ => x * (log x) ^ p) atTop atTop := by
  -- Step 1.1: `(log x)^(-p) = o(x^(1/2))`; Mathlib's `isLittleO_log_rpow_rpow_atTop`
  -- allows an arbitrary exponent on the logarithm, so this holds for every `p`.
  have h1 : (fun x : ℝ => (log x) ^ (-p)) =o[atTop] fun x : ℝ => x ^ ((1:ℝ)/2) :=
    isLittleO_log_rpow_rpow_atTop (-p) (by norm_num)
  -- Step 1.2: turn the little-o into the eventual bound `‖(log x)^(-p)‖ ≤ 1 * ‖x^(1/2)‖`.
  have h2 := h1.bound (c := 1) one_pos
  -- Step 1.3: it suffices to bound our function below by `x ^ (1/2)`, which tends to `∞`.
  refine tendsto_atTop_mono' atTop ?_
    (tendsto_rpow_atTop (show (0:ℝ) < 1/2 by norm_num))
  filter_upwards [h2, eventually_gt_atTop (1:ℝ)] with x hx hx1
  -- Step 1.4: for `x > 1` both `x` and `log x` are positive, so all norms are the values.
  have hx0 : (0:ℝ) < x := lt_trans one_pos hx1
  have hlog : 0 < log x := Real.log_pos hx1
  rw [Real.norm_of_nonneg (by positivity), Real.norm_of_nonneg (by positivity), one_mul] at hx
  have hpos : (0:ℝ) < (log x) ^ (-p) := Real.rpow_pos_of_pos hlog _
  -- Step 1.5: invert the bound `(log x)^(-p) ≤ x^(1/2)`.
  have hinv : (x ^ ((1:ℝ)/2))⁻¹ ≤ ((log x) ^ (-p))⁻¹ := by
    have := one_div_le_one_div_of_le hpos hx
    simpa [one_div] using this
  -- Step 1.6: `((log x)^(-p))⁻¹ = (log x)^p`.
  have hp' : ((log x) ^ (-p))⁻¹ = (log x) ^ p := by
    rw [Real.rpow_neg hlog.le, inv_inv]
  -- Step 1.7: `x * (x^(1/2))⁻¹ = x^(1/2)`, since `x^(1/2) * x^(1/2) = x`.
  have h12 : x ^ ((1:ℝ)/2) * x ^ ((1:ℝ)/2) = x := by
    rw [← Real.rpow_add hx0]; norm_num
  have hxp : (0:ℝ) < x ^ ((1:ℝ)/2) := Real.rpow_pos_of_pos hx0 _
  have hsq : x * (x ^ ((1:ℝ)/2))⁻¹ = x ^ ((1:ℝ)/2) := by
    rw [inv_eq_one_div, mul_one_div, div_eq_iff hxp.ne']
    exact h12.symm
  -- Step 1.8: chain the pieces into `x^(1/2) ≤ x * (log x)^p`.
  calc x ^ ((1:ℝ)/2) = x * (x ^ ((1:ℝ)/2))⁻¹ := hsq.symm
    _ ≤ x * ((log x) ^ (-p))⁻¹ := mul_le_mul_of_nonneg_left hinv hx0.le
    _ = x * (log x) ^ p := by rw [hp']

/-- **Step 2.** Consequently the sequence `k ↦ 1/(k * (log k) ^ p)` tends to `0`
for every real `p` — in particular it *does* have a limit. -/
theorem Pugh_exercise_3_63b_zero (p : ℝ) :
    Tendsto (fun k : ℕ => (1:ℝ) / (k * (log k) ^ p)) atTop (𝓝 0) := by
  -- Step 2.1: compose Step 1 with `(↑· : ℕ → ℝ) → ∞` to get divergence along the naturals.
  have h := (Pugh_exercise_3_63b_aux p).comp (tendsto_natCast_atTop_atTop (R := ℝ))
  -- Step 2.2: the reciprocal of a function tending to `∞` tends to `0`.
  refine Tendsto.congr ?_ h.inv_tendsto_atTop
  intro k
  rw [Pi.inv_apply, Function.comp_apply, one_div]

/-! ## Refutation
The original statement `Pugh_exercise_3_63b` is false: `Pugh_exercise_3_63b_neg` proves the negation of its elaborated type. -/
theorem Pugh_exercise_3_63b_neg : ¬ (type_of% @Pugh_exercise_3_63b) := by
  -- Step 3: instantiate at the counterexample `p = 0` (so `hp : 0 ≤ 1` holds) and
  -- `f = fun k => 1/(k * (log k)^0) = 1/k`, whose limit `l = 0` exists by Step 2.
  intro H
  exact H 0 _ zero_le_one rfl ⟨0, Pugh_exercise_3_63b_zero 0⟩

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Real Function
open scoped Topology

theorem Pugh_exercise_3_63b_corrected (p : ℝ) (f : ℕ → ℝ) (hp : p ≤ 1)
    (h : f = fun k : ℕ => 1 / (k * (Real.log k) ^ p)) :
    ¬ Summable f := by
  classical
  subst h
  -- Helper: `log 3 > 1`, since `e < 3`.
  have hlog3 : (1 : ℝ) < Real.log 3 := by
    have hexp : Real.exp 1 < 3 := by have := Real.exp_one_lt_d9; linarith
    have hlt := Real.log_lt_log (Real.exp_pos 1) hexp
    rwa [Real.log_exp] at hlt
  -- Step 1: Prove the boundary `p = 1` case (Bertrand series) via Cauchy condensation.
  have hbertrand : ¬ Summable (fun k : ℕ => 1 / ((k : ℝ) * Real.log k)) := by
    intro hb
    -- Step 1.1: The summand is eventually nonneg (for `k ≥ 2`).
    have hnn : 0 ≤ᶠ[atTop] (fun k : ℕ => 1 / ((k : ℝ) * Real.log k)) := by
      filter_upwards [Filter.eventually_ge_atTop (2 : ℕ)] with k hk
      have hkR_pos : (0 : ℝ) < (k : ℝ) := by exact_mod_cast (by omega : 0 < k)
      have hlog_pos : 0 < Real.log k :=
        Real.log_pos (by exact_mod_cast (by omega : 1 < k))
      positivity
    -- Step 1.2: It is also eventually antitone (for `k ≥ 2`).
    have hmono : ∀ᶠ k in (atTop : Filter ℕ),
        1 / (((k + 1 : ℕ) : ℝ) * Real.log ((k + 1 : ℕ) : ℝ))
          ≤ 1 / ((k : ℝ) * Real.log k) := by
      filter_upwards [Filter.eventually_ge_atTop (2 : ℕ)] with k hk
      have hkR_pos : (0 : ℝ) < (k : ℝ) := by exact_mod_cast (by omega : 0 < k)
      have hk1R_pos : (0 : ℝ) < ((k + 1 : ℕ) : ℝ) :=
        by exact_mod_cast (by omega : 0 < k + 1)
      have hlogk_pos : 0 < Real.log k :=
        Real.log_pos (by exact_mod_cast (by omega : 1 < k))
      have hlogk1_pos : 0 < Real.log ((k + 1 : ℕ) : ℝ) :=
        Real.log_pos (by exact_mod_cast (by omega : 1 < k + 1))
      have hk_le : (k : ℝ) ≤ ((k + 1 : ℕ) : ℝ) := by push_cast; linarith
      have hlog_le : Real.log k ≤ Real.log ((k + 1 : ℕ) : ℝ) :=
        Real.log_le_log hkR_pos hk_le
      have hmul_le :
          (k : ℝ) * Real.log k ≤ ((k + 1 : ℕ) : ℝ) * Real.log ((k + 1 : ℕ) : ℝ) :=
        mul_le_mul hk_le hlog_le hlogk_pos.le hk1R_pos.le
      exact one_div_le_one_div_of_le (mul_pos hkR_pos hlogk_pos) hmul_le
    -- Step 1.3: Apply Cauchy condensation: now `hb` is on the condensed sequence.
    rw [← summable_condensed_iff_of_eventually_nonneg hnn hmono] at hb
    -- Step 1.4: For `k ≥ 1`, `2^k · (1 / (2^k · log 2^k)) = 1 / (k · log 2)`.
    rw [← summable_nat_add_iff 1] at hb
    have hlog2_pos : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
    have hsimp :
        (fun k : ℕ =>
            (2 : ℝ) ^ (k + 1) *
              (1 / (((2 ^ (k + 1) : ℕ) : ℝ) * Real.log ((2 ^ (k + 1) : ℕ) : ℝ))))
          = fun k : ℕ => 1 / (((k + 1 : ℕ) : ℝ) * Real.log 2) := by
      funext k
      have h2k_pos : (0 : ℝ) < (2 : ℝ) ^ (k + 1) := by positivity
      have h2k_ne : ((2 : ℝ) ^ (k + 1)) ≠ 0 := h2k_pos.ne'
      have hcast : ((2 ^ (k + 1) : ℕ) : ℝ) = (2 : ℝ) ^ (k + 1) := by push_cast; rfl
      have hlog : Real.log ((2 : ℝ) ^ (k + 1)) = ((k + 1 : ℕ) : ℝ) * Real.log 2 := by
        rw [Real.log_pow]
      rw [hcast, hlog]
      have hk1_pos : (0 : ℝ) < ((k + 1 : ℕ) : ℝ) :=
        by exact_mod_cast (Nat.succ_pos k)
      field_simp
    rw [hsimp] at hb
    -- Step 1.5: Multiplying by `log 2` reduces to the harmonic series.
    have hb' : Summable (fun k : ℕ => 1 / (((k + 1 : ℕ) : ℝ))) := by
      have hmul := hb.mul_left (Real.log 2)
      have heq :
          (fun k : ℕ => Real.log 2 * (1 / (((k + 1 : ℕ) : ℝ) * Real.log 2)))
            = fun k : ℕ => 1 / (((k + 1 : ℕ) : ℝ)) := by
        funext k
        have hk1_pos : (0 : ℝ) < ((k + 1 : ℕ) : ℝ) :=
          by exact_mod_cast (Nat.succ_pos k)
        field_simp
      rwa [heq] at hmul
    exact not_summable_one_div_natCast
      ((summable_nat_add_iff (f := fun n : ℕ => (1 : ℝ) / n) 1).mp hb')
  -- Step 2: For arbitrary `p ≤ 1`, compare with the Bertrand series at `p = 1`.
  intro hsum
  apply hbertrand
  -- Step 2.1: Shift past `k < 3` to apply the comparison cleanly.
  rw [← summable_nat_add_iff 3]
  refine ((summable_nat_add_iff 3).mpr hsum).of_nonneg_of_le ?nn ?bound
  -- Step 2.2: Each `1/((k+3) · log(k+3))` is nonneg for `k ≥ 0`.
  · intro n
    have hk_one : (1 : ℝ) < ((n + 3 : ℕ) : ℝ) :=
      by exact_mod_cast (by omega : 1 < n + 3)
    have hlog_pos : 0 < Real.log ((n + 3 : ℕ) : ℝ) := Real.log_pos hk_one
    have hk_pos : (0 : ℝ) < ((n + 3 : ℕ) : ℝ) :=
      by exact_mod_cast (by omega : 0 < n + 3)
    positivity
  -- Step 2.3: For `k ≥ 3` and `p ≤ 1`, `(log k)^p ≤ log k`, hence the desired inequality.
  · intro n
    have hk3 : (3 : ℝ) ≤ ((n + 3 : ℕ) : ℝ) := by exact_mod_cast (Nat.le_add_left 3 n)
    have hk_one : (1 : ℝ) < ((n + 3 : ℕ) : ℝ) :=
      by exact_mod_cast (by omega : 1 < n + 3)
    have hk_pos : (0 : ℝ) < ((n + 3 : ℕ) : ℝ) :=
      by exact_mod_cast (by omega : 0 < n + 3)
    have hlog_pos : 0 < Real.log ((n + 3 : ℕ) : ℝ) := Real.log_pos hk_one
    have hlog_ge_one : (1 : ℝ) ≤ Real.log ((n + 3 : ℕ) : ℝ) := by
      have hle := Real.log_le_log (by norm_num : (0 : ℝ) < 3) hk3
      linarith
    have hpow_le :
        Real.log ((n + 3 : ℕ) : ℝ) ^ p ≤ Real.log ((n + 3 : ℕ) : ℝ) := by
      have h := Real.rpow_le_rpow_of_exponent_le hlog_ge_one hp
      simpa [Real.rpow_one] using h
    have hpow_pos : 0 < Real.log ((n + 3 : ℕ) : ℝ) ^ p :=
      Real.rpow_pos_of_pos hlog_pos p
    have hmul_le :
        ((n + 3 : ℕ) : ℝ) * Real.log ((n + 3 : ℕ) : ℝ) ^ p
          ≤ ((n + 3 : ℕ) : ℝ) * Real.log ((n + 3 : ℕ) : ℝ) :=
      mul_le_mul_of_nonneg_left hpow_le hk_pos.le
    exact one_div_le_one_div_of_le (mul_pos hk_pos hpow_pos) hmul_le
