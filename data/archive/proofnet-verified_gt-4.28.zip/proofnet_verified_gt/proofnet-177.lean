import Mathlib


open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-Informal Statement

Suppose that $f$ is holomorphic in an open set $\Omega$. Prove that if $|f|$ is constant, then $f$ is constant.
-/

/-Informal Proof

Let $f(z)=f(x, y)=u(x, y)+i v(x, y)$, where $z=x+i y$.
We first give a mostly correct argument; the reader should pay attention to find the difficulty. Since $|f|=\sqrt{u^2+v^2}$ is constant,
$$
\left\{\begin{array}{l}
0=\frac{\partial\left(u^2+v^2\right)}{\partial x}=2 u \frac{\partial u}{\partial x}+2 v \frac{\partial v}{\partial x} . \\
0=\frac{\partial\left(u^2+v^2\right)}{\partial y}=2 u \frac{\partial u}{\partial y}+2 v \frac{\partial v}{\partial y} .
\end{array}\right.
$$
Plug in the Cauchy-Riemann equations and we get
$$
\begin{gathered}
u \frac{\partial v}{\partial y}+v \frac{\partial v}{\partial x}=0 \\
-u \frac{\partial v}{\partial x}+v \frac{\partial v}{\partial y}=0 \\
(1.14) \Rightarrow \frac{\partial v}{\partial x}=\frac{v}{u} \frac{\partial v}{\partial y}
\end{gathered}
$$
Plug (1.15) into (1.13) and we get
$$
\frac{u^2+v^2}{u} \frac{\partial v}{\partial y}=0 .
$$
So $u^2+v^2=0$ or $\frac{\partial v}{\partial y}=0$.

If $u^2+v^2=0$, then, since $u, v$ are real, $u=v=0$, and thus $f=0$ which is constant.

Thus we may assume $u^2+v^2$ equals a non-zero constant, and we may divide by it. We multiply both sides by $u$ and find $\frac{\partial v}{\partial y}=0$, then by (1.15), $\frac{\partial v}{\partial x}=0$, and by Cauchy-Riemann, $\frac{\partial u}{\partial x}=0$.
$$
f^{\prime}=\frac{\partial f}{\partial x}=\frac{\partial u}{\partial x}+i \frac{\partial v}{\partial x}=0 .
$$
Thus $f$ is constant.
Why is the above only mostly a proof? The problem is we have a division by $u$, and need to make sure everything is well-defined. Specifically, we need to know that $u$ is never zero. We do have $f^{\prime}=0$ except at points where $u=0$, but we would need to investigate that a bit more.
Let's return to
$$
\left\{\begin{array}{l}
0=\frac{\partial\left(u^2+v^2\right)}{\partial x}=2 u \frac{\partial u}{\partial x}+2 v \frac{\partial v}{\partial x} . \\
0=\frac{\partial\left(u^2+v^2\right)}{\partial y}=2 u \frac{\partial u}{\partial y}+2 v \frac{\partial v}{\partial y} .
\end{array}\right.
$$
Plug in the Cauchy-Riemann equations and we get
$$
\begin{array}{r}
u \frac{\partial v}{\partial y}+v \frac{\partial v}{\partial x}=0 \\
-u \frac{\partial v}{\partial x}+v \frac{\partial v}{\partial y}=0 .
\end{array}
$$
We multiply the first equation $u$ and the second by $v$, and obtain
$$
\begin{aligned}
u^2 \frac{\partial v}{\partial y}+u v \frac{\partial v}{\partial x} & =0 \\
-u v \frac{\partial v}{\partial x}+v^2 \frac{\partial v}{\partial y} & =0 .
\end{aligned}
$$
Adding the two yields
$$
u^2 \frac{\partial v}{\partial y}+v^2 \frac{\partial v}{\partial y}=0,
$$
or equivalently
$$
\left(u^2+v^2\right) \frac{\partial v}{\partial y}=0 .
$$
We now argue in a similar manner as before, except now we don't have the annoying $u$ in the denominator. If $u^2+v^2=0$ then $u=v=0$, else we can divide by $u^2+v^2$ and find $\partial v / \partial y=0$. Arguing along these lines finishes the proof.
-/

theorem Shakarchi_exercise_1_13c {f : ℂ → ℂ} (Ω : Set ℂ) (a b : Ω) (h : IsOpen Ω)
  (hf : DifferentiableOn ℂ f Ω) (hc : ∃ (c : ℝ), ∀ z ∈ Ω, norm (f z) = c) :
  f a = f b := by
  sorry

/-! ### Counterexample data

Shakarchi's Exercise 1.13 is stated for a *region*, i.e. an open **connected** set.
The formalization above only assumes `IsOpen Ω`, dropping connectedness.  On a
disconnected open set a holomorphic function of constant modulus need not be
constant: it may take different (equal-modulus) values on different connected
components.

We take `Ω = ball 0 1 ∪ ball 4 1` (two disjoint open discs) and the function
`cex177f` below, which is `1` on the first disc and `-1` everywhere else.  It is
locally constant on `Ω`, hence holomorphic there, has constant modulus `1`, but
`cex177f 0 = 1 ≠ -1 = cex177f 4`. -/

/-- The counterexample function: `1` on the open unit ball, `-1` elsewhere. -/
noncomputable def cex177f : ℂ → ℂ := fun z => if ‖z‖ < 1 then 1 else -1

/-! ## Refutation
The original statement `Shakarchi_exercise_1_13c` is false: `Shakarchi_exercise_1_13c_neg` proves the negation of its elaborated type. -/
theorem Shakarchi_exercise_1_13c_neg : ¬ (type_of% @Shakarchi_exercise_1_13c) := by
  -- Step 0: assume the (over-general) statement and derive `False`.
  intro H
  -- Step 1: the counterexample domain: the union of two disjoint open unit discs,
  -- centred at `0` and at `4`.
  set Ω : Set ℂ := Metric.ball (0:ℂ) 1 ∪ Metric.ball (4:ℂ) 1 with hΩ
  -- Step 1.1: the two sample points, one in each component.
  have h0 : (0:ℂ) ∈ Ω := Or.inl (by simp)
  have h4 : (4:ℂ) ∈ Ω := Or.inr (by simp)
  -- Step 1.2: `Ω` is open, being a union of two open balls.
  have hopen : IsOpen Ω := (Metric.isOpen_ball).union Metric.isOpen_ball
  -- Step 2: the two discs are disjoint.  Concretely, any `z ∈ ball 4 1`
  -- satisfies `‖z‖ > 3`, so in particular `¬ (‖z‖ < 1)`.
  have hdisj : ∀ z : ℂ, z ∈ Metric.ball (4:ℂ) 1 → ¬ (‖z‖ < 1) := by
    intro z hz
    rw [Metric.mem_ball, dist_eq_norm] at hz
    -- Step 2.1: triangle inequality `‖4‖ ≤ ‖z‖ + ‖z - 4‖`.
    have h1 : ‖(4:ℂ)‖ ≤ ‖z‖ + ‖z - 4‖ := by
      have : ‖(0:ℂ) - (4:ℂ)‖ ≤ ‖(0:ℂ) - z‖ + ‖z - 4‖ := norm_sub_le_norm_sub_add_norm_sub 0 z 4
      simpa [norm_sub_rev] using this
    have h4' : ‖(4:ℂ)‖ = (4:ℝ) := by simp
    rw [h4'] at h1
    -- Step 2.2: `4 ≤ ‖z‖ + ‖z - 4‖ < 1 + 1` is absurd.
    intro hlt
    linarith
  -- Step 2.3: conversely, membership in `ball 0 1` is literally `‖z‖ < 1`.
  have hball0 : ∀ z : ℂ, z ∈ Metric.ball (0:ℂ) 1 → ‖z‖ < 1 := by
    intro z hz; simpa [Metric.mem_ball, dist_eq_norm] using hz
  -- Step 3: `cex177f` is differentiable on `Ω`, because it is locally constant
  -- on each of the two (open) components.
  have hdiff : DifferentiableOn ℂ cex177f Ω := by
    intro z hz
    rcases hz with hz | hz
    · -- Step 3.1: near a point of `ball 0 1`, `cex177f` agrees with the constant `1`.
      have he : cex177f =ᶠ[nhds z] (fun _ => (1:ℂ)) := by
        filter_upwards [Metric.isOpen_ball.mem_nhds hz] with w hw
        simp [cex177f, hball0 w hw]
      exact ((differentiableAt_const (1:ℂ)).congr_of_eventuallyEq he).differentiableWithinAt
    · -- Step 3.2: near a point of `ball 4 1`, `cex177f` agrees with the constant `-1`.
      have he : cex177f =ᶠ[nhds z] (fun _ => (-1:ℂ)) := by
        filter_upwards [Metric.isOpen_ball.mem_nhds hz] with w hw
        simp [cex177f, hdisj w hw]
      exact ((differentiableAt_const (-1:ℂ)).congr_of_eventuallyEq he).differentiableWithinAt
  -- Step 4: `‖cex177f z‖ = 1` everywhere (both branches have modulus one).
  have hnorm : ∃ (c : ℝ), ∀ z ∈ Ω, norm (cex177f z) = c := by
    refine ⟨1, fun z _ => ?_⟩
    by_cases hz : ‖z‖ < 1 <;> simp [cex177f, hz]
  -- Step 5: feed the counterexample to `H`, taking `a = 0` and `b = 4`.
  have key := H (f := cex177f) Ω ⟨0, h0⟩ ⟨4, h4⟩ hopen hdiff hnorm
  -- Step 5.1: evaluate both sides.
  have e0 : cex177f 0 = 1 := by simp [cex177f]
  have e4 : cex177f 4 = -1 := by
    norm_num [cex177f]
  rw [show ((⟨0, h0⟩ : Ω) : ℂ) = 0 from rfl, show ((⟨4, h4⟩ : Ω) : ℂ) = 4 from rfl,
    e0, e4] at key
  -- Step 6: `(1 : ℂ) = -1` is false.
  norm_num at key


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-
Corrected version: adding the hypothesis that Ω is preconnected forces the two points to lie
in the same connected component, so the classical maximum modulus principle applies and
shows that f is constant.  The proof below formalizes this fix.
-/

theorem Shakarchi_exercise_1_13c_corrected {f : ℂ → ℂ} {Ω : Set ℂ} (a b : Ω)
    (hΩ : IsOpen Ω) (hconn : IsPreconnected Ω)
    (hf : DifferentiableOn ℂ f Ω) (hc : ∃ c : ℝ, ∀ z ∈ Ω, ‖f z‖ = c) :
    f a = f b := by
  -- Step 1: Extract the constant value of ‖f z‖ from the hypothesis.
  obtain ⟨c, hc⟩ := hc
  -- Step 2: Package the maximality of the norm at the point a.
  have hmax : IsMaxOn (fun z => ‖f z‖) Ω a := by
    -- Step 2.1: Every point of Ω has the same norm, hence no one can exceed the value at a.
    intro z hz
    simp [hc z hz, hc a a.property]
  -- Step 3: Apply the maximum modulus principle on preconnected sets.
  have hEq :
      Set.EqOn f (fun _ => f a) Ω :=
    eqOn_of_isPreconnected_of_isMaxOn_norm hconn hΩ hf a.property hmax
  -- Step 4: Evaluate this equality-on-set statement at the point b.
  have hb_mem : ((b : ℂ) ∈ Ω) := b.property
  have hb := hEq hb_mem
  -- Step 5: The previous step already states f b = f a; rewrite to match the goal.
  simp [hb]
