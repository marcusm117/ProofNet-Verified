import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $p(x)=a_{n} x^{n}+a_{n-1} x^{n-1}+\cdots+a_{1} x+a_{0}$ be an element of the polynomial ring $R[x]$. Prove that $p(x)$ is a zero divisor in $R[x]$ if and only if there is a nonzero $b \in R$ such that $b p(x)=0$.
-/

/-Informal Proof

Solution: If $b p(x)=0$ for some nonzero $b \in R$, then it is clear that $p(x)$ is a zero divisor.
Now suppose $p(x)$ is a zero divisor; that is, for some $q(x)=\sum_{i=0}^m b_i x^i$, we have $p(x) q(x)=0$. We may choose $q(x)$ to have minimal degree among the nonzero polynomials with this property.
We will now show by induction that $a_i q(x)=0$ for all $0 \leq i \leq n$.
For the base case, note that
$$
p(x) q(x)=\sum_{k=0}^{n+m}\left(\sum_{i+j=k} a_i b_j\right) x^k=0 .
$$
The coefficient of $x^{n+m}$ in this product is $a_n b_m$ on one hand, and 0 on the other. Thus $a_n b_m=0$. Now $a_n q(x) p(x)=0$, and the coefficient of $x^m$ in $q$ is $a_n b_m=0$. Thus the degree of $a_n q(x)$ is strictly less than that of $q(x)$; since $q(x)$ has minimal degree among the nonzero polynomials which multiply $p(x)$ to 0 , in fact $a_n q(x)=0$. More specifically, $a_n b_i=0$ for all $0 \leq i \leq m$.
For the inductive step, suppose that for some $0 \leq t<n$, we have $a_r q(x)=0$ for all $t<r \leq n$. Now
$$
p(x) q(x)=\sum_{k=0}^{n+m}\left(\sum_{i+j=k} a_i b_j\right) x^k=0 .
$$
On one hand, the coefficient of $x^{m+t}$ is $\sum_{i+j=m+t} a_i b_j$, and on the other hand, it is 0 . Thus
$$
\sum_{i+j=m+t} a_i b_j=0 .
$$
By the induction hypothesis, if $i \geq t$, then $a_i b_j=0$. Thus all terms such that $i \geq t$ are zero. If $i<t$, then we must have $j>m$, a contradiction. Thus we have $a_t b_m=0$. As in the base case,
$$
a_t q(x) p(x)=0
$$
and $a_t q(x)$ has degree strictly less than that of $q(x)$, so that by minimality, $a_t q(x)=0$.
By induction, $a_i q(x)=0$ for all $0 \leq i \leq n$. In particular, $a_i b_m=0$. Thus $b_m p(x)=0$.
-/

theorem Dummit_Foote_exercise_7_2_2 {R : Type*} [Ring R] (p : Polynomial R) :
  p ∣ 0 ↔ ∃ b : R, b ≠ 0 ∧ b • p = 0 := by
  sorry

/-- Helper: over any ring `R`, the only scalar annihilating the polynomial `X` is `0`.
Indeed `b • X` has degree-1 coefficient `b • 1 = b`, so `b • X = 0` forces `b = 0`. -/
theorem smul_X_eq_zero_iff_of_ring {R : Type*} [Ring R] {b : R}
    (hbp : b • (Polynomial.X : Polynomial R) = 0) : b = 0 := by
  -- Compare the degree-1 coefficients of both sides.
  have hcoeff := congrArg (fun q => Polynomial.coeff q 1) hbp
  simpa using hcoeff

/-! ## Refutation
The original statement `Dummit_Foote_exercise_7_2_2` is false: `Dummit_Foote_exercise_7_2_2_neg` proves the negation of its elaborated type. -/
theorem Dummit_Foote_exercise_7_2_2_neg : ¬ (type_of% @Dummit_Foote_exercise_7_2_2) := by
  -- The formalization renders "p is a zero divisor in R[x]" as `p ∣ 0`, but divisibility
  -- OF zero is trivial: `dvd_zero p : p ∣ 0` for every `p` (witness `0 = p * 0`).
  -- So the left-hand side of the iff is vacuously true and the statement collapses to the
  -- false claim that every polynomial over every ring is killed by a nonzero constant.
  -- Counterexample: `R = ℤ` (universe-lifted to match the auto-bound universe) and `p = X`.
  intro h
  -- Step 1: instantiate at `R = ULift ℤ` and `p = X`.
  -- Step 1.1: the LHS `X ∣ 0` holds by `dvd_zero`, so the forward direction of the `iff`
  -- produces a nonzero `b : ULift ℤ` with `b • X = 0`.
  obtain ⟨b, hb, hbp⟩ := (h (R := ULift ℤ) Polynomial.X).mp (dvd_zero _)
  -- Step 2: by the helper lemma, comparing degree-1 coefficients gives `b = 0`.
  have hb0 : b = 0 := smul_X_eq_zero_iff_of_ring hbp
  -- Step 3: this contradicts `hb : b ≠ 0`.
  exact hb hb0

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators nonZeroDivisors

namespace ProofNet244

/-
Step 2: Provide a corrected (always true) statement.
Corrected version:
The original uses `p ∣ 0`, which is always true (take the zero multiplier)
and so does not characterize being a zero divisor.  The proper notion is
the existence of a nonzero polynomial multiplier `q` with `p * q = 0`.
With that definition, the biconditional of the informal statement does
hold: `p` is a zero divisor in `R[x]` iff some nonzero scalar `b ∈ R`
annihilates `p`.  The hard direction is the McCoy theorem, available in
Mathlib as `Polynomial.notMem_nonZeroDivisors_iff`.
-/

theorem _root_.Dummit_Foote_exercise_7_2_2_corrected {R : Type*} [CommRing R] (p : Polynomial R) :
    (∃ q : Polynomial R, q ≠ 0 ∧ p * q = 0) ↔
      (∃ b : R, b ≠ 0 ∧ b • p = 0) := by
  classical
  constructor
  · -- Forward direction: McCoy's theorem.
    -- Step 1: unpack the polynomial witness and flip the product.
    rintro ⟨q, hq, hpq⟩
    have hqp : q * p = 0 := by rw [mul_comm]; exact hpq
    -- Step 2: phrase `p` being a zero divisor via `nonZeroDivisors`.
    have hnot : p ∉ (Polynomial R)⁰ :=
      notMem_nonZeroDivisors_iff_right.mpr ⟨q, hqp, hq⟩
    -- Step 3: apply the McCoy theorem to extract a scalar annihilator.
    exact Polynomial.notMem_nonZeroDivisors_iff.mp hnot
  · -- Backward direction: the constant polynomial `C b` is the witness.
    rintro ⟨b, hb, hbp⟩
    refine ⟨Polynomial.C b, ?_, ?_⟩
    · -- Step 1: `C b ≠ 0` because `b ≠ 0` and `C` is injective at zero.
      intro hzero
      exact hb (Polynomial.C_eq_zero.mp hzero)
    · -- Step 2: `p * C b = C b * p = b • p = 0`.
      have hconst : (Polynomial.C b : Polynomial R) * p = 0 := by
        rw [← Polynomial.smul_eq_C_mul]; exact hbp
      rw [mul_comm]; exact hconst

end ProofNet244
