import Mathlib


open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators InnerProductSpace

/-Informal Statement

Suppose that $S, T \in \mathcal{L}(V)$ are such that $S T=T S$. Prove that $\operatorname{null} (T-\lambda I)$ is invariant under $S$ for every $\lambda \in \mathbf{F}$.
-/

/-Informal Proof

First off, fix $\lambda \in F$. Secondly, let $v \in \operatorname{null}(T-\lambda I)$. If so, then $(T-\lambda I)(S v)=T S v-\lambda S v=$ $S T v-\lambda S v=S(T v-\lambda v)=0$. Therefore, $S v \in \operatorname{null}(T-\lambda I)$ since $n u l l(T-\lambda I)$ is actually invariant under $S$.
-/

theorem Axler_exercise_5_4 {F V : Type*} [AddCommGroup V] [Field F]
  [Module F V] (S T : V →ₗ[F] V) (hST : S ∘ T = T ∘ S) (c : F):
  Submodule.map S (ker (T - c • LinearMap.id)) = ker (T - c • LinearMap.id) := by
  sorry

/-! ## Refutation
The original statement `Axler_exercise_5_4` is false: `Axler_exercise_5_4_neg` proves the negation of its elaborated type. -/
theorem Axler_exercise_5_4_neg : ¬ (type_of% @Axler_exercise_5_4) := by
  -- The formalization demands set EQUALITY `map S (ker (T - c • id)) = ker (T - c • id)`,
  -- whereas the informal exercise only claims INVARIANCE, i.e. the inclusion `≤`.
  -- Equality additionally needs `S` to be surjective onto that kernel, which fails for `S = 0`.
  --
  -- Step 1: instantiate at `F = ULift ℚ`, `V = ULift ℚ` (ULift so the universes match the
  -- universe-polymorphic statement), with `S = T = 0` and `c = 0`.
  intro h
  -- Step 1.1: `S ∘ T = T ∘ S` holds trivially since both sides are the constant `0`.
  have key := h (F := ULift.{u_1} ℚ) (V := ULift.{u_2} ℚ)
    (0 : ULift.{u_2} ℚ →ₗ[ULift.{u_1} ℚ] ULift.{u_2} ℚ)
    (0 : ULift.{u_2} ℚ →ₗ[ULift.{u_1} ℚ] ULift.{u_2} ℚ)
    (by funext x; simp) (0 : ULift.{u_1} ℚ)
  -- Step 2: with `T = 0` and `c = 0`, `T - c • id = 0`, so its kernel is all of `V = ⊤`,
  -- while `Submodule.map 0 ⊤ = ⊥`.  As `ULift ℚ` is nontrivial, `⊥ ≠ ⊤`.
  -- Step 2.1: read the submodule equality elementwise.
  rw [Submodule.ext_iff] at key
  -- Step 2.2: `ULift.up 1` lies in the right-hand side (the whole space), hence in the image of `0`.
  have h1 := (key (ULift.up (1 : ℚ))).2 (by simp)
  -- Step 2.3: every element of the image of the zero map is `0`, forcing `(1 : ℚ) = 0`: absurd.
  simp at h1
  exact one_ne_zero (congrArg ULift.down h1)


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators

theorem Axler_exercise_5_4_corrected {F V : Type*} [AddCommGroup V] [Field F]
    [Module F V] (S T : V →ₗ[F] V) (hST : S ∘ T = T ∘ S) (c : F) :
    Submodule.map S (ker (T - c • LinearMap.id)) ≤ ker (T - c • LinearMap.id) := by
  -- Step 1: Pick an arbitrary element of the mapped kernel and show it lies in the kernel.
  intro y
  -- Step 1.1: Destructure the membership witness coming from the definition of Submodule.map.
  rintro ⟨x, hx_mem, rfl⟩
  -- Step 2: Translate the kernel condition into the equality T x = c • x.
  have hx_eq : T x = c • x := by
    -- Step 2.1: Evaluate the kernel predicate explicitly and solve for T x.
    simpa [LinearMap.mem_ker, LinearMap.sub_apply, LinearMap.smul_apply, sub_eq_zero] using hx_mem
  -- Step 3: Use the commutation hypothesis to relate T (S x) and S (T x).
  have h_comm_pointwise :
      T (S x) = S (T x) := by
    -- Step 3.1: Apply the equality of compositions to x and rearrange.
    simpa using (congrArg (fun f => f x) hST).symm
  -- Step 4: Expand (T - c • id) (S x) and simplify the resulting expression.
  change T (S x) - c • S x = 0
  -- Step 4.1: Replace T (S x) with S (T x) via the commuting relation.
  have h_swap :
      T (S x) - c • S x =
        S (T x) - c • S x := by
    -- Step 4.1.1: Substitute the equality obtained in Step 3.
    simp [h_comm_pointwise]
  -- Step 4.2: Substitute the description of T x found in Step 2.
  have h_subst :
      S (T x) - c • S x =
        S (c • x) - c • S x := by
    -- Step 4.2.1: Replace T x with c • x.
    simp [hx_eq]
  -- Step 4.3: Evaluate S on the scalar multiple and cancel the resulting terms.
  have h_vanish :
      S (c • x) - c • S x = 0 := by
    -- Step 4.3.1: Linear maps respect scalar multiplication, so both terms coincide.
    simp
  -- Step 4.4: Chain the previous equalities to conclude the computation.
  have h_target :
      T (S x) - c • S x = 0 :=
    (h_swap.trans (h_subst.trans h_vanish))
  -- Step 4.5: Finish the proof by appealing to the computed equality.
  simpa using h_target
