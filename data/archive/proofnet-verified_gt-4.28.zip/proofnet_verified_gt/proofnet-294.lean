import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

/-Informal Statement

Show that if $Y$ is a subspace of $X$, and $A$ is a subset of $Y$, then the topology $A$ inherits as a subspace of $Y$ is the same as the topology it inherits as a subspace of $X$.
-/

/-Informal Proof

Exercise 16.1. Let $\mathcal{T}$ be the topology $A$ inherits as a subspace of $Y$, and $\mathcal{O}$ be the topology it inherits as a subspace of $X$. A (standard) basis element for $\mathcal{T}$ has the form $U \cap A$ where $U$ is open in $Y$, so is of the form $(Y \cap V) \cap A=V \cap A$ where $V$ is open in $X$. Therefore every basis element for $\mathcal{T}$ is also a basis element for $\mathcal{O}$. Conversely, a (standard) basis element for $\mathcal{O}$ have the form $W \cap A=W \cap Y \cap A$ where $W$ is open in $X$. Since $W \cap Y$ is open in $Y$, this is a basis element for $\mathcal{T}$, so every basis element for $\mathcal{O}$ is a basis element for $\mathcal{T}$. It follows that $\mathcal{T}=\mathcal{O}$.
-/

theorem Munkres_exercise_16_1 {X : Type*} [TopologicalSpace X]
  (Y : Set X)
  (A : Set Y) :
  ∀ U : Set A, IsOpen U ↔ IsOpen (Subtype.val '' U) := by
  sorry

/-! ## Refutation
The original statement `Munkres_exercise_16_1` is false: `Munkres_exercise_16_1_neg` proves the negation of its elaborated type. -/
theorem Munkres_exercise_16_1_neg : ¬ (type_of% @Munkres_exercise_16_1) := by
  -- Counterexample: X = ULift ℝ (to live in the required universe), Y = univ,
  -- A = the preimage of {up 0} in Y, and U = univ : Set A.
  intro h
  -- Step 1: `univ : Set A` is open in A, so by `h` its image in Y is open.
  have h1 := (h (X := ULift ℝ) (univ : Set (ULift ℝ))
    (Subtype.val ⁻¹' ({ULift.up 0} : Set (ULift ℝ))) univ).mp isOpen_univ
  -- Step 1.1: the image of `univ` under `Subtype.val` is just A.
  rw [Subtype.coe_image_univ] at h1
  -- Step 2: Y = univ is open in X, so `Subtype.val : Y → X` is an open map;
  -- pushing A forward gives that {up 0} is open in `ULift ℝ`.
  have h2 := (isOpen_univ (X := ULift ℝ)).isOpenMap_subtype_val _ h1
  rw [Subtype.image_preimage_coe, univ_inter] at h2
  -- Step 3: transport along the homeomorphism `ULift ℝ ≃ₜ ℝ`: {0} is open in ℝ.
  have h3 := Homeomorph.ulift.isOpenMap _ h2
  rw [Set.image_singleton] at h3
  -- Step 4: contradiction, singletons are not open in ℝ.
  exact not_isOpen_singleton (0 : ℝ) h3

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace Topology
open scoped Topology

/-
Corrected version (with proof).
Correct statement: the inclusion map `(fun a : A => (a : X))` is *inducing*,
so the topology on `A` is exactly the one induced from `X`.  This captures
precisely the idea that taking subspaces in two steps (first inside `Y`, then
inside `X`) is the same as inducing the topology from `X` directly.
-/
theorem Munkres_exercise_16_1_corrected {X : Type*} [TopologicalSpace X]
    (Y : Set X) (A : Set Y) :
    IsInducing (fun a : A => (a : X)) := by
  -- Step 1: By definition, `Inducing` asks us to identify the topology on `A`
  --         with the topology induced from `X` through the composite inclusion.
  refine ⟨?_⟩
  -- Step 2: Expand both topologies using `Subtype.instTopologicalSpaceSubtype`
  --         and combine them with `induced_compose`.
  -- Step 3: Observe that the composite `Subtype.val ∘ Subtype.val`
  --         is the function `fun a : A => (a : X)`.
  change
      TopologicalSpace.induced (Subtype.val : A → Y)
          (TopologicalSpace.induced (Subtype.val : Y → X) inferInstance)
        =
        TopologicalSpace.induced (fun a : A => (a : X)) inferInstance
  simpa [Function.comp] using
    (induced_compose
      (tγ := inferInstance)
      (f := (Subtype.val : A → Y))
      (g := (Subtype.val : Y → X)))
