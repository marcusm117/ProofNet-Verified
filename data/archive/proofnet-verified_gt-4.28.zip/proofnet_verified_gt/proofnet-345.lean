import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that the Cauchy product of two absolutely convergent series converges absolutely.
-/

/-Informal Proof

Since both the hypothesis and conclusion refer to absolute convergence, we may assume both series consist of nonnegative terms. We let $S_n=\sum_{k=0}^n a_n, T_n=\sum_{k=0}^n b_n$, and $U_n=\sum_{k=0}^n \sum_{l=0}^k a_l b_{k-l}$. We need to show that $U_n$ remains bounded, given that $S_n$ and $T_n$ are bounded. To do this we make the convention that $a_{-1}=T_{-1}=0$, in order to save ourselves from having to separate off the first and last terms when we sum by parts. We then have
$$
\begin{aligned}
U_n &=\sum_{k=0}^n \sum_{l=0}^k a_l b_{k-l} \\
&=\sum_{k=0}^n \sum_{l=0}^k a_l\left(T_{k-l}-T_{k-l-1}\right) \\
&=\sum_{k=0}^n \sum_{j=0}^k a_{k-j}\left(T_j-T_{j-1}\right) \\
&=\sum_{k=0}^n \sum_{j=0}^k\left(a_{k-j}-a_{k-j-1}\right) T_j \\
&=\sum_{j=0}^n \sum_{k=j}^n\left(a_{k-j}-a_{k-j-1}\right) T_j
&=\sum_{j=0}^n a_{n-j} T_j \\
&\leq T \sum_{m=0}^n a_m \\
&=T S_n \\
&\leq S T .
\end{aligned}
$$
Thus $U_n$ is bounded, and hence approaches a finite limit.
-/

theorem Rudin_exercise_3_13
  (a b : ℕ → ℝ)
  (ha : ∃ y, (Tendsto (λ n => (∑ i ∈ (range n), |a i|)) atTop (𝓝 y)))
  (hb : ∃ y, (Tendsto (λ n => (∑ i ∈ (range n), |b i|)) atTop (𝓝 y))) :
  ∃ y, (Tendsto (λ n => (∑ i ∈ (range n),
  λ i => (∑ j ∈ range (i + 1), a j * b (i - j)))) atTop (𝓝 y)) := by
  sorry

/-! ## Refutation
The original statement `Rudin_exercise_3_13` is false: `Rudin_exercise_3_13_neg` proves the negation of its elaborated type. -/
theorem Rudin_exercise_3_13_neg : ¬ (type_of% @Rudin_exercise_3_13) := by
  -- Step 0: The conclusion sums the *function* `c := fun i => ∑ j ∈ range (i+1), a j * b (i-j)`
  -- (the inner `λ i` shadows the summation index), so the partial sums are `n • c` in `ℕ → ℝ`.
  -- We take `a = b = d`, the indicator of `0`; then `c 0 = 1`, and coordinate `0` is `n ↦ n`.
  intro h
  -- Step 1: Define the counterexample sequence `d = δ₀`.
  set d : ℕ → ℝ := fun i => if i = 0 then 1 else 0 with hd
  -- Step 2: The absolute partial sums of `d` are eventually equal to `1`, hence converge.
  have hsum : ∃ y, Tendsto (fun n => ∑ i ∈ range n, |d i|) atTop (𝓝 y) := by
    refine ⟨1, tendsto_const_nhds.congr' ?_⟩
    filter_upwards [eventually_ge_atTop 1] with n hn
    -- Step 2.1: Only the `i = 0` term of the sum is nonzero.
    rw [Finset.sum_eq_single 0]
    · simp [hd]
    · intro i _ hi; simp [hd, hi]
    · intro h0; exact absurd (Finset.mem_range.2 hn) h0
  -- Step 3: Apply the (false) statement to `a = b = d`.
  obtain ⟨y, hy⟩ := h d d hsum hsum
  -- Step 4: Evaluation at `0` is continuous, so coordinate `0` of the partial sums converges.
  have h0 := (continuous_apply 0).continuousAt.tendsto.comp hy
  -- Step 5: Coordinate `0` of the `n`-th partial sum is `n * (d 0 * d 0) = n`.
  have : (fun n : ℕ => (∑ i ∈ range n, fun i => ∑ j ∈ range (i + 1), d j * d (i - j)) 0)
      = fun n : ℕ => (n : ℝ) := by
    funext n
    simp [Finset.sum_apply, hd]
  rw [Function.comp_def, this] at h0
  -- Step 6: But `n ↦ (n : ℝ)` tends to `+∞`, so it cannot converge to a finite limit.
  exact not_tendsto_atTop_of_tendsto_nhds h0 tendsto_natCast_atTop_atTop

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

/-
Corrected statement:
Step 0: Clarify that the absolute value inside the final sum must be applied to the scalar term
`∑ j ∈ range (i + 1), a j * b (i - j)` instead of the whole constant function.
Step 0.1: With that change the conclusion states that the sequence of partial sums of absolute
values of the Cauchy product is convergent, i.e. that the Cauchy product is absolutely convergent.
Step 0.2: The following section proves this corrected statement directly from the hypotheses that
the series of `|a|` and `|b|` converge.
-/

section CorrectedStatement

open scoped BigOperators

lemma convolution_abs_le (a b : ℕ → ℝ) (n : ℕ) :
    |∑ j ∈ range (n + 1), a j * b (n - j)|
      ≤ ∑ j ∈ range (n + 1), |a j| * |b (n - j)| := by
  -- Step 1: use the triangle inequality on each partial Cauchy product.
  simpa [abs_mul] using
    Finset.abs_sum_le_sum_abs (fun j => a j * b (n - j)) (range (n + 1))

theorem Rudin_exercise_3_13_corrected
   (a b : ℕ → ℝ)
   (ha : ∃ y, Tendsto (fun n => ∑ i ∈ range n, |a i|) atTop (𝓝 y))
   (hb : ∃ y, Tendsto (fun n => ∑ i ∈ range n, |b i|) atTop (𝓝 y)) :
   ∃ y,
     Tendsto
       (fun n =>
         ∑ i ∈ range n,
           |∑ j ∈ range (i + 1), a j * b (i - j)|)
       atTop (𝓝 y) := by
  -- Step 2: reduce the problem to the absolute Cauchy product of nonnegative sequences.
  classical
  have hSummAbsA : Summable fun n => |a n| :=
    summable_of_absolute_convergence_real (by simpa using ha)
  have hSummAbsB : Summable fun n => |b n| :=
    summable_of_absolute_convergence_real (by simpa using hb)
  -- Step 2.1: the convolution of the absolute values is summable.
  have hSummConv :
      Summable fun n =>
        ∑ k ∈ range (n + 1), |a k| * |b (n - k)| := by
    have hSummNorm :=
      summable_norm_sum_mul_range_of_summable_norm
        (f := fun n => |a n|) (g := fun n => |b n|)
        (hf := by simpa [Real.norm_eq_abs] using hSummAbsA)
        (hg := by simpa [Real.norm_eq_abs] using hSummAbsB)
    simpa using
      (Summable.of_norm hSummNorm :
        Summable fun n => ∑ k ∈ range (n + 1), |a k| * |b (n - k)|)
  -- Step 2.2: dominate the absolute values of the actual Cauchy product.
  have hSummAbs :
      Summable fun n =>
        |∑ k ∈ range (n + 1), a k * b (n - k)| := by
    refine Summable.of_nonneg_of_le (fun _ => abs_nonneg _) (fun n => convolution_abs_le a b n) ?_
    exact hSummConv
  -- Step 2.3: convert summability into the desired limit statement.
  refine ⟨∑' n, |∑ k ∈ range (n + 1), a k * b (n - k)|, ?_⟩
  have hlimit := hSummAbs.hasSum.tendsto_sum_nat
  simpa using hlimit

end CorrectedStatement
