import Mathlib


open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators InnerProductSpace

/-Informal Statement

Suppose $S, T \in \mathcal{L}(V)$. Prove that $S T$ and $T S$ have the same eigenvalues.
-/

/-Informal Proof

To start, let $\lambda \in F$ be an eigenvalue of $S T$. Now, we would want $\lambda$ to be an eigenvalue of $T S$. Since $\lambda$, by itself, is an eigenvalue of $S T$, then there has to be a nonzero vector $v \in V$ such that $(S T) v=\lambda v$.
Now, With a given reference that $(S T) v=\lambda v$, you will then have the following: $(T S)(T v)=$ $T(S T v)=T(\lambda v)=\lambda T v$
If $T v \neq 0$, then the listed equation above shows that $\lambda$ is an eigenvalue of $T S$.
If $T v=0$, then $\lambda=0$, since $S(T v)=\lambda T v$. This also means that $T$ isn't invertible, which would imply that $T S$ isn't invertible, which can also be implied that $\lambda$, which equals 0 , is an eigenvalue of $T S$.
Step 3
3 of 3
Now, regardless of whether $T v=0$ or not, we would have shown that $\lambda$ is an eigenvalue of $T S$. Since $\lambda$ (was) an arbitrary eigenvalue of $S T$, we have shown that every single eigenvalue of $S T$ is an eigenvalue of $T S$. When you do reverse the roles of both $S$ and $T$, then we can conclude that that every single eigenvalue of $T S$ is also an eigenvalue of $S T$. Therefore, both $S T$ and $T S$ have the exact same eigenvalues.
-/

theorem Axler_exercise_5_11 {F V : Type*} [AddCommGroup V] [Field F]
  [Module F V] (S T : End F V) :
  (S * T).Eigenvalues = (T * S).Eigenvalues := by
  sorry

/-! ### Counterexample: the two unilateral shifts on `ℕ → G`

The informal statement is a theorem about *finite-dimensional* spaces (Axler's book
works over finite-dimensional `V` throughout).  The formalization dropped that
hypothesis.  In infinite dimensions `S * T` and `T * S` share all *nonzero*
eigenvalues, but `0` is an eigenvalue of `S * T` exactly when `S * T` fails to be
injective, and that is not symmetric in `S` and `T`.

Concretely, on the sequence space `V = ℕ → G` take
* `L` = left shift,  `(L x) n = x (n + 1)`;
* `R` = right shift, `(R x) 0 = 0`, `(R x) (m + 1) = x m`.

Then `L * R = 1`, whose only eigenvalue is `1`, while `R * L` is the projection
killing the `0`-th coordinate, which has both `0` and `1` as eigenvalues.  Hence
`(L * R).Eigenvalues` is a subsingleton whereas `(R * L).Eigenvalues` has two
distinct elements, so the two *types* are not equal. -/

/-- The left shift `(x n) ↦ (x (n+1))` as an `F`-linear endomorphism of `ℕ → G`. -/
def leftShift203 (F G : Type*) [Field F] [AddCommGroup G] [Module F G] :
    Module.End F (ℕ → G) where
  toFun x := fun n => x (n + 1)
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-- The right shift `(x n) ↦ (0, x 0, x 1, …)` as an `F`-linear endomorphism of `ℕ → G`. -/
def rightShift203 (F G : Type*) [Field F] [AddCommGroup G] [Module F G] :
    Module.End F (ℕ → G) where
  toFun x := fun n => match n with | 0 => 0 | m + 1 => x m
  map_add' x y := by funext n; cases n <;> simp
  map_smul' c x := by funext n; cases n <;> simp

/-- Step A: `L * R = 1`.  Indeed `(L (R x)) n = (R x) (n+1) = x n`. -/
theorem leftShift_mul_rightShift203 (F G : Type*) [Field F] [AddCommGroup G] [Module F G] :
    leftShift203 F G * rightShift203 F G = 1 := by
  apply LinearMap.ext
  intro x
  funext n
  rfl

/-- Step B: `(R * L) x` vanishes at index `0`. -/
theorem rightShift_mul_leftShift203_zero (F G : Type*) [Field F] [AddCommGroup G] [Module F G]
    (x : ℕ → G) : (rightShift203 F G * leftShift203 F G) x 0 = 0 := rfl

/-- Step C: `(R * L) x` agrees with `x` at every positive index. -/
theorem rightShift_mul_leftShift203_succ (F G : Type*) [Field F] [AddCommGroup G] [Module F G]
    (x : ℕ → G) (m : ℕ) : (rightShift203 F G * leftShift203 F G) x (m + 1) = x (m + 1) := rfl

/-- **The refutation, in a form applicable to any nontrivial module.**
If the statement of `Axler_exercise_5_11` held for `V = ℕ → G` with `G ≠ 0`,
we would get a contradiction. -/
theorem shifts_refute203 {F G : Type*} [Field F] [AddCommGroup G] [Module F G]
    (g : G) (hg : g ≠ 0)
    (H : ∀ S T : Module.End F (ℕ → G), (S * T).Eigenvalues = (T * S).Eigenvalues) :
    False := by
  -- Step 1: abbreviations for the two shifts.
  set L := leftShift203 F G with hL
  set R := rightShift203 F G with hR
  -- Step 2: the only eigenvalue of the identity is `1`.
  have key : ∀ μ : F, (1 : Module.End F (ℕ → G)).HasEigenvalue μ → μ = 1 := by
    intro μ hμ
    -- Step 2.1: pick an eigenvector `v ≠ 0` with `1 v = μ • v`, i.e. `v = μ • v`.
    obtain ⟨v, hv, hv0⟩ := hμ.exists_hasEigenvector
    rw [Module.End.mem_eigenspace_iff] at hv
    have hvv : v = μ • v := by simpa using hv
    -- Step 2.2: if `μ ≠ 1` then `1 - μ` is invertible and kills `v`, forcing `v = 0`.
    by_contra hne
    apply hv0
    have hsub : (1 : F) - μ ≠ 0 := sub_ne_zero.mpr fun hc => hne hc.symm
    have h0 : ((1 : F) - μ) • v = 0 := by
      rw [sub_smul, one_smul, ← hvv]
      simp
    calc v = ((1 : F) - μ)⁻¹ • (((1 : F) - μ) • v) := by
              rw [smul_smul, inv_mul_cancel₀ hsub, one_smul]
      _ = 0 := by rw [h0, smul_zero]
  -- Step 3: `0` is an eigenvalue of `R * L`, witnessed by `Pi.single 0 g`.
  have hz : (R * L).HasEigenvalue 0 := by
    apply Module.End.hasEigenvalue_of_hasEigenvector (x := Pi.single 0 g)
    constructor
    · -- Step 3.1: `(R * L) (Pi.single 0 g) = 0 = (0 : F) • Pi.single 0 g`.
      rw [Module.End.mem_eigenspace_iff]
      funext n
      cases n with
      | zero => rw [hR, hL, rightShift_mul_leftShift203_zero]; simp
      | succ m =>
          rw [hR, hL, rightShift_mul_leftShift203_succ]
          simp
    · -- Step 3.2: `Pi.single 0 g ≠ 0` because `g ≠ 0`.
      intro hc
      exact hg (by simpa using congrFun hc 0)
  -- Step 4: `1` is an eigenvalue of `R * L`, witnessed by `Pi.single 1 g`.
  have ho : (R * L).HasEigenvalue 1 := by
    apply Module.End.hasEigenvalue_of_hasEigenvector (x := Pi.single 1 g)
    constructor
    · -- Step 4.1: `Pi.single 1 g` vanishes at `0`, so `R * L` fixes it.
      rw [Module.End.mem_eigenspace_iff]
      funext n
      cases n with
      | zero => rw [hR, hL, rightShift_mul_leftShift203_zero]; simp
      | succ m =>
          rw [hR, hL, rightShift_mul_leftShift203_succ]
          simp
    · -- Step 4.2: `Pi.single 1 g ≠ 0` because `g ≠ 0`.
      intro hc
      exact hg (by simpa using congrFun hc 1)
  -- Step 5: instantiate the (alleged) theorem at `S = L`, `T = R` and simplify `L * R` to `1`.
  have h := H L R
  rw [hL, hR, leftShift_mul_rightShift203] at h
  -- Step 6: the eigenvalue type of the identity is a subsingleton, by Step 2.
  have hsub : Subsingleton ((1 : Module.End F (ℕ → G)).Eigenvalues) := by
    constructor
    rintro ⟨a, ha⟩ ⟨b, hb⟩
    exact Subtype.ext ((key a ha).trans (key b hb).symm)
  -- Step 7: transporting along `h` collapses the two distinct eigenvalues `0 ≠ 1`.
  have e := Equiv.cast h
  have heq : (⟨0, hz⟩ : (R * L).Eigenvalues) = ⟨1, ho⟩ :=
    e.symm.injective (Subsingleton.elim _ _)
  have h01 : (0 : F) = 1 := congrArg Subtype.val heq
  exact zero_ne_one h01

/-! ## Refutation
The original statement `Axler_exercise_5_11` is false: `Axler_exercise_5_11_neg` proves the negation of its elaborated type. -/
theorem Axler_exercise_5_11_neg : ¬ (type_of% @Axler_exercise_5_11) := by
  -- Step 8: instantiate at `F = ULift ℚ` and `V = ℕ → ULift ℚ`, both `ULift`ed so
  -- that they inhabit the (arbitrary, independent) universes of the statement.
  intro h
  exact shifts_refute203 (F := ULift ℚ) (G := ULift ℚ) 1 one_ne_zero (fun S T => h S T)


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators

/-
### Corrected statement (with the missing hypothesis restored)

If `V` is finite-dimensional, then `S*T` and `T*S` do have exactly the
same eigenvalues; the characteristic polynomials coincide by the
standard matrix identity `charpoly (AB) = charpoly (BA)`, and eigenvalues
are precisely the roots of the characteristic polynomial.
-/
theorem Axler_exercise_5_11_corrected {F V : Type*} [Field F] [AddCommGroup V]
    [Module F V] [FiniteDimensional F V] (S T : End F V) :
    (S * T).Eigenvalues = (T * S).Eigenvalues := by
  classical
  -- Step 1: Reduce to the characteristic polynomial identity via matrices.
  have h_charpoly :
      (S * T).charpoly = (T * S).charpoly := by
    -- Step 1.1: Work in a convenient finite basis.
    let b := Module.finBasis F V
    -- Step 1.2: Compare the characteristic polynomials via matrices.
    have hmat :
        (LinearMap.toMatrix b b (S * T)).charpoly =
          (LinearMap.toMatrix b b (T * S)).charpoly := by
      calc
        (LinearMap.toMatrix b b (S * T)).charpoly
            = (LinearMap.toMatrix b b S * LinearMap.toMatrix b b T).charpoly := by
              simp [LinearMap.toMatrix_mul]
        _ = (LinearMap.toMatrix b b T * LinearMap.toMatrix b b S).charpoly :=
            Matrix.charpoly_mul_comm _ _
        _ = (LinearMap.toMatrix b b (T * S)).charpoly := by
              simp [LinearMap.toMatrix_mul]
    -- Step 1.3: Use `charpoly_toMatrix` to translate back to linear maps.
    calc
      (S * T).charpoly
          = (LinearMap.toMatrix b b (S * T)).charpoly := by
              simp [LinearMap.charpoly_toMatrix (f := S * T) (b := b)]
      _ = (LinearMap.toMatrix b b (T * S)).charpoly := hmat
      _ = (T * S).charpoly := by
              simp [LinearMap.charpoly_toMatrix (f := T * S) (b := b)]
  -- Step 2: Equate the eigenvalue predicates using the root characterization.
  have h_pred :
      (fun μ : F => (S * T).HasEigenvalue μ) =
      (fun μ : F => (T * S).HasEigenvalue μ) := by
    funext μ
    apply propext
    -- Step 2.1: Eigenvalues are exactly the roots of the characteristic polynomial.
    have hST :=
      (Module.End.hasEigenvalue_iff_isRoot_charpoly (f := S * T) (μ := μ))
    have hTS :=
      (Module.End.hasEigenvalue_iff_isRoot_charpoly (f := T * S) (μ := μ))
    -- Step 2.2: Rewrite using the characteristic-polynomial identity.
    constructor
    · intro hμ
      have hroot : (S * T).charpoly.IsRoot μ := (hST.mp hμ)
      have hroot' : (T * S).charpoly.IsRoot μ := by
        simpa [h_charpoly] using hroot
      exact hTS.mpr hroot'
    · intro hμ
      have hroot : (T * S).charpoly.IsRoot μ := (hTS.mp hμ)
      have hroot' : (S * T).charpoly.IsRoot μ := by
        simpa [h_charpoly] using hroot
      exact hST.mpr hroot'
  -- Step 3: Equality of predicates gives equality of the bundled eigenvalue subtypes.
  have h_pred_unif :
      (fun μ : F => HasUnifEigenvalue (S * T) μ 1) =
      (fun μ : F => HasUnifEigenvalue (T * S) μ 1) := by
    simpa [HasEigenvalue] using h_pred
  simp [Eigenvalues, UnifEigenvalues, h_pred_unif]
