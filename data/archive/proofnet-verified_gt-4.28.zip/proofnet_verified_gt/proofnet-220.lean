import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $G$ be a finite group which possesses an automorphism $\sigma$ such that $\sigma(g)=g$ if and only if $g=1$. If $\sigma^{2}$ is the identity map from $G$ to $G$, prove that $G$ is abelian.
-/

/-Informal Proof

Solution: We define a mapping $f: G \rightarrow G$ by $f(x)=x^{-1} \sigma(x)$.
Claim: $f$ is injective.
Proof of claim: Suppose $f(x)=f(y)$. Then $y^{-1} \sigma(y)=x^{-1} \sigma(x)$, so that $x y^{-1}=\sigma(x) \sigma\left(y^{-1}\right)$, and $x y^{-1}=\sigma\left(x y^{-1}\right)$. Then we have $x y^{-1}=1$, hence $x=y$. So $f$ is injective.

Since $G$ is finite and $f$ is injective, $f$ is also surjective. Then every $z \in G$ is of the form $x^{-1} \sigma(x)$ for some $x$. Now let $z \in G$ with $z=x^{-1} \sigma(x)$. We have
$$
\sigma(z)=\sigma\left(x^{-1} \sigma(x)\right)=\sigma(x)^{-1} x=\left(x^{-1} \sigma(x)\right)^{-1}=z^{-1} .
$$
Thus $\sigma$ is in fact the inversion mapping, and we assumed that $\sigma$ is a homomorphism. By a previous example, then, $G$ is abelian.
-/

theorem Dummit_Foote_exercise_1_6_23 {G : Type*}
  [Group G] (σ : MulAut G) (hs : ∀ g : G, σ g = 1 → g = 1)
  (hs2 : ∀ g : G, σ (σ g) = g) :
  ∀ x y : G, x*y = y*x := by
  sorry

/-! ## Refutation
The original statement `Dummit_Foote_exercise_1_6_23` is false: `Dummit_Foote_exercise_1_6_23_neg` proves the negation of its elaborated type. -/

/-
### Why the formalization is false

The informal exercise assumes that `σ` is *fixed-point free*: `σ g = g → g = 1`.
The Lean hypothesis `hs` instead says `σ g = 1 → g = 1`, which holds for *every*
automorphism (an automorphism is injective and sends `1` to `1`), so it carries
no information at all.  The finiteness of `G` is dropped as well.

What is left is the claim "every group carrying an involutive automorphism is
abelian", and the *identity* automorphism is involutive on any group.  So any
nonabelian group refutes the statement; we take the smallest one,
`G = Equiv.Perm (Fin 3)`, together with `σ = 1`.
-/

/-- Step A: two permutations of `Fin 3` that do not commute.
`Equiv.Perm (Fin 3)` has decidable equality and computable multiplication,
so the inequality is settled by `decide`. -/
theorem perm_fin_three_not_comm :
    Equiv.swap (0 : Fin 3) 1 * Equiv.swap (1 : Fin 3) 2
      ≠ Equiv.swap (1 : Fin 3) 2 * Equiv.swap (0 : Fin 3) 1 := by
  decide

theorem Dummit_Foote_exercise_1_6_23_neg : ¬ (type_of% @Dummit_Foote_exercise_1_6_23) := by
  -- Step 1: assume the general statement.
  intro h
  -- Step 2: choose the counterexample group.
  --   The negated statement is universe polymorphic (`G : Type u_1`), while
  --   `Equiv.Perm (Fin 3)` lives in `Type 0`, so we lift it with `ULift`:
  --   `ULift (Equiv.Perm (Fin 3)) : Type u_1`.  `ULift` of a group is a group,
  --   isomorphic to the original one, hence still nonabelian.
  -- Step 3: instantiate `h` at that group with `σ = 1`, the identity automorphism.
  --   Step 3.1: `hs` — since `(1 : MulAut G) g = g`, the hypothesis reads
  --     `g = 1 → g = 1`, which is trivially true.  This is exactly the defect of
  --     the formalization: `hs` should have been `σ g = g → g = 1`.
  --   Step 3.2: `hs2` — `(1 : MulAut G) ((1 : MulAut G) g) = g` is immediate.
  have hcomm := h (G := ULift (Equiv.Perm (Fin 3))) (1 : MulAut (ULift (Equiv.Perm (Fin 3))))
    (fun g hg => by simpa using hg) (fun g => by simp)
  -- Step 4: the conclusion claims all elements commute; feed it the two swaps.
  have hxy := hcomm (ULift.up (Equiv.swap (0 : Fin 3) 1)) (ULift.up (Equiv.swap (1 : Fin 3) 2))
  -- Step 5: push the equality down through `ULift.down` to get a contradiction
  -- with Step A.
  exact perm_fin_three_not_comm (by simpa using congrArg ULift.down hxy)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

/-
With the missing finiteness assumption reinstated, the classical proof works:
`σ` must agree with inversion, which is a group automorphism precisely when the
group is abelian.  The next theorem formalizes this corrected statement.
-/

theorem Dummit_Foote_exercise_1_6_23_corrected {G : Type*} [Group G] [Finite G]
    (σ : MulAut G) (hs : ∀ g : G, σ g = g ↔ g = 1)
    (hs2 : ∀ g : G, σ (σ g) = g) :
    ∀ x y : G, x * y = y * x := by
  -- Step 1: view `σ` as the associated monoid homomorphism.
  let φ : G →* G := σ.toMonoidHom
  -- Step 2: verify that `φ` is fixed-point-free in the `MonoidHom` sense.
  have hfree : MonoidHom.FixedPointFree φ := by
    -- Step 2.1: transfer the given equivalence to the required implication.
    intro g hg
    exact (hs g).1 hg
  -- Step 3: express involutivity as a statement about the underlying function.
  have hinv : Function.Involutive φ := by
    -- Step 3.1: `hs2` already states the needed property.
    intro g
    simpa using hs2 g
  -- Step 4: commute any two elements using the dedicated lemma.
  intro x y
  -- Step 4.1: specialize the commuting statement to `x` and `y`.
  have hx :
      Commute x y :=
    MonoidHom.FixedPointFree.commute_all_of_involutive
      (φ := φ) hfree hinv x y
  -- Step 4.2: rewrite `Commute` as the desired equality.
  simpa using hx
