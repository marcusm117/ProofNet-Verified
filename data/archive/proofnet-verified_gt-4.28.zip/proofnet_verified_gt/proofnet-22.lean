import Mathlib


open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators InnerProductSpace

/-Informal Statement

Suppose $u, v \in V$. Prove that $\langle u, v\rangle=0$ if and only if $\|u\| \leq\|u+a v\|$ for all $a \in \mathbf{F}$.
-/

/-Informal Proof

First off, let us suppose that $(u, v)=0$.
Now, let $a \in \mathbb{F}$. Next, $u, a v$ are orthogonal.
The Pythagorean theorem thus implies that
$$
\begin{aligned}
\|u+a v\|^2 & =\|u\|^2+\|a v\|^2 \\
& \geq\|u\|^2
\end{aligned}
$$
So, by taking the square roots, this will now give us $\|u\| \leq\|u+a v\|$.
Now, to prove the implication in the other direction, we must now let $\|u\| \leq$ $\|u+a v\|$ for all $a \in \mathbb{F}$. Squaring this inequality, we get both:
$$
\begin{gathered}
\|u\|^2 a n d \leq\|u+a v\|^2 \\
=(u+a v, u+a v) \\
=(u, u)+(u, a v)+(a v, u)+(a v, a v) \\
=\|u\|^2+\bar{a}(u, v)+a \overline{(u, v)}+|a|^2\|v\|^2 \\
\|u\|^2+2 \Re \bar{a}(u, v)+|a|^2\|v\|^2
\end{gathered}
$$
for all $a \in \mathbb{F}$.
Therefore,
$$
-2 \Re \bar{a}(u, v) \leq|a|^2\|v\|^2
$$
for all $a \in \mathbb{F}$. In particular, we can let $a$ equal $-t(u, v)$ for $t>0$. Substituting this value for $a$ into the inequality above gives
$$
2 t|(u, v)|^2 \leq t^2|(u, v)|^2\|v\|^2
$$
for all $t>0$.
Step 4
4 of 4
Divide both sides of the inequality above by $t$, getting
$$
2|(u, v)|^2 \leq t \mid(u, v)^2\|v\|^2
$$
for all $t>0$. If $v=0$, then $(u, v)=0$, as desired. If $v \neq 0$, set $t$ equal to $1 /\|v\|^2$ in the inequality above, getting
$$
2|(u, v)|^2 \leq|(u, v)|^2,
$$
which implies that $(u, v)=0$.
-/

theorem Axler_exercise_6_2 {V : Type*} [NormedAddCommGroup V] [Module ℂ V]
[InnerProductSpace ℂ V] (u v : V) :
  ⟪u, v⟫_ℂ = 0 ↔ ∀ (a : ℂ), ‖u‖  ≤ ‖u + a • v‖ := by
  sorry

/-! ### Why the statement above is false as elaborated

The binder `[Module ℂ V]` is declared *before* `[InnerProductSpace ℂ V]`, and it is that binder
which supplies the scalar action used by `a • v` (the elaborated statement contains
`@HSMul.hSMul ℂ V V _ a v` with the `SMul` coming from the `Module ℂ V` binder, not from
`InnerProductSpace.toNormedSpace.toModule`).  So `•` is an *arbitrary* `ℂ`-module structure on the
additive group `V`, totally unrelated to the norm `‖·‖` and the inner product `⟪·,·⟫_ℂ` (which do
come from the `NormedAddCommGroup`/`InnerProductSpace` binders).  The intended mathematical
statement — where `•` is the inner product space action — is true; the statement below is not.

Counterexample.  Take `V = ℂ × ℂ` with its usual L2 inner product (`WithLp 2 (ℂ × ℂ)`, lifted to an
arbitrary universe by `ULift`), `u = (1, 0)`, `v = (0, 1)`, so that `⟪u, v⟫_ℂ = 0`.  For the rogue
`Module ℂ V` binder transport the standard action along the additive involution
`S (x, y) = (⟨x.re, y.re⟩, ⟨x.im, y.im⟩)` of `ℂ × ℂ` (i.e. use the *second* complex structure
`J (x, y) = (-y, x)` of `ℝ⁴`).  Then `I •' v = S (I * S v) = S (I * (I, 0)) = S (-1, 0) = (-1, 0)`,
i.e. `I •' v = -u`, hence `‖u + I •' v‖ = 0 < 1 = ‖u‖` and the forward implication fails. -/

/-- Step 1: the additive involution `S (x, y) = (⟨x.re, y.re⟩, ⟨x.im, y.im⟩)` of `ℂ × ℂ`.
It is additive (real and imaginary parts are additive) and an involution, but it is *not*
`ℂ`-linear, which is exactly what makes the transported module structure rogue. -/
def axler62_S : (ℂ × ℂ) ≃+ (ℂ × ℂ) where
  toFun z := (⟨z.1.re, z.2.re⟩, ⟨z.1.im, z.2.im⟩)
  invFun z := (⟨z.1.re, z.2.re⟩, ⟨z.1.im, z.2.im⟩)
  left_inv z := by ext <;> simp
  right_inv z := by ext <;> simp
  map_add' z w := by ext <;> simp [Complex.ext_iff]

/-- Step 2: the carrier, `ℂ × ℂ` with its standard L2 norm and inner product. -/
abbrev axler62_W : Type := WithLp 2 (ℂ × ℂ)

/-- Step 3: an additive equivalence `ULift axler62_W ≃+ (ℂ × ℂ)` which is *not* `ℂ`-linear:
it forgets the `ULift`/`WithLp` wrappers and then applies the involution `axler62_S`.
The `ULift` is needed only because the negated statement is universe polymorphic, so the
counterexample must be produced in an arbitrary universe `u`. -/
noncomputable def axler62_e.{u} : ULift.{u} axler62_W ≃+ (ℂ × ℂ) :=
  (AddEquiv.ulift).trans (((WithLp.linearEquiv 2 ℂ (ℂ × ℂ)).toAddEquiv).trans axler62_S)

/-- Step 4: the rogue `ℂ`-module structure on the additive group of `ULift axler62_W`,
obtained by transporting the standard one along `axler62_e`; concretely
`a •' x = axler62_e.symm (a • axler62_e x)`.  The additive group (hence the norm and the inner
product) is untouched; only the scalar action changes. -/
noncomputable def axler62_rogue.{u} : Module ℂ (ULift.{u} axler62_W) :=
  AddEquiv.module ℂ axler62_e.{u}

/-- Step 5: the *standard* inner product space structure on `ULift axler62_W`, obtained
coordinatewise from the one on `axler62_W` (Mathlib has no `ULift` instance, so we build it).
Note its scalar action is the standard `ULift` one, **not** the rogue action of Step 4. -/
noncomputable def axler62_ips.{u} : InnerProductSpace ℂ (ULift.{u} axler62_W) :=
  { (inferInstance : NormedSpace ℂ (ULift.{u} axler62_W)) with
    inner := fun x y => inner ℂ x.down y.down
    norm_sq_eq_re_inner := fun x => InnerProductSpace.norm_sq_eq_re_inner (𝕜 := ℂ) x.down
    conj_inner_symm := fun x y => InnerProductSpace.conj_inner_symm (𝕜 := ℂ) x.down y.down
    add_left := fun x y z => InnerProductSpace.add_left (𝕜 := ℂ) x.down y.down z.down
    smul_left := fun x y r => InnerProductSpace.smul_left (𝕜 := ℂ) x.down y.down r }

/-- Step 6: the two vectors `u = (1, 0)` and `v = (0, 1)`; they are orthogonal for the
standard inner product of Step 5. -/
def axler62_u.{u} : ULift.{u} axler62_W := ULift.up (WithLp.toLp 2 ((1 : ℂ), (0 : ℂ)))

def axler62_v.{u} : ULift.{u} axler62_W := ULift.up (WithLp.toLp 2 ((0 : ℂ), (1 : ℂ)))

/-- Step 7: the key computation `I •' v = -u` for the rogue action of Step 4:
`axler62_e v = S (0, 1) = (I, 0)`, then `I * (I, 0) = (-1, 0)`, and `S (-1, 0) = (-1, 0)`. -/
theorem axler62_smul_eq.{u} :
    (axler62_e.{u}).symm (Complex.I • axler62_e.{u} axler62_v.{u}) = - axler62_u.{u} := by
  -- Step 7.1: unfold every wrapper; `simp` computes the two applications of `axler62_S`.
  simp [axler62_e, axler62_S, axler62_u, axler62_v, AddEquiv.ulift, ULift.ext_iff]
  -- Step 7.2: the leftover goal is `(⟨-1, 0⟩, ⟨0, 0⟩) = -(1, 0)` inside `WithLp 2 (ℂ × ℂ)`.
  rw [← WithLp.toLp_neg]
  simp [Prod.ext_iff, Complex.ext_iff]

/-- Step 8: the negation, stated for an arbitrary universe `u` (this is exactly the statement of
`Axler_exercise_6_2_neg` below, with the universe parameter made explicit). -/
theorem axler62_key.{u} :
    ¬ (∀ {V : Type u} [NormedAddCommGroup V] [Module ℂ V] [InnerProductSpace ℂ V] (u v : V),
        ⟪u, v⟫_ℂ = 0 ↔ ∀ (a : ℂ), ‖u‖ ≤ ‖u + a • v‖) := by
  intro h
  -- Step 8.1: instantiate the statement at the counterexample.  The instances are passed
  -- explicitly: the norm/inner product are the standard ones, while the `Module ℂ V` binder
  -- receives the rogue action of Step 4.
  have hiff := @h (ULift.{u} axler62_W) inferInstance axler62_rogue.{u} axler62_ips.{u}
    axler62_u.{u} axler62_v.{u}
  -- Step 8.2: `⟪u, v⟫_ℂ = conj 1 * 0 + conj 0 * 1 = 0`, so the left-hand side holds;
  -- specialise the resulting inequality to `a = I`.
  have hI := hiff.mp (by
      show (inner ℂ (WithLp.toLp 2 ((1 : ℂ), (0 : ℂ)) : axler62_W)
              (WithLp.toLp 2 ((0 : ℂ), (1 : ℂ)))) = 0
      simp) Complex.I
  -- Step 8.3: but `u + I •' v = u + (-u) = 0`, so the inequality reads `‖u‖ ≤ ‖0‖`.
  have hle : ‖axler62_u.{u}‖ ≤ ‖(0 : ULift.{u} axler62_W)‖ := by
    refine le_trans hI (le_of_eq (congrArg norm ?_))
    show axler62_u.{u} + (axler62_e.{u}).symm (Complex.I • axler62_e.{u} axler62_v.{u}) = 0
    rw [axler62_smul_eq]
    simp
  -- Step 8.4: `‖u‖ ≤ 0` forces `u = 0`, contradicting `u = (1, 0) ≠ 0`.
  rw [norm_zero, norm_le_zero_iff] at hle
  simp [axler62_u, ULift.ext_iff, Prod.ext_iff] at hle

/-! ## Refutation
The original statement `Axler_exercise_6_2` is false: `Axler_exercise_6_2_neg` proves the negation of its elaborated type. -/
theorem Axler_exercise_6_2_neg : ¬ (type_of% @Axler_exercise_6_2) := by
  -- Step 9: this is literally Step 8.
  exact axler62_key


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open InnerProductSpace RCLike ContinuousLinearMap Complex
open scoped BigOperators

theorem Axler_exercise_6_2_corrected {V : Type*} [NormedAddCommGroup V] {F : Type*}
    [RCLike F] [InnerProductSpace F V]
    (u v : V) :
    ⟪u, v⟫_F = 0 ↔ ∀ (a : F), ‖u‖ ≤ ‖u + a • v‖ := by
  classical
  constructor
  · -- Step 1: Assume the inner product between `u` and `v` is zero.
    intro hinner a
    -- Step 1.2: Show that `u` is orthogonal to `a • v` by sesquilinearity of the inner product.
    have h_ortho : ⟪u, a • v⟫_F = 0 := by
      -- Step 1.2.1: Rewrite the inner product using linearity in the second component.
      calc
        ⟪u, a • v⟫_F = a * ⟪u, v⟫_F := inner_smul_right (𝕜 := F) u v a
        _ = a * 0 := by simp [hinner]
        _ = 0 := by simp
    -- Step 1.3: Apply the Pythagorean identity to `u` and `a • v`.
    have h_pyth : ‖u + a • v‖ ^ 2 = ‖u‖ ^ 2 + ‖a • v‖ ^ 2 := by
      -- Step 1.3.1: Convert the multiplicative form supplied by Mathlib to the additive form we want.
      have := norm_add_sq_eq_norm_sq_add_norm_sq_of_inner_eq_zero u (a • v) (by simpa using h_ortho)
      simpa [pow_two] using this
    -- Step 1.4: Use the nonnegativity of squares to bound the right-hand side from below by `‖u‖ ^ 2`.
    have h_sq_le : ‖u‖ ^ 2 ≤ ‖u + a • v‖ ^ 2 := by
      -- Step 1.4.1: The term `‖a • v‖ ^ 2` is nonnegative, so adding it only increases `‖u‖ ^ 2`.
      have h_base : ‖u‖ ^ 2 ≤ ‖u‖ ^ 2 + ‖a • v‖ ^ 2 := le_add_of_nonneg_right (sq_nonneg _)
      -- Step 1.4.2: Replace the sum of squares with `‖u + a • v‖ ^ 2` via the Pythagorean identity.
      simp [h_pyth]
    -- Step 1.5: Translate the inequality on squares back to the statement about norms, using monotonicity of the square root.
    have h_sqrt := Real.sqrt_le_sqrt h_sq_le
    -- Step 1.5.1: Square roots of squared norms collapse back to norms because norms are nonnegative.
    simpa [Real.sqrt_sq, norm_nonneg] using h_sqrt
  · -- Step 2: Assume the norm inequality holds for every scalar and prove the inner product vanishes.
    intro h
    -- Step 2.1: Argue by contradiction and suppose the inner product is nonzero.
    by_contra hinner
    have hinner_ne : ⟪u, v⟫_F ≠ 0 := by simpa using hinner
    -- Step 2.2: Show that `v` itself cannot be zero, otherwise the inner product would vanish immediately.
    have hv : v ≠ 0 := by
      -- Step 2.2.1: If `v = 0`, the right argument of the inner product is zero, contradicting `hinner_ne`.
      intro hv_zero
      have : ⟪u, v⟫_F = 0 := by simp [hv_zero]
      exact hinner this
    -- Step 2.3: Record that the self-inner-product of `v` is nonzero, so the inverse that appears below makes sense.
    have hv_inner : ⟪v, v⟫_F ≠ 0 := (inner_self_ne_zero).2 hv
    -- Step 2.4: Pick the scalar that cancels the component of `u` in the `v`-direction after conjugation.
    set b : F := -⟪u, v⟫_F * (⟪v, v⟫_F)⁻¹ with hb
    set a : F := star b with ha
    -- Step 2.5: Verify that the auxiliary scalars are nonzero (needed to get a strict inequality later).
    have hb_ne : b ≠ 0 := by
      -- Step 2.5.1: Both the numerator and denominator are nonzero, so their product is nonzero as well.
      have hnum : -⟪u, v⟫_F ≠ 0 := neg_ne_zero.mpr hinner_ne
      have hden : (⟪v, v⟫_F)⁻¹ ≠ 0 := inv_ne_zero hv_inner
      simpa [hb] using mul_ne_zero hnum hden
    have ha_ne : a ≠ 0 := by
      -- Step 2.5.2: Conjugation preserves nonvanishing, so take the conjugate to reduce to `hb_ne`.
      intro ha_zero
      have : b = 0 := by
        have h_star_eq : star (star b) = (0 : F) := by
          simpa [ha, star_zero] using congrArg star ha_zero
        simpa [star_star] using h_star_eq
      exact hb_ne this
    -- Step 2.6: Show that `u + a • v` is orthogonal to `v` with this specific choice of `a`.
    have h_conj : star a = b := by simp [ha]
    have h_ortho_v : ⟪u + a • v, v⟫_F = 0 := by
      -- Step 2.6.1: Expand and substitute the chosen scalar to make the cross term disappear.
      calc
        ⟪u + a • v, v⟫_F
            = ⟪u, v⟫_F + ⟪a • v, v⟫_F := by simp [inner_add_left]
        _ = ⟪u, v⟫_F + star a * ⟪v, v⟫_F := by simp [inner_smul_left]
        _ = ⟪u, v⟫_F + b * ⟪v, v⟫_F := by simp [h_conj]
        _ = ⟪u, v⟫_F + (-⟪u, v⟫_F * (⟪v, v⟫_F)⁻¹) * ⟪v, v⟫_F := by simp [hb]
        _ = ⟪u, v⟫_F + (-⟪u, v⟫_F) := by
          -- Step 2.6.1.1: Cancel the invertible factor `⟪v, v⟫` with its inverse.
          congr 1
          rw [mul_assoc, inv_mul_cancel₀ hv_inner, mul_one]
        _ = 0 := by simp
    -- Step 2.7: Evaluate the inequality hypothesis at the special scalar `a`.
    have h_le := h a
    -- Step 2.8: Note that `u` decomposes orthogonally as `(u + a • v) + (-a) • v`.
    have h_ortho_neg : ⟪u + a • v, -a • v⟫_F = 0 := by
      -- Step 2.8.1: Orthogonality survives scaling in the second argument.
      simp [inner_smul_right, h_ortho_v]
    have h_pyth : ‖u‖ ^ 2 = ‖u + a • v‖ ^ 2 + ‖a • v‖ ^ 2 := by
      -- Step 2.8.2: Apply the Pythagorean theorem to the orthogonal decomposition of `u`.
      have := norm_add_sq_eq_norm_sq_add_norm_sq_of_inner_eq_zero (u + a • v) (-a • v) (by
        simpa using h_ortho_neg)
      -- Step 2.8.2.1: Simplify the resulting expression to isolate `‖u‖ ^ 2` on the left.
      simpa [pow_two, add_comm, add_left_comm, add_assoc]
        using this
    -- Step 2.9: Show that the correction term `‖a • v‖ ^ 2` is strictly positive.
    have ha_pos : 0 < ‖a‖ := norm_pos_iff.mpr ha_ne
    have hv_pos : 0 < ‖v‖ := norm_pos_iff.mpr hv
    have h_smul_pos : 0 < ‖a • v‖ := by
      -- Step 2.9.1: Use multiplicativity of the norm to combine `ha_pos` and `hv_pos`.
      simpa [norm_smul] using mul_pos ha_pos hv_pos
    have h_smul_sq_pos : 0 < ‖a • v‖ ^ 2 := sq_pos_of_pos h_smul_pos
    -- Step 2.10: Convert the Pythagorean identity into a strict inequality.
    have h_diff_pos : 0 < ‖u‖ ^ 2 - ‖u + a • v‖ ^ 2 := by
      -- Step 2.10.1: Rearrange `h_pyth` to express the difference as the positive square term.
      have : ‖u‖ ^ 2 - ‖u + a • v‖ ^ 2 = ‖a • v‖ ^ 2 := by
        simp [h_pyth, add_comm, add_assoc, sub_eq_add_neg]
      -- Step 2.10.2: Substitute the strictly positive square obtained above.
      simpa [this] using h_smul_sq_pos
    have h_lt_sq : ‖u + a • v‖ ^ 2 < ‖u‖ ^ 2 := sub_pos.mp h_diff_pos
    -- Step 2.11: Pull the strict inequality on squares back to norms.
    have h_lt_norm : ‖u + a • v‖ < ‖u‖ := by
      -- Step 2.11.1: Compare absolute values using strict monotonicity of squaring on nonnegatives.
      have h_abs_lt : |‖u + a • v‖| < |‖u‖| := (sq_lt_sq).1 h_lt_sq
      -- Step 2.11.2: Norms are nonnegative, so absolute values simplify directly.
      simpa [abs_of_nonneg (norm_nonneg _), abs_of_nonneg (norm_nonneg _)] using h_abs_lt
    -- Step 2.12: Reach the contradiction with the assumed lower bound and finish the proof.
    exact (not_le_of_gt h_lt_norm) h_le
