import Mathlib


open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-Informal Statement

Suppose that $f$ is holomorphic in an open set $\Omega$. Prove that if $\text{Im}(f)$ is constant, then $f$ is constant.
-/

/-Informal Proof

Let $f(z)=f(x, y)=u(x, y)+i v(x, y)$, where $z=x+i y$.
Since $\operatorname{Im}(f)=$ constant,
$$
\frac{\partial v}{\partial x}=0, \frac{\partial v}{\partial y}=0 .
$$
By the Cauchy-Riemann equations,
$$
\frac{\partial u}{\partial x}=\frac{\partial v}{\partial y}=0 .
$$
Thus in $\Omega$,
$$
f^{\prime}(z)=\frac{\partial f}{\partial x}=\frac{\partial u}{\partial x}+i \frac{\partial v}{\partial x}=0+0=0 .
$$
Thus $f$ is constant.
-/

theorem Shakarchi_exercise_1_13b {f : ℂ → ℂ} (Ω : Set ℂ) (a b : Ω) (h : IsOpen Ω)
  (hf : DifferentiableOn ℂ f Ω) (hc : ∃ (c : ℝ), ∀ z ∈ Ω, (f z).im = c) :
  f a = f b := by
  sorry

/-! ## Refutation
The original statement `Shakarchi_exercise_1_13b` is false: `Shakarchi_exercise_1_13b_neg` proves the negation of its elaborated type. -/
theorem Shakarchi_exercise_1_13b_neg : ¬ (type_of% @Shakarchi_exercise_1_13b) := by
  -- Step 0: assume the (universally quantified) statement and derive `False`.
  intro H
  -- Step 1: the counterexample. Ω is the complex plane minus the imaginary axis,
  -- i.e. the disjoint union of the open right and left half-planes (open but NOT connected),
  -- and `f` is the indicator of the right half-plane.
  set Ω : Set ℂ := {z | 0 < z.re} ∪ {z | z.re < 0} with hΩ
  let f : ℂ → ℂ := fun z => if 0 < z.re then 1 else 0
  -- Step 2: Ω is open.
  -- Step 2.1: each half-plane is open (preimage of an open ray under the continuous `re`).
  have hR : IsOpen {z : ℂ | 0 < z.re} := isOpen_lt continuous_const continuous_re
  have hL : IsOpen {z : ℂ | z.re < 0} := isOpen_lt continuous_re continuous_const
  -- Step 2.2: a union of open sets is open.
  have hopen : IsOpen Ω := hR.union hL
  -- Step 3: `f` is holomorphic on Ω, since it is locally constant near every point of Ω.
  have hdiff : DifferentiableOn ℂ f Ω := by
    intro z hz
    apply DifferentiableAt.differentiableWithinAt
    rcases hz with hz | hz
    · -- Step 3.1: near a point of the right half-plane, `f` agrees with the constant `1`.
      have : f =ᶠ[𝓝 z] fun _ => (1 : ℂ) := by
        filter_upwards [hR.mem_nhds hz] with w hw
        simp [f, show 0 < w.re from hw]
      exact (differentiableAt_const _).congr_of_eventuallyEq this
    · -- Step 3.2: near a point of the left half-plane, `f` agrees with the constant `0`.
      have : f =ᶠ[𝓝 z] fun _ => (0 : ℂ) := by
        filter_upwards [hL.mem_nhds hz] with w hw
        have : ¬ (0 < w.re) := not_lt.mpr (le_of_lt (show w.re < 0 from hw))
        simp [f, this]
      exact (differentiableAt_const _).congr_of_eventuallyEq this
  -- Step 4: `Im f` is constantly `0` on Ω (indeed everywhere), since `f` only takes values 0, 1.
  have hc : ∃ c : ℝ, ∀ z ∈ Ω, (f z).im = c := ⟨0, fun z _ => by
    by_cases h : 0 < z.re <;> simp [f, h]⟩
  -- Step 5: pick the two points `a = 1` (right half-plane) and `b = -1` (left half-plane).
  have ha : (1 : ℂ) ∈ Ω := Or.inl (by simp)
  have hb : (-1 : ℂ) ∈ Ω := Or.inr (by simp)
  -- Step 6: the statement would give `f 1 = f (-1)`, i.e. `1 = 0`, a contradiction.
  have := H (f := f) Ω ⟨1, ha⟩ ⟨-1, hb⟩ hopen hdiff hc
  simp [f] at this


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-- A helper lemma for the corrected version: no nonempty subset of a horizontal or vertical line
is open in the complex plane. -/
lemma subset_verticalLine_not_isOpen {c : ℝ} {s : Set ℂ}
    (hs : s ⊆ {z : ℂ | z.im = c}) (hne : s.Nonempty) :
    ¬ IsOpen s := by
  classical
  -- Step 1: Fix a point `w ∈ s` and remember its imaginary part.
  obtain ⟨w, hw⟩ := hne
  have hw_im : w.im = c := by
    have := hs hw
    simpa [Set.mem_setOf_eq] using this
  -- Step 2: Assume `s` is open so that it contains a ball around `w`.
  intro hOpen
  rcases Metric.mem_nhds_iff.1 (hOpen.mem_nhds hw) with ⟨r, hr_pos, hr_ball⟩
  -- Step 3: Move vertically by `r / 2` to obtain a new point inside that ball.
  set w' := w + ((r / 2 : ℝ) : ℂ) * Complex.I
  have hw'_mem : w' ∈ Metric.ball w r := by
    -- Step 3.1: Compute the distance to `w`.
    have hdist : dist w' w = r / 2 := by
      simp [w', dist_eq_norm, Complex.norm_real, Complex.norm_I,
        Real.norm_eq_abs, abs_of_pos hr_pos]
    -- Step 3.2: Compare this distance with `r`.
    have : dist w' w < r := by
      simpa [hdist] using (half_lt_self hr_pos)
    exact Metric.mem_ball.2 this
  have hw'_in_s : w' ∈ s := hr_ball hw'_mem
  -- Step 4: Evaluate the imaginary part of `w'`.
  have hw'_im : w'.im = c + r / 2 := by
    simp [w', hw_im]
  -- Step 5: The equality above contradicts the constraint `hs`.
  have hpos : r / 2 > 0 := half_pos hr_pos
  have hw'_not_mem : w' ∉ {z : ℂ | z.im = c} := by
    -- Step 5.1: `c + r / 2` is strictly larger than `c`.
    have hneq : c + r / 2 ≠ c := by
      have hgt : c + r / 2 > c := by
        have := lt_add_of_pos_right c hpos
        simpa [add_comm] using this
      exact ne_of_gt hgt
    -- Step 5.2: Conclude that `w'.im` cannot equal `c`.
    intro hw'
    have : c + r / 2 = c := by
      simpa [Set.mem_setOf_eq, hw'_im] using hw'
    exact hneq this
  exact hw'_not_mem (hs hw'_in_s)

/-- Corrected statement: on a preconnected open domain, a holomorphic function with constant
imaginary part is globally constant. -/
theorem Shakarchi_exercise_1_13b_corrected {f : ℂ → ℂ} {Ω : Set ℂ}
    (hΩ : IsOpen Ω) (hConn : IsPreconnected Ω)
    (hf : DifferentiableOn ℂ f Ω)
    (hc : ∃ c : ℝ, ∀ z ∈ Ω, (f z).im = c) :
    ∀ a b : Ω, f a = f b := by
  classical
  -- Step 1: Extract the constant imaginary value.
  obtain ⟨c, hcConst⟩ := hc
  -- Step 2: Promote the differentiability assumption to analyticity on a neighborhood.
  have hAnalytic : AnalyticOnNhd ℂ f Ω := hf.analyticOnNhd hΩ
  -- Step 3: Apply the open mapping theorem dichotomy.
  have hChoice := hAnalytic.is_constant_or_isOpen hConn
  -- Step 4: Prepare the auxiliary facts about the image of `f`.
  have hsubset : f '' Ω ⊆ {z : ℂ | z.im = c} := by
    -- Step 4.1: Directly unfold the definition of the image and use `hcConst`.
    intro w hw
    rcases hw with ⟨z, hzΩ, rfl⟩
    simpa [Set.mem_setOf_eq] using hcConst z hzΩ
  -- Step 4.2: We will also use that the image is nonempty once a point of `Ω` is chosen.
  intro a b
  have himage_ne : (f '' Ω).Nonempty := ⟨f a, ⟨a, a.property, rfl⟩⟩
  -- Step 5: Perform the case analysis.
  cases hChoice with
  | inl hconst =>
      -- Step 5.1: In the constant case, specialize the witness to both `a` and `b`.
      obtain ⟨w, hw⟩ := hconst
      have ha := hw a a.property
      have hb := hw b b.property
      -- Step 5.2: Combine the two equalities.
      simp [ha, hb]
  | inr hopen =>
      -- Step 6: Show that the \"open image\" option contradicts the geometric constraint.
      have hopenImage : IsOpen (f '' Ω) := hopen Ω subset_rfl hΩ
      have hnoopen := subset_verticalLine_not_isOpen (c := c) hsubset himage_ne
      exact (hnoopen hopenImage).elim
