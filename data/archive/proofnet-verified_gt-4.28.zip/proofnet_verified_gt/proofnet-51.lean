import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that if $P \in \operatorname{Syl}_{p}(G)$ and $H$ is a subgroup of $G$ containing $P$ then $P \in \operatorname{Syl}_{p}(H)$.
-/

/-Informal Proof

If $P \leq H \leq G$ is a Sylow $p$-subgroup of $G$, then $p$ does not divide $[G: P]$. Now $[G: P]=[G: H][H: P]$, so that $p$ does not divide $[H: P]$; hence $P$ is a Sylow $p$-subgroup of $H$.
-/

theorem Dummit_Foote_exercise_4_5_1a {p : ℕ} {G : Type*} [Group G]
  {P : Subgroup G} (hP : IsPGroup p P) (H : Subgroup G)
  (hH : P ≤ H) : IsPGroup p H := by
  sorry

/-! ## Refutation
The original statement `Dummit_Foote_exercise_4_5_1a` is false: `Dummit_Foote_exercise_4_5_1a_neg` proves the negation of its elaborated type. -/

/-
### Why the formalization is false

The informal exercise says: a *Sylow* `p`-subgroup `P` of `G` remains a Sylow
`p`-subgroup of any intermediate subgroup `H` with `P ≤ H ≤ G`.

The Lean statement, however, only assumes that `P` is *some* `p`-group (not a
maximal one), and it concludes that the *overgroup* `H` is a `p`-group. That is
plainly false: enlarging a `p`-group can leave the class of `p`-groups.

Counterexample: `p = 2`, `G = ULift (Multiplicative (ZMod 3))` (cyclic of order 3),
`P = ⊥` and `H = ⊤`. The trivial subgroup `⊥` is a `2`-group, and `⊥ ≤ ⊤`, but
`Nat.card ↥(⊤ : Subgroup G) = 3` is not a power of `2`.

(`ULift` is needed only because the negated statement is universe polymorphic:
`G` must live in the arbitrary universe `u_1`, so we lift the small group into it.)
-/
theorem Dummit_Foote_exercise_4_5_1a_neg : ¬ (type_of% @Dummit_Foote_exercise_4_5_1a) := by
  -- Step 1: assume the universally quantified statement `h`.
  intro h
  -- Step 2: the trivial subgroup `⊥` of the cyclic group of order 3 is a 2-group.
  -- Step 2.1: `⊥` is a subsingleton, so every element equals `1`, hence `g ^ 2 ^ 0 = 1`.
  have hP : IsPGroup 2 (⊥ : Subgroup (ULift.{u_1} (Multiplicative (ZMod 3)))) := by
    intro g
    exact ⟨0, by simpa using Subsingleton.elim _ _⟩
  -- Step 3: specialise `h` to `p = 2`, `P = ⊥`, `H = ⊤` (using `bot_le : ⊥ ≤ ⊤`).
  -- This yields the false claim that the whole group `⊤` is a 2-group.
  have key := h (p := 2) hP (⊤ : Subgroup (ULift.{u_1} (Multiplicative (ZMod 3)))) bot_le
  -- Step 4: derive `False` from `key` by counting elements.
  -- Step 4.1: `IsPGroup.exists_card_eq` needs `2` to be prime.
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  -- Step 4.2: a finite `p`-group has cardinality `p ^ n` for some `n`.
  obtain ⟨n, hn⟩ := key.exists_card_eq
  -- Step 4.3: rewrite `Nat.card ↥(⊤ : Subgroup G)` as `Nat.card G` and then drop the `ULift`.
  rw [Nat.card_congr (Subgroup.topEquiv (G := ULift.{u_1} (Multiplicative (ZMod 3)))).toEquiv,
    Nat.card_congr Equiv.ulift] at hn
  -- Step 4.4: `Multiplicative (ZMod 3)` has exactly 3 elements, so `hn : 3 = 2 ^ n`.
  simp [Nat.card_eq_fintype_card] at hn
  -- Step 5: `3 = 2 ^ n` is impossible.
  -- Step 5.1: it would give `3 ∣ 2 ^ n`, and `3` is prime, so `3 ∣ 2`.
  have h3 : (3:ℕ) ∣ 2 ^ n := hn ▸ dvd_rfl
  have := Nat.Prime.dvd_of_dvd_pow (by norm_num) h3
  -- Step 5.2: `3 ∣ 2` is arithmetically absurd.
  omega

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_4_5_1a_corrected {p : ℕ} {G : Type*} [Group G]
  {P : Sylow p G} (H : Subgroup G) (hH : P ≤ H) :
  IsPGroup p (P.subgroupOf H) ∧
  ∀ (Q : Subgroup H), IsPGroup p Q → (P.subgroupOf H) ≤ Q → Q = (P.subgroupOf H) := by
  classical
  -- Step 1: Define `P_H` as the Sylow subgroup of `H` obtained by restricting `P`.
  let P_H : Sylow p H := P.subtype hH
  -- Step 1.1: Record that the underlying subgroup of `P_H` is definitionally `P.subgroupOf H`.
  have hP_H_coe : (P_H : Subgroup H) = P.subgroupOf H := rfl
  -- Step 2: Extract the `p`-group property from the Sylow structure on `P_H`.
  have hPgroup : IsPGroup p (P.subgroupOf H) := by
    -- Step 2.1: Reinterpret the stored `IsPGroup` information of `P_H` through `hP_H_coe`.
    simpa [P_H, hP_H_coe] using (P_H.isPGroup')
  -- Step 3: Show that every `p`-subgroup of `H` containing `P.subgroupOf H` must coincide with it.
  have hMaximal :
      ∀ (Q : Subgroup H), IsPGroup p Q → (P.subgroupOf H) ≤ Q → Q = (P.subgroupOf H) := by
    -- Step 3.1: Introduce an arbitrary `p`-subgroup `Q` of `H` containing `P.subgroupOf H`.
    intro Q hQ hle
    -- Step 3.2: Translate the containment into the language of `P_H`.
    have hle' : (P_H : Subgroup H) ≤ Q := by
      -- Step 3.2.1: Use `hP_H_coe` to identify the two subgroups.
      simpa [P_H, hP_H_coe] using hle
    -- Step 3.3: Apply the maximality property encoded in the Sylow structure of `P_H`.
    have hEq : Q = (P_H : Subgroup H) := P_H.is_maximal' hQ hle'
    -- Step 3.4: Rewrite the obtained equality back in terms of `P.subgroupOf H`.
    simpa [P_H, hP_H_coe] using hEq
  -- Step 4: Combine the `p`-group property and the maximality property to conclude.
  exact ⟨hPgroup, hMaximal⟩
