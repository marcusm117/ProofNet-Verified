import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

/-Informal Statement

Let $f: S^{1} \rightarrow \mathbb{R}$ be a continuous map. Show there exists a point $x$ of $S^{1}$ such that $f(x)=f(-x)$.
-/

/-Informal Proof

Let $f: S^1 \rightarrow \mathbb{R}$ be continuous. Let $x \in S^1$. If $f(x)=f(-x)$ we are done, so assume $f(x) \neq f(-x)$. Define $g: S^1 \rightarrow \mathbb{R}$ by setting $g(x)=f(x)-f(-x)$. Then $g$ is continuous. Suppose $f(x)>f(-x)$, so that $g(x)>0$. Then $-x \in S^1$ and $g(-x)<0$. By the intermediate value theorem, since $S^1$ is connected and $g(-x)<0<g(x)$, there exists $y \in S^1$ such that $g(y)=0$. i.e, $f(y)=f(-y)$. Similarly, if $f(x)<f(-x)$, then $g(x)<0<g(-x)$ and again the intermediate value theorem gives the result.
-/

theorem Munkres_exercise_24_2 {f : (Metric.sphere 0 1 : Set ℝ) → ℝ}
  (hf : Continuous f) : ∃ x, f x = f (-x) := by
  sorry

/-! ## Refutation
The original statement `Munkres_exercise_24_2` is false: `Munkres_exercise_24_2_neg` proves the negation of its elaborated type. -/

/-
## Why the formalization is false

The informal statement is the 1-dimensional Borsuk–Ulam theorem about the *circle*
`S¹ ⊆ ℝ²`.  The formalization instead uses `(Metric.sphere 0 1 : Set ℝ)`, the unit
sphere of the *real line*, which is the two-point discrete space `{-1, 1}`.  On that
space every function is continuous, the antipodal map merely swaps the two points,
and there is no connectedness left to run an intermediate value argument.

Counterexample: take `f = Subtype.val`, i.e. `f x = (x : ℝ)`.  It is continuous
(`continuous_subtype_val`), yet `f x = f (-x)` says `(x : ℝ) = -(x : ℝ)`, forcing
`(x : ℝ) = 0`, which contradicts `‖x‖ = 1`.
-/

theorem Munkres_exercise_24_2_neg : ¬ (type_of% @Munkres_exercise_24_2) := by
  -- Step 1: assume the (universally quantified) statement holds.
  intro h
  -- Step 2: instantiate it at the coercion `f = Subtype.val : sphere 0 1 → ℝ`,
  -- which is continuous by `continuous_subtype_val`.  This yields a point `x`
  -- of the "sphere" with `(x : ℝ) = ((-x : sphere 0 1) : ℝ)`.
  obtain ⟨x, hx⟩ := @h (fun x => (x : ℝ)) continuous_subtype_val
  -- Step 3: push the coercion through the negation on the sphere subtype:
  -- `((-x : sphere 0 1) : ℝ) = -(x : ℝ)`.  So `hx : (x : ℝ) = -(x : ℝ)`.
  simp only [coe_neg_sphere] at hx
  -- Step 4: hence `(x : ℝ) = 0`.
  have hx0 : (x : ℝ) = 0 := by linarith
  -- Step 5: but `x` lies on the unit sphere, so `‖(x : ℝ) - 0‖ = 1`,
  -- i.e. `‖(0 : ℝ)‖ = 1` after rewriting, which is `(0 : ℝ) = 1` — absurd.
  have hmem := x.2
  rw [mem_sphere_iff_norm, sub_zero, hx0] at hmem
  simp at hmem

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace
open scoped Topology

/-
Explanation: The formalized domain `Metric.sphere 0 1 : Set ℝ` contains only the two antipodal
points `1` and `-1`. A continuous function on this discrete two-point space can separate the values
at these points, so the claimed equality need not hold.
-/

noncomputable section

open scoped Real

/-
Corrected Statement:
If we interpret the circle as the unit sphere in the complex plane, every continuous function
`f : Metric.sphere (0 : ℂ) 1 → ℝ` admits an antipodal pair with equal values.
-/

/-- Step 5: Parameterize the sphere via the exponential map on the circle. -/
def circleParam (t : ℝ) :
    (Metric.sphere (0 : ℂ) 1 : Set ℂ) :=
  ⟨(Circle.exp t : ℂ), by
    -- Step 5.1: Restate the sphere membership as a norm equality.
    change ‖(Circle.exp t : ℂ) - 0‖ = 1
    -- Step 5.2: Simplify to the known unit-norm property of `Circle.exp`.
    simp⟩

/-- Step 6: The parametrization is continuous. -/
lemma circleParam_continuous : Continuous circleParam := by
  -- Step 6.1: The map `t ↦ (Circle.exp t : ℂ)` is continuous.
  have hval :
      Continuous fun t : ℝ => (Circle.exp t : ℂ) :=
    (continuous_subtype_val : Continuous fun z : Circle => (z : ℂ)).comp Circle.exp.continuous
  -- Step 6.2: Upgrade the continuity result to the subtype.
  exact Continuous.subtype_mk
    (by simpa [circleParam] using hval)
    (by
      intro t
      change ‖(Circle.exp t : ℂ) - 0‖ = 1
      simp)

/-- Step 7: Rotating the parameter by `π` gives the antipodal point. -/
lemma circleParam_add_pi (t : ℝ) :
    circleParam (t + Real.pi) = -circleParam t := by
  -- Step 7.1: Compare underlying complex numbers.
  apply Subtype.ext
  -- Step 7.2: Rewrite via complex exponentials.
  change (Circle.exp (t + Real.pi) : ℂ) = -(Circle.exp t : ℂ)
  simp [Circle.coe_exp, Complex.exp_pi_mul_I]

/-- Step 8: State and prove the corrected version on the complex unit circle. -/
theorem Munkres_exercise_24_2_corrected
    {f : (Metric.sphere (0 : ℂ) 1 : Set ℂ) → ℝ}
    (hf : Continuous f) : ∃ x, f x = f (-x) := by
  -- Step 9.1: Work classically for convenience.
  classical
  -- Step 9.2: Define the asymmetry function on the sphere.
  let g : (Metric.sphere (0 : ℂ) 1 : Set ℂ) → ℝ := fun z => f z - f (-z)
  -- Step 9.3: Establish continuity of `g`.
  have hg : Continuous g := by
    -- Step 9.3.1: Combine continuity of `f` with the negation map.
    refine hf.sub ?_
    exact hf.comp continuous_neg
  -- Step 9.4: Pull back along the parameterization.
  let φ : ℝ → ℝ := fun t => g (circleParam t)
  -- Step 9.5: Record continuity of `φ`.
  have hφ : Continuous φ := hg.comp circleParam_continuous
  -- Step 9.6: Evaluate the endpoints at `0` and `π`.
  have hφ_zero :
      φ 0 = f (circleParam 0) - f (-circleParam 0) := by
    -- Step 9.6.1: Unfold definitions.
    simp [φ, g]
  have hφ_pi :
      φ Real.pi = f (circleParam Real.pi) - f (-circleParam Real.pi) := by
    -- Step 9.6.2: Similar expansion at `π`.
    simp [φ, g]
  -- Step 9.7: Relate the two endpoints using the antipodal identity.
  have hflip : circleParam Real.pi = -circleParam 0 := by
    simpa [zero_add] using circleParam_add_pi (0 : ℝ)
  have hφ_pi' :
      φ Real.pi = -φ 0 := by
    -- Step 9.7.1: Substitute the identity from Step 9.7.
    simp [φ, g, hflip, sub_eq_add_neg, add_comm]
  -- Step 9.8: Prepare data for the intermediate value theorem.
  have hcont_on : ContinuousOn φ (Set.Icc (0 : ℝ) Real.pi) := hφ.continuousOn
  have hpi_nonneg : (0 : ℝ) ≤ Real.pi := Real.pi_nonneg
  -- Step 9.9: Case split on whether `φ 0` already vanishes.
  by_cases hzero : φ 0 = 0
  · -- Step 9.9.1: Immediate solution when the difference at `t = 0` vanishes.
    refine ⟨circleParam 0, ?_⟩
    -- Step 9.9.1.1: Read the equality off from the definition of `φ`.
    have hzero' : φ 0 = 0 := hzero
    have : f (circleParam 0) - f (-circleParam 0) = 0 := by
      simpa [φ, g] using hzero'
    exact sub_eq_zero.mp this
  · -- Step 9.9.2: Otherwise, apply the intermediate value theorem.
    have hφ_ne : φ 0 ≠ 0 := hzero
    -- Step 9.9.2.1: Distinguish the sign of `φ 0`.
    have hcases := lt_or_gt_of_ne hφ_ne
    rcases hcases with hneg | hpos
    · -- Step 9.9.2.1(a): If `φ 0 < 0`, then `φ π > 0`.
      have hpos' : 0 ≤ φ Real.pi := by
        simpa [hφ_pi'] using neg_nonneg.mpr (le_of_lt hneg)
      have hsubset :=
        intermediate_value_Icc (a := (0 : ℝ)) (b := Real.pi)
          (f := φ) hpi_nonneg hcont_on
      have hzero_mem : (0 : ℝ) ∈ Set.Icc (φ 0) (φ Real.pi) :=
        ⟨le_of_lt hneg, hpos'⟩
      obtain ⟨t, ht_mem, ht_val⟩ := hsubset hzero_mem
      refine ⟨circleParam t, ?_⟩
      -- Step 9.9.2.1(a.i): Translate the vanishing of `φ t` back to the original function.
      simpa [φ, g, sub_eq_zero] using ht_val
    · -- Step 9.9.2.1(b): If `φ 0 > 0`, then `φ π < 0`.
      have hneg' : φ Real.pi ≤ 0 := by
        simpa [hφ_pi'] using neg_nonpos.mpr (le_of_lt hpos)
      have hsubset :=
        intermediate_value_Icc' (a := (0 : ℝ)) (b := Real.pi)
          (f := φ) hpi_nonneg hcont_on
      have hzero_mem : (0 : ℝ) ∈ Set.Icc (φ Real.pi) (φ 0) :=
        ⟨hneg', le_of_lt hpos⟩
      obtain ⟨t, ht_mem, ht_val⟩ := hsubset hzero_mem
      refine ⟨circleParam t, ?_⟩
      -- Step 9.9.2.1(b.i): Conclude as in the previous branch.
      simpa [φ, g, sub_eq_zero] using ht_val
