import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

A subgroup $M$ of a group $G$ is called a maximal subgroup if $M \neq G$ and the only subgroups of $G$ which contain $M$ are $M$ and $G$. Prove that if $H$ is a proper subgroup of the finite group $G$ then there is a maximal subgroup of $G$ containing $H$.
-/

/-Informal Proof

If $H$ is maximal, then we are done. If $H$ is not maximal, then there is a subgroup $K_1$ of $G$ such that $H<K_1<G$. If $K_1$ is maximal, we are done. But if $K_1$ is not maximal, there is a subgroup $K_2$ with $H<K_1<K_2<G$. If $K_2$ is maximal, we are done, and if not, keep repeating the procedure. Since $G$ is finite, this process must eventually come to an end, so that $K_n$ is maximal for some positive integer $n$. Then $K_n$ is a maximal subgroup containing $H$.
-/

theorem Dummit_Foote_exercise_2_4_16a {G : Type*} [Group G] {H : Subgroup G}
  (hH : H ≠ ⊤) :
  ∃ M : Subgroup G, M ≠ ⊤ ∧
  ∀ K : Subgroup G, M ≤ K → K = M ∨ K = ⊤ ∧
  H ≤ M := by
  sorry

/-! ## Refutation
The original statement `Dummit_Foote_exercise_2_4_16a` is false: `Dummit_Foote_exercise_2_4_16a_neg` proves the negation of its elaborated type. -/

/-! ### Counterexample

The formalization drops the hypothesis that `G` is finite, so it asserts that *every* group
has a maximal (co-atomic) subgroup above any proper subgroup.  This is false for divisible
groups.  We use the additive group `ℚ` (viewed multiplicatively as `Multiplicative ℚ`)
together with `H = ⊥`.

The key work is done additively in the lemma below: `ℚ` has no additive subgroup `A ≠ ⊤`
whose only over-subgroups are `A` and `⊤`. -/

/-- **Main mathematical content.**  The additive group `ℚ` has no co-atom:
there is no proper additive subgroup `A` such that every subgroup containing `A`
equals `A` or `⊤`. -/
theorem rat_no_coatom_aux (A : AddSubgroup ℚ) (hA : A ≠ ⊤)
    (hK : ∀ B : AddSubgroup ℚ, A ≤ B → B = A ∨ B = ⊤) : False := by
  -- Step 1: `A` is *pure*: if `n ≠ 0` is a natural number and `n * x ∈ A`, then `x ∈ A`.
  have hpure : ∀ n : ℕ, n ≠ 0 → ∀ x : ℚ, (n : ℚ) * x ∈ A → x ∈ A := by
    intro n hn x hx
    have hn' : (n : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr hn
    -- Step 1.1: the preimage `B = { y | n * y ∈ A }` of `A` under multiplication by `n`
    -- is a subgroup containing `A`.
    have hAB : A ≤ A.comap (AddMonoidHom.mulLeft (n : ℚ)) := by
      intro y hy
      simp only [AddSubgroup.mem_comap, AddMonoidHom.coe_mulLeft, ← nsmul_eq_mul]
      exact nsmul_mem hy n
    rcases hK _ hAB with h | h
    · -- Step 1.2: if `B = A` we are done, since `x ∈ B` by assumption.
      have hxB : x ∈ A.comap (AddMonoidHom.mulLeft (n : ℚ)) := by
        simpa only [AddSubgroup.mem_comap, AddMonoidHom.coe_mulLeft] using hx
      rw [h] at hxB
      exact hxB
    · -- Step 1.3: if `B = ⊤` then `A = ⊤` (divisibility: every `z` is `n * (z / n)`),
      -- contradicting `hA`.
      refine absurd ((AddSubgroup.eq_top_iff' A).mpr fun z => ?_) hA
      have hz : z / (n : ℚ) ∈ A.comap (AddMonoidHom.mulLeft (n : ℚ)) := by
        rw [h]; trivial
      have hcancel : (n : ℚ) * (z / (n : ℚ)) = z := by field_simp
      simpa only [AddSubgroup.mem_comap, AddMonoidHom.coe_mulLeft, hcancel] using hz
  by_cases hbot : A = ⊥
  · -- Step 2: if `A = ⊥`, then the subgroup `ℤ ⊆ ℚ` sits strictly between `⊥` and `⊤`.
    have h1 : A ≤ AddSubgroup.zmultiples (1 : ℚ) := by rw [hbot]; exact bot_le
    rcases hK _ h1 with h | h
    · -- Step 2.1: `ℤ = ⊥` is impossible since `1 ≠ 0`.
      have h2 : (1 : ℚ) ∈ AddSubgroup.zmultiples (1 : ℚ) := AddSubgroup.mem_zmultiples 1
      rw [h, hbot, AddSubgroup.mem_bot] at h2
      exact one_ne_zero h2
    · -- Step 2.2: `ℤ = ⊤` is impossible since `1/2` is not an integer.
      have h2 : (1 / 2 : ℚ) ∈ AddSubgroup.zmultiples (1 : ℚ) := by rw [h]; trivial
      rw [AddSubgroup.mem_zmultiples_iff] at h2
      obtain ⟨k, hk⟩ := h2
      rw [zsmul_eq_mul, mul_one] at hk
      have h3 : (2 * k : ℤ) = 1 := by
        have : ((2 * k : ℤ) : ℚ) = ((1 : ℤ) : ℚ) := by push_cast; linarith
        exact_mod_cast this
      omega
  · -- Step 3: if `A ≠ ⊥`, pick `0 ≠ x ∈ A`; then purity forces `A = ⊤`.
    obtain ⟨x, hxA, hx0⟩ : ∃ x, x ∈ A ∧ x ≠ 0 := by
      by_contra hcon
      push_neg at hcon
      refine hbot (eq_bot_iff.mpr fun y hy => ?_)
      simpa [AddSubgroup.mem_bot] using hcon y hy
    refine hA ((AddSubgroup.eq_top_iff' A).mpr fun z => ?_)
    -- Step 3.1: every `z : ℚ` is `q * x` for some rational `q` (as `x ≠ 0`).
    obtain ⟨q, rfl⟩ : ∃ q : ℚ, z = q * x := ⟨z / x, by field_simp⟩
    -- Step 3.2: `q.den * (q * x) = q.num * x`, which lies in `A` since `x ∈ A`.
    have hden : ((q.den : ℚ)) * (q * x) = ((q.num : ℚ)) * x := by
      rw [← mul_assoc, Rat.den_mul_eq_num]
    have hmem : ((q.den : ℚ)) * (q * x) ∈ A := by
      rw [hden, ← zsmul_eq_mul]
      exact zsmul_mem hxA _
    -- Step 3.3: purity with `n = q.den ≠ 0` gives `q * x ∈ A`.
    exact hpure q.den (Rat.den_ne_zero _) (q * x) hmem

/-- The additive monoid hom `ℚ →+ ULift ℚ` (used to move the counterexample into an
arbitrary universe). -/
def upRatHom : ℚ →+ ULift.{u} ℚ where
  toFun q := ⟨q⟩
  map_zero' := rfl
  map_add' _ _ := rfl

/-- The additive monoid hom `ULift ℚ →+ ℚ`. -/
def downRatHom : ULift.{u} ℚ →+ ℚ where
  toFun q := q.down
  map_zero' := rfl
  map_add' _ _ := rfl

theorem Dummit_Foote_exercise_2_4_16a_neg : ¬ (type_of% @Dummit_Foote_exercise_2_4_16a) := by
  intro h
  -- Step 4: instantiate the statement at `G = Multiplicative (ULift ℚ)` and `H = ⊥`.
  -- (`ULift` is only needed to place `ℚ` in the ambient universe of the statement.)
  obtain ⟨M, hMtop, hMK⟩ := h (G := Multiplicative (ULift ℚ)) (H := ⊥) (by
    intro hcon
    have h1 : Multiplicative.ofAdd (⟨(1 : ℚ)⟩ : ULift ℚ) ∈
        (⊥ : Subgroup (Multiplicative (ULift ℚ))) := by rw [hcon]; trivial
    rw [Subgroup.mem_bot] at h1
    exact one_ne_zero (congrArg ULift.down (_root_.ofAdd_eq_one.mp h1)))
  -- Step 5: transport `M` to the additive subgroup `A = { q : ℚ | ofAdd ⟨q⟩ ∈ M }` of `ℚ`.
  set A : AddSubgroup ℚ := (Subgroup.toAddSubgroup' M).comap upRatHom with hAdef
  -- Step 5.1: `A ≠ ⊤`, because `A = ⊤` would give `M = ⊤`.
  have hA : A ≠ ⊤ := by
    intro hcon
    refine hMtop ((Subgroup.eq_top_iff' M).mpr fun g => ?_)
    have h2 : (Multiplicative.toAdd g).down ∈ A := by rw [hcon]; trivial
    exact h2
  -- Step 5.2: every additive subgroup of `ℚ` above `A` is `A` or `⊤`,
  -- since the corresponding subgroup of `Multiplicative (ULift ℚ)` lies above `M`.
  have hKA : ∀ B : AddSubgroup ℚ, A ≤ B → B = A ∨ B = ⊤ := by
    intro B hAB
    have hMB : M ≤ AddSubgroup.toSubgroup (B.comap downRatHom) := by
      intro g hg
      have h3 : (Multiplicative.toAdd g).down ∈ A := hg
      exact hAB h3
    rcases hMK _ hMB with hcase | ⟨hcase, -⟩
    · -- the transported subgroup is `M`, i.e. `B = A`
      refine Or.inl (SetLike.ext fun q => ⟨fun hq => ?_, fun hq => ?_⟩)
      · have h4 : Multiplicative.ofAdd (⟨q⟩ : ULift ℚ) ∈
            AddSubgroup.toSubgroup (B.comap downRatHom) := hq
        rw [hcase] at h4
        exact h4
      · have h4 : Multiplicative.ofAdd (⟨q⟩ : ULift ℚ) ∈ M := hq
        rw [← hcase] at h4
        exact h4
    · -- the transported subgroup is `⊤`, i.e. `B = ⊤`
      refine Or.inr ((AddSubgroup.eq_top_iff' B).mpr fun q => ?_)
      have h4 : Multiplicative.ofAdd (⟨q⟩ : ULift ℚ) ∈
          AddSubgroup.toSubgroup (B.comap downRatHom) := by rw [hcase]; trivial
      exact h4
  -- Step 6: contradiction with the divisibility of `ℚ`.
  exact rat_no_coatom_aux A hA hKA

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_2_4_16a_corrected {G : Type*} [Group G] [Fintype G] {H : Subgroup G}
  (hH : H ≠ ⊤) :
  ∃ M : Subgroup G, M ≠ ⊤ ∧
  (∀ K : Subgroup G, M ≤ K → K = M ∨ K = ⊤) ∧
  H ≤ M := by
  classical
  -- Step 1: Encode "proper supergroups of `H`" via a predicate on subgroup cardinalities.
  let P : ℕ → Prop :=
    fun k => ∃ K : Subgroup G, H ≤ K ∧ K ≠ ⊤ ∧ Fintype.card ↥K = k
  -- Step 1.1: Any subgroup injects into `G`, so its size is bounded above by `|G|`.
  have hBound : ∀ K : Subgroup G, Fintype.card ↥K ≤ Fintype.card G := by
    intro K
    refine Fintype.card_le_of_injective (fun k : K => (k : G)) ?_
    intro x y hxy
    ext
    simpa using hxy
  -- Step 1.2: The subgroup `H` itself witnesses the predicate and is bounded by `|G|`.
  have hWitness : P (Fintype.card ↥H) := ⟨H, le_rfl, hH, rfl⟩
  have hWitnessBound : Fintype.card ↥H ≤ Fintype.card G := hBound H
  -- Step 2: Use `Nat.findGreatest` to extract a subgroup `M` with maximal size among the witnesses.
  set n := Nat.findGreatest P (Fintype.card G) with hn
  have hPn : P n := by
    have := Nat.findGreatest_spec (P := P) (m := Fintype.card ↥H) (n := Fintype.card G)
        hWitnessBound hWitness
    simpa [n] using this
  -- Step 2.1: Unpack the predicate to obtain the desired subgroup `M`.
  rcases hPn with ⟨M, hHM, hMproper, hMcard⟩
  refine ⟨M, hMproper, ?_, hHM⟩
  -- Step 3: Prove that `M` is maximal among proper subgroups containing `H`.
  intro K hMK
  -- Step 3.1: If `K = ⊤`, we are immediately done.
  by_cases hKtop : K = ⊤
  · exact Or.inr hKtop
  -- Step 3.2: Otherwise, `K` is still proper and contains `H`.
  · have hHK : H ≤ K := hHM.trans hMK
    have hPK : P (Fintype.card ↥K) := ⟨K, hHK, hKtop, rfl⟩
    have hBoundK : Fintype.card ↥K ≤ Fintype.card G := hBound K
    -- Step 3.3: Maximality of `n` forces `|K| ≤ |M|`.
    have hLeN : Fintype.card ↥K ≤ n := by
      simpa [n] using Nat.le_findGreatest (P := P) hBoundK hPK
    have hCardLe : Fintype.card ↥K ≤ Fintype.card ↥M := by
      simpa [hMcard] using hLeN
    -- Step 3.4: The inclusion `M ≤ K` gives the reverse inequality on cardinalities.
    have hInj :
        Function.Injective (fun x : M => (⟨x, hMK x.property⟩ : K)) := by
      intro x y hxy
      ext
      simpa using congrArg Subtype.val hxy
    have hCardLe' : Fintype.card ↥M ≤ Fintype.card ↥K :=
      Fintype.card_le_of_injective _ hInj
    have hCardEq : Fintype.card ↥M = Fintype.card ↥K :=
      le_antisymm hCardLe' hCardLe
    -- Step 3.5.1: Compare the cardinality–index identities for `M` and `K`.
    have hMindex :
        Fintype.card ↥M * M.index = Fintype.card G := by
      simpa [Nat.card_eq_fintype_card] using M.card_mul_index
    have hKindex :
        Fintype.card ↥K * K.index = Fintype.card G := by
      simpa [Nat.card_eq_fintype_card] using K.card_mul_index
    have hIndexEqRaw :
        Fintype.card ↥M * M.index = Fintype.card ↥M * K.index := by
      simpa [hCardEq] using hMindex.trans hKindex.symm
    -- Step 3.5.2: Cancel the positive cardinality factor to conclude `M.index = K.index`.
    have hMpos : 0 < Fintype.card ↥M :=
      Fintype.card_pos_iff.mpr ⟨⟨1, M.one_mem⟩⟩
    have hIndexEq : M.index = K.index :=
      Nat.eq_of_mul_eq_mul_left hMpos hIndexEqRaw
    -- Step 3.5.3: Plug the index equality into the relative index formula.
    have hRelEq :
        M.relIndex K * K.index = K.index := by
      simpa [hIndexEq] using Subgroup.relIndex_mul_index (H := M) (K := K) hMK
    have hIndexNeZero : K.index ≠ 0 := by
      classical
      simpa using (K.index_ne_zero_of_finite : K.index ≠ 0)
    have hRelEq' : K.index * M.relIndex K = K.index * 1 := by
      have : K.index * M.relIndex K = K.index := by
        simpa [Nat.mul_comm] using hRelEq
      simpa [Nat.mul_one] using this
    have hRelIndex : M.relIndex K = 1 :=
      Nat.eq_of_mul_eq_mul_left (Nat.pos_of_ne_zero hIndexNeZero) hRelEq'
    -- Step 3.5.4: Relative index `1` means `K ≤ M`, hence `K = M`.
    have hKleM : K ≤ M :=
      (Subgroup.relIndex_eq_one (H := M) (K := K)).1 hRelIndex
    exact Or.inl (le_antisymm hKleM hMK)
