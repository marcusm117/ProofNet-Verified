import Mathlib


open Fintype Set Real Ideal Polynomial
open scoped BigOperators
noncomputable section

/-Informal Statement

If $G$ is a nonabelian group of order 6, prove that $G \simeq S_3$.
-/

/-Informal Proof

Suppose $G$ is a non-abelian group of order 6 . We need to prove that $G \cong S_3$. Since $G$ is non-abelian, we conclude that there is no element of order 6. Now all the nonidentity element has order either 2 or 3 . All elements cannot be order 3 .This is because except the identity elements there are 5 elements, but order 3 elements occur in pair, that is $a, a^2$, both have order 3 , and $a \neq a^2$. So, this is a contradiction, as there are only 5 elements. So, there must be an element of order 2 . All elements of order 2 will imply that $G$ is abelian, hence there is also element of order 3 . Let $a$ be an element of order 2 , and $b$ be an element of order 3 . So we have $e, a, b, b^2$, already 4 elements. Now $a b \neq e, b, b^2$. So $a b$ is another element distinct from the ones already constructed. $a b^2 \neq e, b, a b, b^2, a$. So, we have got another element distinct from the other. So, now $ G=\left\{e, a, b, b^2, a b, a b^2\right\}$. Also, ba must be equal to one of these elements. But $b a \neq e, a, b, b^2$. Also if $b a=a b$, the group will become abelian. so $b a=a b^2$. So what we finally get is $G=\left\langle a, b \mid a^2=e=b^3, b a=a b^2\right\rangle$. Hence $G \cong S_3$.
-/

/-
Note on the formalisation.  The hypothesis `hG' : IsEmpty (CommGroup G)` does *not* say
that the given group structure on `G` is noncommutative: it says that the *type* `G`
carries no commutative group structure whatsoever.  That is impossible for a type with
six elements, since one can transport the abelian group structure of `Multiplicative (Fin 6)`
along any bijection `G ≃ Fin 6`.  So the hypotheses are contradictory and the statement
is vacuously true.  The helper lemma below builds such a commutative group structure.
-/

/-- Any type with exactly six elements carries a commutative group structure:
transport the (additive, hence commutative) group structure of `Fin 6` along a bijection. -/
theorem nonempty_commGroup_of_card_eq_six (G : Type*) [Fintype G]
    (hG : Fintype.card G = 6) : Nonempty (CommGroup G) := by
  -- Step 1: a type with six elements is in bijection with `Fin 6`.
  have e : G ≃ Fin 6 := Fintype.equivFinOfCardEq hG
  -- Step 2: `Fin 6` is an additive commutative group, so its multiplicative
  -- copy `Multiplicative (Fin 6)` is a commutative group.
  have e' : G ≃ Multiplicative (Fin 6) := e.trans Multiplicative.ofAdd
  -- Step 3: transport that structure along the bijection.
  exact ⟨e'.commGroup⟩

instance Herstein_exercise_2_5_37 (G : Type*) [Group G] [Fintype G]
  (hG : card G = 6) (hG' : IsEmpty (CommGroup G)) :
  G ≃* Equiv.Perm (Fin 3) := by
  -- Step 1: from `card G = 6` we produce a commutative group structure on `G`.
  -- (`Nonempty` cannot be eliminated into data, so we pick a witness with `Classical.choice`.)
  have hne : Nonempty (CommGroup G) := nonempty_commGroup_of_card_eq_six G hG
  -- Step 2: this contradicts the hypothesis that `CommGroup G` is empty, so the
  -- hypotheses are inconsistent and anything follows.
  exact (hG'.false (Classical.choice hne)).elim

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Set Real Ideal Polynomial
open scoped BigOperators

/-
Corrected version of the statement.

The original statement uses `IsEmpty (CommGroup G)` to express "G is non-abelian".
This is not equivalent to "the group `G` is non-abelian": `IsEmpty (CommGroup G)`
asserts that there is no commutative group structure on the type `G` at all, but
since any finite group of order 6 has a commutative group structure on its
underlying type (e.g., transported from `ZMod 6`), this hypothesis is actually
contradictory whenever `Fintype.card G = 6`. The original "proof" exploits this
to derive `False` from the hypothesis, rather than proving the genuine
mathematical statement.

The corrected statement expresses non-abelian-ness using the *existing* group
structure on `G`: there exist elements `a, b : G` with `a * b ≠ b * a`.
-/
theorem Herstein_exercise_2_5_37_corrected (G : Type*) [Group G] [Fintype G]
  (hG : card G = 6) (hG' : ∃ a b : G, a * b ≠ b * a) :
  Nonempty (G ≃* Equiv.Perm (Fin 3)) := by
  classical
  have hCardG : Fintype.card G = 6 := by simpa using hG
  have hNatCardG : Nat.card G = 6 := by
    rw [Nat.card_eq_fintype_card]; exact hCardG
  /-
  Step 1: By Cauchy's theorem, find elements `a` and `b` of `G` with
  `orderOf a = 2` and `orderOf b = 3`.
  -/
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  haveI : Fact (Nat.Prime 3) := ⟨Nat.prime_three⟩
  have h2dvd : (2 : ℕ) ∣ Fintype.card G := by rw [hCardG]; decide
  have h3dvd : (3 : ℕ) ∣ Fintype.card G := by rw [hCardG]; decide
  obtain ⟨a, ha⟩ := exists_prime_orderOf_dvd_card 2 h2dvd
  obtain ⟨b, hb⟩ := exists_prime_orderOf_dvd_card 3 h3dvd
  /-
  Step 2: Define `H = ⟨a⟩` and `K = ⟨b⟩`, the cyclic subgroups generated
  by `a` and `b`. They have cardinalities 2 and 3 respectively.
  -/
  set H : Subgroup G := Subgroup.zpowers a with hH_def
  set K : Subgroup G := Subgroup.zpowers b with hK_def
  have hCardH : Fintype.card H = 2 := by
    show Fintype.card (Subgroup.zpowers a) = 2
    rw [Fintype.card_zpowers, ha]
  have hCardK : Fintype.card K = 3 := by
    show Fintype.card (Subgroup.zpowers b) = 3
    rw [Fintype.card_zpowers, hb]
  have hNatCardH : Nat.card H = 2 := by
    rw [Nat.card_eq_fintype_card]; exact hCardH
  have hNatCardK : Nat.card K = 3 := by
    rw [Nat.card_eq_fintype_card]; exact hCardK
  /-
  Step 3: `H` and `K` are disjoint as subgroups: any common element has order
  dividing both `2` and `3`, hence order `1`, hence equals `1`.
  -/
  have hDisj : Disjoint H K := by
    rw [Subgroup.disjoint_def]
    intro x hxH hxK
    have hx2 : orderOf x ∣ 2 := by
      have h := orderOf_dvd_card (x := (⟨x, hxH⟩ : H))
      rwa [Subgroup.orderOf_mk, hCardH] at h
    have hx3 : orderOf x ∣ 3 := by
      have h := orderOf_dvd_card (x := (⟨x, hxK⟩ : K))
      rwa [Subgroup.orderOf_mk, hCardK] at h
    have h1 : orderOf x = 1 := by
      have hgcd : orderOf x ∣ Nat.gcd 2 3 := Nat.dvd_gcd hx2 hx3
      simpa using hgcd
    exact orderOf_eq_one_iff.mp h1
  /-
  Step 4: `K` has index 2 in `G`, hence `K` is normal.
  -/
  have hKindex2 : K.index = 2 := by
    have hLag := K.card_mul_index
    rw [hNatCardK, hNatCardG] at hLag
    omega
  haveI hKnormal : K.Normal := Subgroup.normal_of_index_eq_two hKindex2
  /-
  Step 5: `H` is *not* normal in `G`. Otherwise, both `H` and `K` would be
  normal with trivial intersection, hence elementwise commute. In particular
  `a * b = b * a`. Then `orderOf (a * b) = 6 = card G`, so `G` is cyclic and
  hence commutative, contradicting `hG'`.
  -/
  have hHnotNormal : ¬ H.Normal := by
    intro hHnormal
    have hab_comm : Commute a b :=
      Subgroup.commute_of_normal_of_disjoint H K hHnormal hKnormal hDisj a b
        (Subgroup.mem_zpowers a) (Subgroup.mem_zpowers b)
    have hcoprime : (orderOf a).Coprime (orderOf b) := by
      rw [ha, hb]; decide
    have hord_ab : orderOf (a * b) = 6 := by
      rw [hab_comm.orderOf_mul_eq_mul_orderOf_of_coprime hcoprime, ha, hb]
    have hcyc : IsCyclic G :=
      isCyclic_of_orderOf_eq_card (a * b) (by rw [hord_ab, hNatCardG])
    have hcomm := (IsCyclic.commutative (α := G)).comm
    obtain ⟨x, y, hxy⟩ := hG'
    exact hxy (hcomm x y)
  /-
  Step 6: `H.normalCore = ⊥`. Indeed, `H.normalCore.subgroupOf H` is a subgroup
  of the prime-order group `H`, so it is either `⊥` or `⊤`. The `⊤` case forces
  `H.normalCore = H`, which would make `H` normal — contradicting Step 5.
  Hence it is `⊥`, i.e. `H.normalCore` is disjoint from `H`. Combined with
  `H.normalCore ≤ H`, this gives `H.normalCore = ⊥`.
  -/
  have hNormCore : H.normalCore = ⊥ := by
    haveI : Fact (Nat.card H).Prime := ⟨hNatCardH ▸ Nat.prime_two⟩
    rcases (H.normalCore.subgroupOf H).eq_bot_or_eq_top_of_prime_card with hbot | htop
    · rw [Subgroup.subgroupOf_eq_bot] at hbot
      have hsub : H.normalCore ⊓ H = H.normalCore := inf_of_le_left H.normalCore_le
      have : H.normalCore ⊓ H ≤ ⊥ := hbot.le_bot
      rw [hsub] at this
      exact le_bot_iff.mp this
    · rw [Subgroup.subgroupOf_eq_top] at htop
      have h_eq : H.normalCore = H := le_antisymm H.normalCore_le htop
      exact absurd (h_eq ▸ H.normalCore_normal) hHnotNormal
  /-
  Step 7: The action of `G` on `G ⧸ H` by left multiplication gives a group
  homomorphism `φ : G →* Equiv.Perm (G ⧸ H)`. Its kernel is `H.normalCore`,
  which is `⊥` by Step 6, so `φ` is injective.
  -/
  set φ : G →* Equiv.Perm (G ⧸ H) := MulAction.toPermHom G (G ⧸ H) with hφ_def
  have hker : φ.ker = ⊥ := by
    rw [hφ_def, ← Subgroup.normalCore_eq_ker]
    exact hNormCore
  have hφ_inj : Function.Injective φ := (MonoidHom.ker_eq_bot_iff φ).mp hker
  /-
  Step 8: `Fintype.card (G ⧸ H) = 3` (Lagrange's identity), and therefore
  `Fintype.card (Equiv.Perm (G ⧸ H)) = 3! = 6 = Fintype.card G`. Combined
  with injectivity from Step 7, `φ` is bijective.
  -/
  have hCardQuot : Fintype.card (G ⧸ H) = 3 := by
    have hLag : Nat.card G = Nat.card (G ⧸ H) * Nat.card H :=
      Subgroup.card_eq_card_quotient_mul_card_subgroup H
    rw [hNatCardG, hNatCardH, Nat.card_eq_fintype_card] at hLag
    omega
  have hCardPerm : Fintype.card (Equiv.Perm (G ⧸ H)) = 6 := by
    rw [Fintype.card_perm, hCardQuot]; rfl
  have hφ_bij : Function.Bijective φ := by
    rw [Fintype.bijective_iff_injective_and_card]
    refine ⟨hφ_inj, ?_⟩
    rw [hCardG, hCardPerm]
  /-
  Step 9: Promote the bijective hom to a `MulEquiv`, and compose with the
  multiplicative equivalence `Equiv.Perm (G ⧸ H) ≃* Equiv.Perm (Fin 3)` induced
  by the bijection `(G ⧸ H) ≃ Fin 3` (from equal cardinalities).
  -/
  let ψ : G ≃* Equiv.Perm (G ⧸ H) := MulEquiv.ofBijective φ hφ_bij
  let e : G ⧸ H ≃ Fin 3 := Fintype.equivFinOfCardEq hCardQuot
  let χ : Equiv.Perm (G ⧸ H) ≃* Equiv.Perm (Fin 3) := Equiv.permCongrHom e
  exact ⟨ψ.trans χ⟩
