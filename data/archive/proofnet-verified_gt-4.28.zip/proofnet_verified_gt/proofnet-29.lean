import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that for all $n>1$ that $\mathbb{Z}/n\mathbb{Z}$ is not a group under multiplication of residue classes.
-/

/-Informal Proof

Note that since $n>1, \overline{1} \neq \overline{0}$. Now suppose $\mathbb{Z} /(n)$ contains a multiplicative identity element $\bar{e}$. Then in particular,
$$
\bar{e} \cdot \overline{1}=\overline{1}
$$
so that $\bar{e}=\overline{1}$. Note, however, that
$$
\overline{0} \cdot \bar{k}=\overline{0}
$$
for all k, so that $\overline{0}$ does not have a multiplicative inverse. Hence $\mathbb{Z} /(n)$ is not a group under multiplication.
-/

theorem Dummit_Foote_exercise_1_1_5 (n : ℕ) (hn : 1 < n) :
  IsEmpty (Group (ZMod n)) := by
  sorry

/-!
### Helper: `ZMod 2` carries *some* group structure

The formal statement claims `IsEmpty (Group (ZMod n))`, i.e. that the *type* `ZMod n`
admits no group structure at all.  The informal exercise only says that `ZMod n` fails to
be a group under multiplication of residue classes.  These are very different claims: a
type-level statement versus a statement about one particular operation.  Since `ZMod n` is
a nonempty type carrying an additive group structure, we may simply *rename* addition to
multiplication and obtain a genuine term of `Group (ZMod n)`.  Hence the formal statement
is false for every `n`, in particular for `n = 2`.
-/

/-- Step 1: A `Group` structure on the type `ZMod 2`, obtained by writing the additive
group `(ZMod 2, +, 0, -)` multiplicatively.

Step 1.1: `Multiplicative α` is by definition the type `α` itself (`def Multiplicative
(α : Type*) := α`), carrying the multiplicative group instance induced from the additive
group structure on `α`.

Step 1.2: Therefore `Group (Multiplicative (ZMod 2))` is definitionally `Group (ZMod 2)`,
and `inferInstanceAs` produces the required instance.  Note that this group's
multiplication is *not* residue-class multiplication — it is residue-class addition — which
is exactly why the informal statement is true while the formal one is false. -/
def groupZMod2 : Group (ZMod 2) :=
  inferInstanceAs (Group (Multiplicative (ZMod 2)))

/-! ## Refutation
The original statement `Dummit_Foote_exercise_1_1_5` is false: `Dummit_Foote_exercise_1_1_5_neg` proves the negation of its elaborated type. -/
theorem Dummit_Foote_exercise_1_1_5_neg : ¬ (type_of% @Dummit_Foote_exercise_1_1_5) := by
  -- Step 2: Assume the universally quantified statement.
  intro h
  -- Step 3: Specialise it to the counterexample `n = 2`, which satisfies `1 < 2`.
  -- This yields `IsEmpty (Group (ZMod 2))`.
  have hEmpty : IsEmpty (Group (ZMod 2)) := h 2 (by norm_num)
  -- Step 4: But `groupZMod2` inhabits `Group (ZMod 2)`, contradicting emptiness.
  exact hEmpty.false groupZMod2

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_1_1_5_corrected (n : ℕ) (hn : 1 < n) :
  ¬ (∀ x : ZMod n, ∃ y : ZMod n, x * y = (1 : ZMod n) ∧ y * x = 1) := by
  classical
  -- Step 1: Register the inequality `1 < n` as a typeclass fact so that `ZMod n` is nontrivial.
  haveI : Fact (1 < n) := ⟨hn⟩
  -- Step 2: Work by contradiction, assuming every element possesses a two-sided inverse.
  intro hAllInv
  -- Step 3: Instantiate the assumption with the residue class `0`.
  obtain ⟨k, hk⟩ := hAllInv 0
  -- Step 4: Extract the left inverse claim for `0` and simplify it.
  -- Step 4.1: The product `0 * k` simplifies to `0`, contradicting `hk.1`.
  have hZeroMul : (0 : ZMod n) * k = 0 := zero_mul k
  -- Step 4.2: Combine the simplification with `hk.1` to deduce `0 = 1`.
  have hContr : (0 : ZMod n) = 1 := by
    simpa [hZeroMul] using hk.1
  -- Step 5: Derive the final contradiction from the nontriviality of `ZMod n`.
  have : (0 : ZMod n) ≠ 1 := zero_ne_one
  exact this hContr
