import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

/-Informal Statement

Let $X$ be a compact Hausdorff space that is the union of the closed subspaces $X_1$ and $X_2$. If $X_1$ and $X_2$ are metrizable, show that $X$ is metrizable.
-/

/-Informal Proof

Both $X_1$ and $X_2$ are compact, Hausdorff and metrizable, so by exercise 3 they are second countable, i.e. there are countable bases $\left\{U_{i, n} \subset X_i \mid n \in \mathbb{N}\right\}$ for $i \in\{1,2\}$. By the same exercise it is enough to show that $X$ is second countable. If $X_1 \cap X_2=\emptyset$ both $X_1$ and $X_2$ are open and the union $\left\{U_{i, n} \mid i \in\{1,2\} ; n \in \mathbb{N}\right\}$ of their countable bases form a countable base for $X$.

Suppose now $X_1 \cap X_2 \neq \emptyset$. Let $x \in X$ and $U \subset X$ be an open neighborhood of $x$. If $x \in X_i-X_j=X-$ $X_j$ then $U \cap X_i$ is open in $X_i$ and there is a basis neighborhood $U_{i, n}$ of $x$ such that $x \in U_{i, n} \cap X-X_j$ is an open neighborhood of $x$ in the open subset $X-X_j$, so $U_{i, n} \cap X-X_j$ is also open in $X$.
Suppose now that $x \in X_1 \cap X_2$. We have that $U \cap X_i$ is open in $X_i$ so there is a basis neighborhood $U_{i, n_i}$ contained in $U \cap X_i$. By definition of sub-space topology there is some open subset $V_{i, n_i} \subset X$ such that $U_{i, n_i}=$ $X_i \cap V_{i, n_i}$. Then
$$
x \in V_{1, n_1} \cap V_{2, n_2}=\left(V_{1, n_1} \cap V_{2, n_2} \cap X_1\right) \cup\left(V_{1, n_1} \cap V_{2, n_2} \cap X_2\right)=\left(U_{1, n_1} \cap V_{2, n_2}\right) \cup\left(V_{1, n_1} \cap U_{2, n_2}\right) \subset U
$$
Therefore the open subsets $U_{i, n} \cap X-X_j$ and $V_{1, n_1} \cap V_{2, n_2}$ form a countable base for $X$.
-/

/-- Local separation through a closed Hausdorff subspace `S`: two distinct points of `X`
have open neighbourhoods whose intersection misses `S`. -/
lemma Munkres_34_9_sep_aux {X : Type*} [TopologicalSpace X] (S : Set X) (hS : IsClosed S)
    [T2Space S] {x y : X} (hxy : x ≠ y) :
    ∃ U V : Set X, IsOpen U ∧ IsOpen V ∧ x ∈ U ∧ y ∈ V ∧ U ∩ V ∩ S = ∅ := by
  by_cases hx : x ∈ S
  · by_cases hy : y ∈ S
    · -- Step 1: both points lie in `S`; separate them inside `S`.
      have hne : (⟨x, hx⟩ : S) ≠ ⟨y, hy⟩ := fun h => hxy (congrArg Subtype.val h)
      obtain ⟨u, v, hu, hv, hxu, hyv, huv⟩ := t2_separation hne
      -- Step 1.1: lift the relatively open sets to open sets of `X`.
      obtain ⟨U, hU, rfl⟩ := isOpen_induced_iff.mp hu
      obtain ⟨V, hV, rfl⟩ := isOpen_induced_iff.mp hv
      refine ⟨U, V, hU, hV, hxu, hyv, ?_⟩
      -- Step 1.2: a common point in `S` would contradict disjointness in `S`.
      refine Set.subset_empty_iff.mp ?_
      rintro z ⟨⟨hzU, hzV⟩, hzS⟩
      exact Set.disjoint_left.mp huv (show (⟨z, hzS⟩ : S) ∈ Subtype.val ⁻¹' U from hzU) hzV
    · -- Step 2: `y ∉ S`; use the open complement of `S` around `y`.
      refine ⟨univ, Sᶜ, isOpen_univ, hS.isOpen_compl, mem_univ _, hy, ?_⟩
      ext z; simp
  · -- Step 3: `x ∉ S`; use the open complement of `S` around `x`.
    refine ⟨Sᶜ, univ, hS.isOpen_compl, isOpen_univ, hx, mem_univ _, ?_⟩
    ext z; simp

/-- Local basis step through a closed subspace `S` with basis `B`: for `a ∈ U` open, there is
`s ∈ insert ∅ B` whose image lies in `U` and an open `V ∋ a` with `V ∩ S ⊆ val '' s`. -/
lemma Munkres_34_9_basis_aux {X : Type*} [TopologicalSpace X] (S : Set X) (hS : IsClosed S)
    (B : Set (Set S)) (hB : IsTopologicalBasis B) {a : X} {U : Set X} (hU : IsOpen U)
    (ha : a ∈ U) :
    ∃ s ∈ insert ∅ B, Subtype.val '' s ⊆ U ∧
      ∃ V : Set X, IsOpen V ∧ a ∈ V ∧ V ∩ S ⊆ Subtype.val '' s := by
  by_cases h : a ∈ S
  · -- Step 1: `a ∈ S`; pick a basic neighbourhood of `a` inside `S ∩ U`.
    obtain ⟨s, hsB, has, hsU⟩ := hB.exists_subset_of_mem_open (a := (⟨a, h⟩ : S))
      (u := Subtype.val ⁻¹' U) ha (hU.preimage continuous_subtype_val)
    -- Step 1.1: `s` is relatively open, so `s = val ⁻¹' V` for an open `V` of `X`.
    obtain ⟨V, hV, hVs⟩ := isOpen_induced_iff.mp (hB.isOpen hsB)
    refine ⟨s, Or.inr hsB, image_subset_iff.mpr hsU, V, hV, ?_, ?_⟩
    · -- Step 1.2: `a ∈ V` since `⟨a, h⟩ ∈ s = val ⁻¹' V`.
      have : (⟨a, h⟩ : S) ∈ Subtype.val ⁻¹' V := hVs ▸ has
      exact this
    · -- Step 1.3: points of `V ∩ S` are images of points of `s`.
      rintro y ⟨hyV, hyS⟩
      refine ⟨⟨y, hyS⟩, ?_, rfl⟩
      rw [← hVs]
      exact hyV
  · -- Step 2: `a ∉ S`; take `s = ∅` and the open complement `V = Sᶜ`.
    refine ⟨∅, Or.inl rfl, by simp, Sᶜ, hS.isOpen_compl, h, ?_⟩
    rintro y ⟨h1, h2⟩
    exact absurd h2 h1

theorem Munkres_exercise_34_9
  (X : Type*) [TopologicalSpace X] [CompactSpace X]
  (X1 X2 : Set X) (hX1 : IsClosed X1) (hX2 : IsClosed X2)
  (hX : X1 ∪ X2 = univ) (hX1m : MetrizableSpace X1)
  (hX2m : MetrizableSpace X2) : MetrizableSpace X := by
  -- Step 0: register the subspace instances. Each `Xi` is metrizable (hence Hausdorff) and,
  -- being closed in a compact space, compact; so it is second countable.
  haveI := hX1m
  haveI := hX2m
  haveI : CompactSpace X1 := isCompact_iff_compactSpace.mp hX1.isCompact
  haveI : CompactSpace X2 := isCompact_iff_compactSpace.mp hX2.isCompact
  -- Every point of `X` lies in `X1` or in `X2`.
  have hcov : ∀ z : X, z ∈ X1 ∨ z ∈ X2 := fun z => by
    have : z ∈ X1 ∪ X2 := hX ▸ mem_univ z
    exact this
  -- Step 1: `X` is Hausdorff (the formal statement omits this, but it follows from the
  -- closed cover by two Hausdorff subspaces).
  haveI : T2Space X := by
    refine ⟨fun x y hxy => ?_⟩
    -- Step 1.1: separate `x, y` modulo `X1` and modulo `X2`.
    obtain ⟨U1, V1, hU1, hV1, hxU1, hyV1, h1⟩ := Munkres_34_9_sep_aux X1 hX1 hxy
    obtain ⟨U2, V2, hU2, hV2, hxU2, hyV2, h2⟩ := Munkres_34_9_sep_aux X2 hX2 hxy
    -- Step 1.2: intersect; a common point would lie in `X1` or `X2`, contradiction.
    refine ⟨U1 ∩ U2, V1 ∩ V2, hU1.inter hU2, hV1.inter hV2, ⟨hxU1, hxU2⟩, ⟨hyV1, hyV2⟩, ?_⟩
    rw [Set.disjoint_left]
    rintro z ⟨hzU1, hzU2⟩ ⟨hzV1, hzV2⟩
    rcases hcov z with hz | hz
    · have : z ∈ U1 ∩ V1 ∩ X1 := ⟨⟨hzU1, hzV1⟩, hz⟩
      rw [h1] at this; exact this
    · have : z ∈ U2 ∩ V2 ∩ X2 := ⟨⟨hzU2, hzV2⟩, hz⟩
      rw [h2] at this; exact this
  -- Step 2: `X` is second countable.
  haveI : SecondCountableTopology X := by
    -- Step 2.1: countable bases of the two subspaces.
    obtain ⟨B1, hB1c, -, hB1⟩ := exists_countable_basis X1
    obtain ⟨B2, hB2c, -, hB2⟩ := exists_countable_basis X2
    -- Step 2.2: candidate basis: interiors of unions `val '' s1 ∪ val '' s2`.
    let C : Set (Set X) := (fun p : Set X1 × Set X2 =>
      interior (Subtype.val '' p.1 ∪ Subtype.val '' p.2)) '' ((insert ∅ B1) ×ˢ (insert ∅ B2))
    have hCc : C.Countable := ((hB1c.insert ∅).prod (hB2c.insert ∅)).image _
    have hC : IsTopologicalBasis C := by
      refine isTopologicalBasis_of_isOpen_of_nhds ?_ ?_
      · -- Step 2.3: members of `C` are open (they are interiors).
        rintro _ ⟨p, -, rfl⟩
        exact isOpen_interior
      · -- Step 2.4: every neighbourhood contains a member of `C` around the point.
        intro a U haU hU
        obtain ⟨s1, hs1, hs1U, V1, hV1, haV1, hV1s⟩ :=
          Munkres_34_9_basis_aux X1 hX1 B1 hB1 hU haU
        obtain ⟨s2, hs2, hs2U, V2, hV2, haV2, hV2s⟩ :=
          Munkres_34_9_basis_aux X2 hX2 B2 hB2 hU haU
        refine ⟨interior (Subtype.val '' s1 ∪ Subtype.val '' s2), ⟨(s1, s2), ⟨hs1, hs2⟩, rfl⟩,
          ?_, interior_subset.trans (union_subset hs1U hs2U)⟩
        -- Step 2.5: `V1 ∩ V2` is an open neighbourhood of `a` inside the union.
        refine mem_interior.mpr ⟨V1 ∩ V2, ?_, hV1.inter hV2, ⟨haV1, haV2⟩⟩
        rintro y ⟨hy1, hy2⟩
        rcases hcov y with h | h
        · exact Or.inl (hV1s ⟨hy1, h⟩)
        · exact Or.inr (hV2s ⟨hy2, h⟩)
    exact hC.secondCountableTopology hCc
  -- Step 3: compact Hausdorff ⇒ regular; regular + second countable ⇒ metrizable (Urysohn).
  exact metrizableSpace_of_t3_secondCountable X

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace
open scoped Topology

theorem Munkres_exercise_34_9_corrected
  (X : Type*) [TopologicalSpace X] [CompactSpace X] [T2Space X]
  (X1 X2 : Set X) (hX1 : IsClosed X1) (hX2 : IsClosed X2)
  (hX : X1 ∪ X2 = univ) (hX1m : MetrizableSpace X1)
  (hX2m : MetrizableSpace X2) : MetrizableSpace X := by
  classical
  -- Step 1: upgrade the closed subspaces `X1` and `X2` to compact second-countable spaces.
  have hX1compact : IsCompact X1 := hX1.isCompact
  have hX2compact : IsCompact X2 := hX2.isCompact
  have _ : CompactSpace X1 := (isCompact_iff_compactSpace).1 hX1compact
  have _ : CompactSpace X2 := (isCompact_iff_compactSpace).1 hX2compact
  -- Step 2: record the canonical countable bases on `X1` and `X2`.
  let B1 := TopologicalSpace.countableBasis X1
  let B2 := TopologicalSpace.countableBasis X2
  have hB1basis : IsTopologicalBasis B1 := TopologicalSpace.isBasis_countableBasis X1
  have hB2basis : IsTopologicalBasis B2 := TopologicalSpace.isBasis_countableBasis X2
  have hB1count : B1.Countable := TopologicalSpace.countable_countableBasis X1
  have hB2count : B2.Countable := TopologicalSpace.countable_countableBasis X2
  -- Step 3: package each basis element together with the data of an ambient open set in `X`.
  let S1 := { s : Set X1 // s ∈ B1 }
  let S2 := { s : Set X2 // s ∈ B2 }
  have hS1count : Countable S1 := hB1count.to_subtype
  have hS2count : Countable S2 := hB2count.to_subtype
  have hLift1 :
      ∀ s : S1, ∃ V : Set X, IsOpen V ∧ Subtype.val ⁻¹' V = (s : Set X1) := by
        -- Step 3.1: every basis element is open in the subspace, hence comes from an open subset of `X`.
        intro s
        have hsopen : IsOpen (s : Set X1) :=
          TopologicalSpace.isOpen_of_mem_countableBasis (α := X1) s.property
        simpa [S1] using (isOpen_induced_iff.mp hsopen)
  have hLift2 :
      ∀ s : S2, ∃ V : Set X, IsOpen V ∧ Subtype.val ⁻¹' V = (s : Set X2) := by
        -- Step 3.2: same construction for the second closed subspace.
        intro s
        have hsopen : IsOpen (s : Set X2) :=
          TopologicalSpace.isOpen_of_mem_countableBasis (α := X2) s.property
        simpa [S2] using (isOpen_induced_iff.mp hsopen)
  -- Step 4: choose concrete ambient open supersets for every basis element.
  choose lift1 hLift1open hLift1preimage using hLift1
  choose lift2 hLift2open hLift2preimage using hLift2
  -- Step 5: build the candidate global basis consisting of three countable families.
  let ℬ₁ : Set (Set X) := Set.range fun s : S1 => lift1 s ∩ X2ᶜ
  let ℬ₂ : Set (Set X) := Set.range fun s : S2 => lift2 s ∩ X1ᶜ
  let ℬ₁₂ : Set (Set X) := Set.range fun p : S1 × S2 => lift1 p.1 ∩ lift2 p.2
  let ℬ : Set (Set X) := ℬ₁ ∪ ℬ₂ ∪ ℬ₁₂
  -- Step 6: keep track of the obvious open sets that will appear repeatedly.
  have hOpenX1c : IsOpen X1ᶜ := hX1.isOpen_compl
  have hOpenX2c : IsOpen X2ᶜ := hX2.isOpen_compl
  -- Step 7: note that every point outside `X2` (resp. `X1`) actually lies in `X1` (resp. `X2`)
  -- thanks to the covering hypothesis.
  have hSubsetX1 : X2ᶜ ⊆ X1 := by
    intro x hx
    have hxUnion : x ∈ X1 ∪ X2 := by simp [hX]
    rcases hxUnion with hxUnion | hxUnion
    · exact hxUnion
    · exact (hx hxUnion).elim
  have hSubsetX2 : X1ᶜ ⊆ X2 := by
    intro x hx
    have hxUnion : x ∈ X1 ∪ X2 := by simp [hX]
    rcases hxUnion with hxUnion | hxUnion
    · exact (hx hxUnion).elim
    · exact hxUnion
  -- Step 8: check that all sets in ℬ are open.
  have hOpenℬ : ∀ U ∈ ℬ, IsOpen U := by
    intro U hU
    rcases hU with hU | hU
    · rcases hU with hU | hU
      · rcases hU with ⟨s, rfl⟩
        exact (hLift1open s).inter hOpenX2c
      · rcases hU with ⟨s, rfl⟩
        exact (hLift2open s).inter hOpenX1c
    · rcases hU with ⟨p, rfl⟩
      exact (hLift1open p.1).inter (hLift2open p.2)
  -- Step 9: prove the local basis property demanded by `isTopologicalBasis_of_isOpen_of_nhds`.
  have hBasisℬ :
      IsTopologicalBasis ℬ := by
        refine
          isTopologicalBasis_of_isOpen_of_nhds hOpenℬ ?_
        -- Step 9.1: fix an arbitrary point and an open neighbourhood.
        intro x U hxU hUopen
        have hxUnion : x ∈ X1 ∪ X2 := by simp [hX]
        -- Step 9.2: split into the three mutually exclusive cases.
        by_cases hx1 : x ∈ X1
        · by_cases hx2 : x ∈ X2
          -- Step 9.2.1: x belongs to both closed subspaces.
          ·
            -- Step 9.2.1.1: build basic neighbourhoods inside X1 and X2.
            set x1 : X1 := ⟨x, hx1⟩
            set x2 : X2 := ⟨x, hx2⟩
            have hUx1 :
                IsOpen ((Subtype.val : X1 → X) ⁻¹' U) :=
              (continuous_subtype_val :
                  Continuous fun p : X1 => (p : X)).isOpen_preimage
                (s := U) hUopen
            have hUx2 :
                IsOpen ((Subtype.val : X2 → X) ⁻¹' U) :=
              (continuous_subtype_val :
                  Continuous fun p : X2 => (p : X)).isOpen_preimage
                (s := U) hUopen
            have hxUx1 : x1 ∈ (Subtype.val : X1 → X) ⁻¹' U := by
              simpa using hxU
            have hxUx2 : x2 ∈ (Subtype.val : X2 → X) ⁻¹' U := by
              simpa using hxU
            obtain ⟨s, hsB1, hxs, hsSubset⟩ :=
              hB1basis.exists_subset_of_mem_open hxUx1 hUx1
            obtain ⟨t, htB2, hxt, htSubset⟩ :=
              hB2basis.exists_subset_of_mem_open hxUx2 hUx2
            -- Step 9.2.1.2: pass back to open subsets of X and assemble an element of ℬ₁₂.
            refine ⟨lift1 ⟨s, hsB1⟩ ∩ lift2 ⟨t, htB2⟩,
              Or.inr ⟨⟨⟨s, hsB1⟩, ⟨t, htB2⟩⟩, rfl⟩, ?_, ?_⟩
            · -- Step 9.2.1.3: x lies in the constructed basic open.
              have hxs' :
                  (x : X) ∈ lift1 ⟨s, hsB1⟩ := by
                have :
                    (x1 : X1) ∈ (Subtype.val : X1 → X) ⁻¹' lift1 ⟨s, hsB1⟩ := by
                  simpa [hLift1preimage ⟨s, hsB1⟩] using hxs
                simpa using this
              have hxt' :
                  (x : X) ∈ lift2 ⟨t, htB2⟩ := by
                have :
                    (x2 : X2) ∈ (Subtype.val : X2 → X) ⁻¹' lift2 ⟨t, htB2⟩ := by
                  simpa [hLift2preimage ⟨t, htB2⟩] using hxt
                simpa using this
              exact ⟨hxs', hxt'⟩
            · -- Step 9.2.1.4: any point in this basic open still lies inside the target open set.
              intro z hz
              have hzUnion : z ∈ X1 ∪ X2 := by simp [hX]
              rcases hzUnion with hzUnion | hzUnion
              ·
                have hzX1 : z ∈ X1 := hzUnion
                have hzmem :
                    (⟨z, hzX1⟩ : X1) ∈ s := by
                  have hzpre :
                      (⟨z, hzX1⟩ : X1) ∈
                        (Subtype.val : X1 → X) ⁻¹' lift1 ⟨s, hsB1⟩ := by
                    simpa using hz.1
                  simpa [hLift1preimage ⟨s, hsB1⟩] using hzpre
                have := hsSubset hzmem
                simpa using this
              ·
                have hzX2 : z ∈ X2 := hzUnion
                have hzmem :
                    (⟨z, hzX2⟩ : X2) ∈ t := by
                  have hzpre :
                      (⟨z, hzX2⟩ : X2) ∈
                        (Subtype.val : X2 → X) ⁻¹' lift2 ⟨t, htB2⟩ := by
                    simpa using hz.2
                  simpa [hLift2preimage ⟨t, htB2⟩] using hzpre
                have := htSubset hzmem
                simpa using this
          -- Step 9.2.2: x belongs to X1 but not to X2.
          ·
            set x1 : X1 := ⟨x, hx1⟩
            have hUx1 :
                IsOpen ((Subtype.val : X1 → X) ⁻¹' U) :=
              (continuous_subtype_val :
                  Continuous fun p : X1 => (p : X)).isOpen_preimage
                (s := U) hUopen
            have hxUx1 : x1 ∈ (Subtype.val : X1 → X) ⁻¹' U := by
              simpa using hxU
            obtain ⟨s, hsB1, hxs, hsSubset⟩ :=
              hB1basis.exists_subset_of_mem_open hxUx1 hUx1
            refine ⟨lift1 ⟨s, hsB1⟩ ∩ X2ᶜ,
              Or.inl <| Or.inl ⟨⟨s, hsB1⟩, rfl⟩, ?_, ?_⟩
            ·
              have hxs' :
                  (x : X) ∈ lift1 ⟨s, hsB1⟩ := by
                have :
                    (x1 : X1) ∈ (Subtype.val : X1 → X) ⁻¹' lift1 ⟨s, hsB1⟩ := by
                  simpa [hLift1preimage ⟨s, hsB1⟩] using hxs
                simpa using this
              exact ⟨hxs', by simpa using hx2⟩
            ·
              intro z hz
              have hzX1 : z ∈ X1 := hSubsetX1 hz.2
              have hzmem :
                  (⟨z, hzX1⟩ : X1) ∈ s := by
                have hzpre :
                    (⟨z, hzX1⟩ : X1) ∈
                      (Subtype.val : X1 → X) ⁻¹' lift1 ⟨s, hsB1⟩ := by
                  simpa using hz.1
                simpa [hLift1preimage ⟨s, hsB1⟩] using hzpre
              have := hsSubset hzmem
              simpa using this
        -- Step 9.2.3: x does not belong to X1, so it must lie in X2 by the covering hypothesis.
        ·
          have hx2 : x ∈ X2 := by
            rcases hxUnion with hxUnion | hxUnion
            · exact (hx1 hxUnion).elim
            · exact hxUnion
          set x2 : X2 := ⟨x, hx2⟩
          have hUx2 :
              IsOpen ((Subtype.val : X2 → X) ⁻¹' U) :=
            (continuous_subtype_val :
                Continuous fun p : X2 => (p : X)).isOpen_preimage
              (s := U) hUopen
          have hxUx2 : x2 ∈ (Subtype.val : X2 → X) ⁻¹' U := by
            simpa using hxU
          obtain ⟨s, hsB2, hxs, hsSubset⟩ :=
            hB2basis.exists_subset_of_mem_open hxUx2 hUx2
          refine ⟨lift2 ⟨s, hsB2⟩ ∩ X1ᶜ,
            Or.inl <| Or.inr ⟨⟨s, hsB2⟩, rfl⟩, ?_, ?_⟩
          ·
            have hxs' :
                (x : X) ∈ lift2 ⟨s, hsB2⟩ := by
              have :
                  (x2 : X2) ∈ (Subtype.val : X2 → X) ⁻¹' lift2 ⟨s, hsB2⟩ := by
                simpa [hLift2preimage ⟨s, hsB2⟩] using hxs
              simpa using this
            exact ⟨hxs', by simpa using hx1⟩
          ·
            intro z hz
            have hzX2 : z ∈ X2 := hSubsetX2 hz.2
            have hzmem :
                (⟨z, hzX2⟩ : X2) ∈ s := by
              have hzpre :
                  (⟨z, hzX2⟩ : X2) ∈
                    (Subtype.val : X2 → X) ⁻¹' lift2 ⟨s, hsB2⟩ := by
                simpa using hz.1
              simpa [hLift2preimage ⟨s, hsB2⟩] using hzpre
            have := hsSubset hzmem
            simpa using this
  -- Step 10: register that ℬ is countable.
  have hℬcount : ℬ.Countable := by
    have hℬ₁count : ℬ₁.Countable :=
      (countable_range fun s : S1 => lift1 s ∩ X2ᶜ)
    have hℬ₂count : ℬ₂.Countable :=
      (countable_range fun s : S2 => lift2 s ∩ X1ᶜ)
    have hℬ₁₂count : ℬ₁₂.Countable :=
      (countable_range fun p : S1 × S2 => lift1 p.1 ∩ lift2 p.2)
    exact (hℬ₁count.union hℬ₂count).union hℬ₁₂count
  -- Step 11: obtain a second-countable topology on `X` from the constructed basis.
  have hSC : SecondCountableTopology X := hBasisℬ.secondCountableTopology hℬcount
  -- Step 12: conclude metrizability via Urysohn's metrization theorem for compact Hausdorff spaces.
  exact TopologicalSpace.metrizableSpace_of_t3_secondCountable X
