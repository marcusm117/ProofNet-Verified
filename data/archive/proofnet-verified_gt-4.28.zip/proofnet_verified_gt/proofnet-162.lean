import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Suppose $\left\{p_{n}\right\}$ is a Cauchy sequence in a metric space $X$, and some sequence $\left\{p_{n l}\right\}$ converges to a point $p \in X$. Prove that the full sequence $\left\{p_{n}\right\}$ converges to $p$.
-/

/-Informal Proof

Let $\varepsilon>0$. Choose $N_1$ so large that $d\left(p_m, p_n\right)<\frac{\varepsilon}{2}$ if $m>N_1$ and $n>N_1$. Then choose $N \geq N_1$ so large that $d\left(p_{n_k}, p\right)<\frac{\varepsilon}{2}$ if $k>N$. Then if $n>N$, we have
$$
d\left(p_n, p\right) \leq d\left(p_n, p_{n_{N+1}}\right)+d\left(p_{n_{N+1}}, p\right)<\varepsilon
$$
For the first term on the right is less than $\frac{\varepsilon}{2}$ since $n>N_1$ and $n_{N+1}>N+1>$ $N_1$. The second term is less than $\frac{\varepsilon}{2}$ by the choice of $N$.
-/

theorem Rudin_exercise_3_20 {X : Type*} [MetricSpace X]
  (p : ℕ → X) (l : ℕ) (r : X)
  (hp : CauchySeq p)
  (hpl : Tendsto (λ n => p (l * n)) atTop (𝓝 r)) :
  Tendsto p atTop (𝓝 r) := by
  sorry

/-- **Helper.**  The statement of `Rudin_exercise_3_20`, specialised to the metric
space `X = ULift ℝ` (which lives in an arbitrary universe `u`, so that it can be fed
to the universe-polymorphic original statement), is contradictory.

The defect: the original formalization quantifies over *all* `l : ℕ`, including
`l = 0`.  For `l = 0` the index map `n ↦ l * n` is constantly `0`, so
`fun n => p (l * n)` is the constant sequence `p 0` rather than a genuine
subsequence; the hypothesis `hpl` then merely says `r = p 0`.  Hence the statement
as written asserts that *every* Cauchy sequence converges to its own first term. -/
theorem helper162
    (H : ∀ (q : ℕ → ULift.{u} ℝ) (l : ℕ) (s : ULift.{u} ℝ),
      CauchySeq q → Tendsto (fun n => q (l * n)) atTop (𝓝 s) → Tendsto q atTop (𝓝 s)) :
    False := by
  -- Step 1: the counterexample sequence `0, 1, 1, 1, ...`, transported into `ULift ℝ`.
  set q : ℕ → ULift.{u} ℝ := fun n => ULift.up (if n = 0 then (0 : ℝ) else 1) with hq_def
  -- Step 2: `q` converges to `ULift.up 1`, being constantly `ULift.up 1` from index `1` on.
  have h1 : Tendsto q atTop (𝓝 (ULift.up.{u} (1 : ℝ))) := by
    apply tendsto_atTop_of_eventually_const (i₀ := 1)
    intro i hi
    -- Step 2.1: for `i ≥ 1` we have `i ≠ 0`, so `q i = ULift.up 1`.
    have hi0 : i ≠ 0 := by omega
    simp [hq_def, hi0]
  -- Step 3: a convergent sequence in a metric space is Cauchy, so hypothesis `hp` holds.
  have hcauchy : CauchySeq q := h1.cauchySeq
  -- Step 4: for `l = 0` the map `fun n => q (0 * n)` is the constant sequence
  -- `q 0 = ULift.up 0`, hence converges to `ULift.up 0`; this discharges `hpl`.
  have h0 : Tendsto (fun n => q (0 * n)) atTop (𝓝 (ULift.up.{u} (0 : ℝ))) := by
    simp [hq_def]
  -- Step 5: the statement, applied with `l = 0` and `r = ULift.up 0`, forces the
  -- full sequence `q` to converge to `ULift.up 0`.
  have h2 : Tendsto q atTop (𝓝 (ULift.up.{u} (0 : ℝ))) := H q 0 (ULift.up (0 : ℝ)) hcauchy h0
  -- Step 6: limits in a metric space (a T2 space) are unique, so `up 0 = up 1`.
  have hup : ULift.up.{u} (0 : ℝ) = ULift.up.{u} (1 : ℝ) := tendsto_nhds_unique h2 h1
  -- Step 7: `ULift.up` is injective, giving `(0 : ℝ) = 1`, a contradiction.
  have hcontr : (0 : ℝ) = 1 := congrArg ULift.down hup
  norm_num at hcontr

/-! ## Refutation
The original statement `Rudin_exercise_3_20` is false: `Rudin_exercise_3_20_neg` proves the negation of its elaborated type. -/
theorem Rudin_exercise_3_20_neg : ¬ (type_of% @Rudin_exercise_3_20) := by
  -- Step 8: instantiate the universally quantified statement at `X = ULift ℝ`
  -- (in the same universe as the statement's `X`) and invoke `helper162`.
  intro h
  exact helper162 (fun q l s hc hl => h q l s hc hl)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

/-
The original formalization is weaker than the informal statement. The informal statement says:
"Suppose {p_n} is a Cauchy sequence in a metric space X, and some *subsequence* {p_{n_k}}
converges to a point p ∈ X. Prove that the full sequence {p_n} converges to p."

The original Lean theorem restricts the subsequence to the very specific arithmetic form
n ↦ p(l · n) for a fixed positive integer l : ℕ+. This only covers subsequences whose
indices form an arithmetic progression (e.g., every 2nd term, every 3rd term, etc.).
However, the informal statement allows *any* subsequence, indexed by an arbitrary strictly
increasing function φ : ℕ → ℕ (e.g., φ(k) = k², φ(k) = 2^k, or any other strictly
increasing index sequence). Since the Lean hypothesis is strictly more restrictive than
the informal hypothesis (while the conclusion is the same), the Lean theorem is logically
weaker than what the informal statement claims.

The corrected version below uses a general strictly increasing function φ : ℕ → ℕ to
index the subsequence, which faithfully captures "some subsequence converges" from the
informal statement. A strictly increasing function φ satisfies φ(n) ≥ n for all n
(hence Tendsto φ atTop atTop), making it the standard mathematical formalization of
"subsequence."
-/

theorem Rudin_exercise_3_20_corrected {X : Type*} [MetricSpace X]
  (p : ℕ → X) (φ : ℕ → ℕ) (r : X)
  (hp : CauchySeq p)
  (hφ : StrictMono φ)
  (hpl : Tendsto (p ∘ φ) atTop (𝓝 r)) :
  Tendsto p atTop (𝓝 r) := by
  -- Step 1: We apply the Mathlib lemma `tendsto_nhds_of_cauchySeq_of_subseq`.
  -- This lemma states: if u is a Cauchy sequence, f : ι → β tends to atTop,
  -- and u ∘ f converges to a, then u converges to a.
  -- We instantiate it with u := p, f := φ, p := atTop, a := r.
  exact tendsto_nhds_of_cauchySeq_of_subseq
    -- Step 1.1: The full sequence p is Cauchy (given by hypothesis `hp`).
    hp
    -- Step 1.2: The index function φ tends to atTop.
    -- Since φ is strictly monotone on ℕ, it tends to infinity.
    -- Mathlib provides `StrictMono.tendsto_atTop` for this.
    hφ.tendsto_atTop
    -- Step 1.3: The subsequence p ∘ φ converges to r (given by hypothesis `hpl`).
    hpl
