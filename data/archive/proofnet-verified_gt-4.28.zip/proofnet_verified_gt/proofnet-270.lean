import Mathlib


open Fintype Set Real Ideal Polynomial
open scoped BigOperators
noncomputable section

/-Informal Statement

If $a^2 = 0$ in $R$, show that $ax + xa$ commutes with $a$.
-/

/-Informal Proof

We need to show that
$$
a(a x+x a)=(a x+x a) a \text { for } a, x \in R .
$$
Now,
$$
\begin{gathered}
a(a x+x a)=a(a x)+a(x a) \\
=a^2 x+a x a \\
=0+a x a=a x a .
\end{gathered}
$$
Again,
$$
\begin{gathered}
(a x+x a) a=(a x) a+(x a) a \\
=a x a+x a^2 \\
=a x a+0=a x a .
\end{gathered}
$$
It follows that,
$$
a(a x+x a)=(a x+x a) a, \text { for } x, a \in R .
$$
This shows that $a x+x a$ commutes with $a$. This completes the proof.
-/

theorem Herstein_exercise_4_2_6 {R : Type*} [Ring R] (a x : R)
  (h : a ^ 2 = 0) : a * (a * x + x * a) = (x + x * a) * a := by
  sorry

/-! ### Helper lemmas for the counterexample

The counterexample lives in `ZMod 4` (with `a = 2`, `x = 1`), but the statement to
be refuted quantifies over rings in an arbitrary universe `Type u`.  We therefore
transport `ZMod 4` up with `ULift`.  All the `ULift` ring operations are defined
componentwise, so every arithmetic identity below holds by `rfl` on the
`ULift.down` components. -/

/-- Step A: the hypothesis `a ^ 2 = 0` holds for `a = 2` in (a lift of) `ZMod 4`,
since `2 ^ 2 = 4 = 0` there. -/
private lemma ulift_zmod_four_sq :
    (ULift.up (2 : ZMod 4) : ULift (ZMod 4)) ^ 2 = 0 :=
  congrArg ULift.up (by decide)

/-- Step B: in `ZMod 4` the two sides of the (mistranscribed) conclusion differ
for `a = 2`, `x = 1`: the left side is `2 * (2 + 2) = 2 * 0 = 0` while the right
side is `(1 + 2) * 2 = 3 * 2 = 2`. -/
private lemma zmod_four_ne :
    (2 : ZMod 4) * (2 * 1 + 1 * 2) ≠ (1 + 1 * 2) * 2 := by decide

/-! ## Refutation
The original statement `Herstein_exercise_4_2_6` is false: `Herstein_exercise_4_2_6_neg` proves the negation of its elaborated type. -/
theorem Herstein_exercise_4_2_6_neg : ¬ (type_of% @Herstein_exercise_4_2_6) := by
  -- Step 1: Assume the (mistranscribed) statement holds for every ring.
  -- The formalization's right-hand side is `(x + x * a) * a` rather than
  -- `(a * x + x * a) * a`, i.e. the leading `a *` was dropped.  Under `a ^ 2 = 0`
  -- the left-hand side reduces to `a * x * a` and the right-hand side to `x * a`,
  -- so the claim is `a * x * a = x * a`, which is not a consequence of `a ^ 2 = 0`.
  intro h
  -- Step 2: Instantiate at the ring `R = ULift (ZMod 4)` with `a = ULift.up 2`
  -- and `x = ULift.up 1`.  (`ULift` only moves `ZMod 4` into the universe the
  -- statement quantifies over; it changes no arithmetic.)
  --   * hypothesis: `a ^ 2 = 2 ^ 2 = 4 = 0`   (`ulift_zmod_four_sq`);
  --   * left-hand side:  `2 * (2 * 1 + 1 * 2) = 2 * 0 = 0`;
  --   * right-hand side: `(1 + 1 * 2) * 2 = 3 * 2 = 6 = 2`.
  have key := @h (ULift (ZMod 4)) _ (ULift.up (2 : ZMod 4)) (ULift.up (1 : ZMod 4))
    ulift_zmod_four_sq
  -- Step 3: Push the equality down to `ZMod 4`.  Every `ULift` operation is
  -- componentwise, so `congrArg ULift.down` yields exactly the `ZMod 4` equation.
  have key' : (2 : ZMod 4) * (2 * 1 + 1 * 2) = (1 + 1 * 2) * 2 := congrArg ULift.down key
  -- Step 4: But that equation says `0 = 2` in `ZMod 4`, which is false.
  exact zmod_four_ne key'

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Set Real Ideal Polynomial
open scoped BigOperators

theorem Herstein_exercise_4_2_6_corrected {R : Type*} [Ring R] (a x : R)
  (h : a ^ 2 = 0) : a * (a * x + x * a) = (a * x + x * a) * a := by
  -- Step 1: Rewrite the squared hypothesis so we can substitute it into products later.
  have h_mul_sq : a * a = 0 := by
    -- Step 1.1: Use the identity `a ^ 2 = a * a` (lemma `pow_two`) to translate the assumption.
    simpa [pow_two] using h
  -- Step 2: Expand the left-hand side using distributivity and associativity so only triple products remain.
  have h_left : a * (a * x + x * a) = a * x * a := by
    -- Step 2.1: Apply left distributivity of multiplication over addition.
    calc
      a * (a * x + x * a)
          = a * (a * x) + a * (x * a) := by
            -- Step 2.1.1: Direct application of `mul_add`.
            simp [mul_add]
      _ = (a * a) * x + a * (x * a) := by
            -- Step 2.2: Reassociate the first summand via associativity.
            simp [mul_assoc]
      _ = (a * a) * x + (a * x) * a := by
            -- Step 2.3: Reassociate the second summand.
            simp [mul_assoc]
      _ = 0 * x + (a * x) * a := by
            -- Step 2.4: Substitute `a * a = 0` from Step 1.
            simp [h_mul_sq]
      _ = (0 : R) + (a * x) * a := by
            -- Step 2.5: Recognize multiplication by zero.
            simp
      _ = a * x * a := by
            -- Step 2.6: Drop the leading zero and read `(a * x) * a` as `a * x * a`.
            simp [zero_add]
  -- Step 3: Expand the right-hand side analogously and reduce it to the same triple product.
  have h_right : (a * x + x * a) * a = a * x * a := by
    -- Step 3.1: Apply right distributivity of multiplication over addition.
    calc
      (a * x + x * a) * a
          = (a * x) * a + (x * a) * a := by
            -- Step 3.1.1: Direct application of `add_mul`.
            simp [add_mul]
      _ = (a * x) * a + x * (a * a) := by
            -- Step 3.2: Reassociate the second summand.
            simp [mul_assoc]
      _ = (a * x) * a + x * 0 := by
            -- Step 3.3: Substitute `a * a = 0` using Step 1.
            simp [h_mul_sq]
      _ = (a * x) * a + 0 := by
            -- Step 3.4: Recognize multiplication by zero.
            simp
      _ = a * x * a := by
            -- Step 3.5: Remove the trailing zero and rewrite `(a * x) * a` via associativity notation.
            simp [add_zero]
  -- Step 4: Combine the two reductions to conclude that the two sides are equal.
  calc
    a * (a * x + x * a)
        = a * x * a := h_left
    _ = (a * x + x * a) * a := h_right.symm
