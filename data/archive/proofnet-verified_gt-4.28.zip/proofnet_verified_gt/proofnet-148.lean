import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

If $r$ is rational $(r \neq 0)$ and $x$ is irrational, prove that $r+x$ is irrational.
-/

/-Informal Proof

If $r$ and $r+x$ were both rational, then $x=r+x-r$ would also be rational.
-/

theorem Rudin_exercise_1_1a
  (x : ℝ) (y : ℚ) :
  ( Irrational x ) -> Irrational ( x + y ) := by
  -- Step 1: Assume `x` is irrational, i.e. `x ∉ Set.range ((↑) : ℚ → ℝ)`.
  intro hx
  -- Step 2: Argue by contradiction: suppose `x + ↑y` is rational, say `x + ↑y = ↑q`.
  --   Then `x = ↑q - ↑y = ↑(q - y)` would be rational, contradicting `hx`.
  --   Note that the hypothesis `y ≠ 0` from the informal statement is not needed:
  --   for `y = 0` the claim `Irrational (x + 0)` is just `Irrational x`.
  rintro ⟨q, hq⟩
  -- Step 2.1: From `↑q = x + ↑y` we get `x = ↑(q - y)`, exhibiting `x` as a rational.
  refine hx ⟨q - y, ?_⟩
  -- Step 2.2: Push the cast through the subtraction and finish by linear arithmetic.
  push_cast
  linarith [hq]

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

theorem Rudin_exercise_1_1a_corrected
  (x : ℝ) (y : ℚ) (hy : y ≠ 0) :
  ( Irrational x ) -> Irrational ( x + y ) := by
  -- Step 1: Introduce the hypothesis that `x` is irrational.
  intro hx
  -- Step 1.1: Note the non-zero assumption on `y` so that every given hypothesis is acknowledged.
  have _hy : y ≠ 0 := hy
  -- Step 2: Unfold the definition of irrationality so that we can work directly with rational witnesses.
  dsimp [Irrational] at hx ⊢
  -- Step 3: Assume, aiming for a contradiction, that `x + y` is rational.
  intro hxy
  -- Step 3.1: Extract the rational number `q` whose real value equals `x + y`.
  rcases hxy with ⟨q, hq⟩
  -- Step 4: Use the irrationality of `x` to reach a contradiction by exhibiting a rational expression for `x`.
  apply hx
  -- Step 4.1: Propose `q - y` (which is rational) as the witness that would force `x` to be rational.
  refine ⟨q - y, ?_⟩
  -- Step 4.2: Relate the real casting of `q - y` with the subtraction of their real casts.
  have hcast : ((q - y : ℚ) : ℝ) = (q : ℝ) - y := by
    -- Step 4.2.1: Casting from ℚ to ℝ commutes with subtraction, so we can push the cast inside.
    norm_cast
  -- Step 4.3: Subtract `y` from both sides of the equation `(q : ℝ) = x + y` to isolate `x`.
  have hsubtract : (q : ℝ) - y = x := by
    -- Step 4.3.1: Apply the function `t ↦ t - y` to both sides of `hq`.
    have := congrArg (fun t : ℝ => t - y) hq
    -- Step 4.3.2: Simplify the right-hand side to get rid of `+ y` and `- y`.
    simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using this
  -- Step 4.4: Combine the previous two equalities to conclude that the real cast of `q - y` equals `x`.
  simpa using hcast.trans hsubtract
