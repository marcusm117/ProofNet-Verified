import Mathlib


open Fintype Set Real Ideal Polynomial
open scoped BigOperators
noncomputable section

/-Informal Statement

If $G$ is a group in which $(a b)^{i}=a^{i} b^{i}$ for three consecutive integers $i$, prove that $G$ is abelian.
-/

/-Informal Proof

Let $G$ be a group, $a, b \in G$ and $i$ be any integer. Then from given condition,
$$
\begin{aligned}
(a b)^i & =a^i b^i \\
(a b)^{i+1} & =a^{i+1} b^{i+1} \\
(a b)^{i+2} & =a^{i+2} b^{i+2}
\end{aligned}
$$
From first and second, we get
$$
a^{i+1} b^{i+1}=(a b)^i(a b)=a^i b^i a b \Longrightarrow b^i a=a b^i
$$
From first and third, we get
$$
a^{i+2} b^{i+2}=(a b)^i(a b)^2=a^i b^i a b a b \Longrightarrow a^2 b^{i+1}=b^i a b a
$$
This gives
$$
a^2 b^{i+1}=a\left(a b^i\right) b=a b^i a b=b^i a^2 b
$$
Finally, we get
$$
b^i a b a=b^i a^2 b \Longrightarrow b a=a b
$$
This shows that $G$ is Abelian.
-/

/-- Helper: if `(a*b)^n = a^n * b^n` and `(a*b)^(n+1) = a^(n+1) * b^(n+1)` hold for all
`a b : G`, then every `n`-th power is central. -/
theorem Herstein_exercise_2_2_3_pow_central {G : Type*} [Group G] {n : ℕ}
    (h1 : ∀ a b : G, (a * b) ^ n = a ^ n * b ^ n)
    (h2 : ∀ a b : G, (a * b) ^ (n + 1) = a ^ (n + 1) * b ^ (n + 1)) :
    ∀ a b : G, a * b ^ n = b ^ n * a := by
  intro a b
  -- Step 1: expand `(a*b)^(n+1)` in two ways.
  -- On the left we peel off one factor and use `h1`; on the right we split both powers.
  have h : a ^ n * b ^ n * (a * b) = a ^ n * a * (b ^ n * b) := by
    have h3 := h2 a b
    rw [pow_succ, pow_succ, pow_succ, h1 a b] at h3
    exact h3
  -- Step 2: right-associate so that both sides start with the common factor `a ^ n`.
  have h4 : a ^ n * (b ^ n * (a * b)) = a ^ n * (a * (b ^ n * b)) := by
    simp only [mul_assoc] at h ⊢
    exact h
  -- Step 3: cancel `a ^ n` on the left.
  have h5 : b ^ n * (a * b) = a * (b ^ n * b) := mul_left_cancel h4
  -- Step 4: left-associate so that both sides end with the common factor `b`.
  have h6 : b ^ n * a * b = a * b ^ n * b := by
    simp only [← mul_assoc] at h5 ⊢
    exact h5
  -- Step 5: cancel `b` on the right; this is the claim (up to symmetry).
  exact (mul_right_cancel h6).symm

instance Herstein_exercise_2_2_3 {G : Type*} [Group G]
  {P : ℕ → Prop} {hP : P = λ i => ∀ a b : G, (a*b)^i = a^i * b^i}
  (hP1 : ∃ n : ℕ, P n ∧ P (n+1) ∧ P (n+2)) : CommGroup G := by
  -- Step 1: unfold `P`.  (`subst` is fine here: it only rewrites the variable `P`.)
  subst hP
  -- Step 2: prove commutativity as a `Prop`.  This is essential: the goal `CommGroup G`
  -- lives in `Type`, so the existential `hP1` may only be destructed inside a `Prop` goal.
  have hcomm : ∀ a b : G, a * b = b * a := by
    -- Step 2.1: extract the three consecutive exponents.
    obtain ⟨n, hn, hn1, hn2⟩ := hP1
    -- Step 2.2: from `P n` and `P (n+1)`, every `n`-th power is central.
    have key1 : ∀ a b : G, a * b ^ n = b ^ n * a :=
      Herstein_exercise_2_2_3_pow_central hn hn1
    -- Step 2.3: from `P (n+1)` and `P (n+2)`, every `(n+1)`-st power is central.
    have key2 : ∀ a b : G, a * b ^ (n + 1) = b ^ (n + 1) * a :=
      Herstein_exercise_2_2_3_pow_central hn1 hn2
    -- Step 2.4: combine.  For all `a b`, compute `b ^ n * (a * b)` in two ways:
    --   b^n * (a*b) = b^n * a * b = a * b^n * b = a * b^(n+1) = b^(n+1) * a = b^n * (b*a).
    intro a b
    have e1 : b ^ n * (a * b) = b ^ n * (b * a) := by
      calc b ^ n * (a * b) = b ^ n * a * b := by rw [mul_assoc]
        _ = a * b ^ n * b := by rw [key1 a b]
        _ = a * b ^ (n + 1) := by rw [pow_succ, mul_assoc]
        _ = b ^ (n + 1) * a := key2 a b
        _ = b ^ n * (b * a) := by rw [pow_succ, mul_assoc]
    -- Step 2.5: cancel `b ^ n` on the left.
    exact mul_left_cancel e1
  -- Step 3: upgrade the group structure to a commutative one.
  exact { (inferInstance : Group G) with mul_comm := hcomm }

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Set Real Ideal Polynomial
open scoped BigOperators

/-
## Why the Original Formalization is Not Faithful

The original formalization quantified the index over ℕ (natural numbers):

    {P : ℕ → Prop} {hP : P = λ i => ∀ a b : G, (a*b)^i = a^i * b^i}
    (hP1 : ∃ n : ℕ, P n ∧ P (n+1) ∧ P (n+2))

However, the informal statement says "three consecutive integers", meaning i ranges over ℤ.
Since every natural number is an integer but not vice versa, the ℕ version is a strict special
case: it cannot express hypotheses where the three consecutive integers are negative
(e.g., i = -2, -1, 0). The informal theorem implies the ℕ version, but not conversely —
so the ℕ formalization is logically weaker than the informal claim.

## Correction

We change the existential quantifier from `∃ n : ℕ` to `∃ n : ℤ`, and use integer
exponentiation `zpow` (notation `a ^ (n : ℤ)`) in place of natural-number exponentiation.
Integer powers are well-defined for groups: `g ^ (-k) = (g ^ k)⁻¹`. We also remove the
unnecessary indirection through a predicate `P` and state the hypotheses directly.

The proof strategy is unchanged:
  1. From consecutive identities at exponents k and k+1, derive that `b^k` commutes with
     all group elements.
  2. Apply this for both k = n and k = n+1.
  3. Express b as `(b^n)⁻¹ * b^(n+1)` — a product of two elements that commute with
     everything — to conclude b commutes with every element.
-/

theorem Herstein_exercise_2_2_3_corrected {G : Type*} [Group G]
  (h : ∃ n : ℤ, (∀ a b : G, (a * b) ^ n = a ^ n * b ^ n) ∧
                  (∀ a b : G, (a * b) ^ (n + 1) = a ^ (n + 1) * b ^ (n + 1)) ∧
                  (∀ a b : G, (a * b) ^ (n + 2) = a ^ (n + 2) * b ^ (n + 2))) :
  ∀ a b : G, a * b = b * a := by
  -- Step 1: Fix arbitrary elements `a` and `b` of the group whose commutativity we must show.
  intro a b
  -- Step 2: Obtain an index `n : ℤ` for which the power identity holds at `n`, `n+1`, and `n+2`.
  obtain ⟨n, hPn, hPn1, hPn2⟩ := h
  -- Step 3: Build a helper lemma showing that two consecutive identities force `b^k` to commute
  --         with every `a`. Specifically: if (a*b)^k = a^k * b^k and (a*b)^(k+1) = a^(k+1) * b^(k+1)
  --         for all a, b, then Commute a (b^k) for all a, b.
  have aux :
      ∀ {k : ℤ},
        (∀ a b : G, (a * b) ^ k = a ^ k * b ^ k) →
        (∀ a b : G, (a * b) ^ (k + 1) = a ^ (k + 1) * b ^ (k + 1)) →
        ∀ a b : G, Commute a (b ^ k) := by
    -- Step 3.1: Fix the index `k` and elements `x`, `y`, along with the two consecutive identities.
    intro k hk hk1 x y
    -- Step 3.2: Expand the (k+1) identity using zpow_add_one and hk, then normalize associativity.
    --           LHS: (x*y)^(k+1) = (x*y)^k * (x*y) = (x^k * y^k) * (x * y) = x^k * y^k * x * y
    --           RHS: x^(k+1) * y^(k+1) = (x^k * x) * (y^k * y) = x^k * x * y^k * y
    --           After normalization: ((x^k * y^k) * x) * y = ((x^k * x) * y^k) * y
    have hk1xy : ((x ^ k * y ^ k) * x) * y = ((x ^ k * x) * y ^ k) * y := by
      simpa [zpow_add_one, hk x y, mul_assoc] using hk1 x y
    -- Step 3.3: Cancel the common rightmost factor `y` from both sides.
    have hk1xy_no_y : (x ^ k * y ^ k) * x = (x ^ k * x) * y ^ k := by
      exact mul_right_cancel hk1xy
    -- Step 3.4: Regroup using associativity so that `x^k` becomes a common left factor.
    --           LHS: x^k * (y^k * x)
    --           RHS: x^k * (x * y^k)
    have hk1xy_regroup : x ^ k * (y ^ k * x) = x ^ k * (x * y ^ k) := by
      simpa [mul_assoc] using hk1xy_no_y
    -- Step 3.5: Cancel the common left factor `x^k` to obtain `y^k * x = x * y^k`.
    have hk1xy_comm : y ^ k * x = x * y ^ k := by
      exact mul_left_cancel hk1xy_regroup
    -- Step 3.6: Package the result as `Commute x (y^k)`, i.e., `x * y^k = y^k * x`.
    exact by
      simpa [Commute] using hk1xy_comm.symm
  -- Step 4: Apply the helper with k = n to deduce that `b^n` commutes with every element.
  have commPowN : ∀ a b : G, Commute a (b ^ n) := aux hPn hPn1
  -- Step 5: Apply the helper with k = n+1 to deduce that `b^(n+1)` commutes with every element.
  --         Note: we must convert `n + 2` to `n + 1 + 1` since aux expects the second argument
  --         at exponent `k + 1 = (n+1) + 1`, which Lean represents as `n + 1 + 1`.
  have hPn2' : ∀ a b : G, (a * b) ^ (n + 1 + 1) = a ^ (n + 1 + 1) * b ^ (n + 1 + 1) := by
    have : n + 1 + 1 = n + 2 := by ring
    simp only [this]; exact hPn2
  have commPowN1 : ∀ a b : G, Commute a (b ^ (n + 1)) := aux hPn1 hPn2'
  -- Step 6: Instantiate the commutation facts at our fixed elements `a` and `b`.
  have h_comm_n : Commute a (b ^ n) := commPowN a b
  have h_comm_n1 : Commute a (b ^ (n + 1)) := commPowN1 a b
  -- Step 6.1: Derive that `a` commutes with the inverse `(b^n)⁻¹` (from Commute.inv_right).
  have h_comm_inv : Commute a ((b ^ n)⁻¹) := h_comm_n.inv_right
  -- Step 6.2: Combine: `a` commutes with `(b^n)⁻¹ * b^(n+1)` (product of two commuting elements).
  have h_comm_prod : Commute a ((b ^ n)⁻¹ * b ^ (n + 1)) := h_comm_inv.mul_right h_comm_n1
  -- Step 6.3: Show that `(b^n)⁻¹ * b^(n+1) = b` using zpow_add_one and inv_mul_cancel_left.
  have hb_rep : (b ^ n)⁻¹ * b ^ (n + 1) = b := by
    -- Step 6.3.1: Expand `b^(n+1)` as `b^n * b` via zpow_add_one.
    calc
      (b ^ n)⁻¹ * b ^ (n + 1)
          = (b ^ n)⁻¹ * (b ^ n * b) := by
            simp [zpow_add_one]
    -- Step 6.3.2: Re-associate to `((b^n)⁻¹ * b^n) * b`.
      _ = ((b ^ n)⁻¹ * b ^ n) * b :=
            (mul_assoc (b ^ n)⁻¹ (b ^ n) b).symm
    -- Step 6.3.3: Simplify `(b^n)⁻¹ * b^n = 1` and `1 * b = b`.
      _ = b := by
            simp
  -- Step 6.4: Rewrite the commutation using `(b^n)⁻¹ * b^(n+1) = b` to get `Commute a b`.
  have h_comm_b : Commute a b := by
    simpa [hb_rep] using h_comm_prod
  -- Step 7: Unfold `Commute a b` to the desired equality `a * b = b * a`.
  simpa [Commute] using h_comm_b
