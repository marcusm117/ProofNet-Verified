import Mathlib


open Fintype Set Real Ideal Polynomial
open scoped BigOperators
noncomputable section

/-Informal Statement

If $p$ is a prime, show that $q(x) = 1 + x + x^2 + \cdots x^{p - 1}$ is irreducible in $Q[x]$.
-/

/-Informal Proof

Lemma: Let $F$ be a field and $f(x) \in F[x]$. If $c \in F$ and $f(x+c)$ is irreducible in $F[x]$, then $f(x)$ is irreducible in $F[x]$.
Proof of the Lemma: Suppose that $f(x)$ is reducible, i.e., there exist non-constant $g(x), h(x) \in F[x]$ so that
$$
f(x)=g(x) h(x) .
$$
In particular, then we have
$$
f(x+c)=g(x+c) h(x+c) .
$$
Note that $g(x+c)$ and $h(x+c)$ have the same degree at $g(x)$ and $h(x)$ respectively; in particular, they are non-constant polynomials. So our assumption is wrong.
Hence, $f(x)$ is irreducible in $F[x]$. This proves our Lemma.

Now recall the identity
$$
\frac{x^p-1}{x-1}=x^{p-1}+x^{p-2}+\ldots \ldots+x^2+x+1 .
$$
We prove that $f(x+1)$ is $\$$ |textbffirreducible in $\mathbb{Q}[x]$ and then apply the Lemma to conclude that $f(x)$ is irreducible in $\mathbb{Q}[x] .3 \$$ Note that
$$
\begin{aligned}
& f(x+1)=\frac{(x+1)^p-1}{x} \\
& =\frac{x^p+p x^{p-1}+\ldots+p x}{x} \\
& =x^{p-1}+p x^{p-2}+\ldots .+p .
\end{aligned}
$$
Using that the binomial coefficients occurring above are all divisible by $p$, we have that $f(x+1)$ is irreducible $\mathbb{Q}[x]$ by Eisenstein's criterion applied with prime $p$. 

Then by the lemma $f(x)$ is irreducible $\mathbb{Q}[x]$. This completes the proof.
-/

theorem Herstein_exercise_4_5_25 {p : ℕ} (hp : Nat.Prime p) :
  Irreducible (∑ i : Finset.range p, X ^ p : Polynomial ℚ) := by
  sorry

/-! ## Helper lemmas for the refutation

The formalization does not express the cyclotomic polynomial.  In the term
`(∑ i : Finset.range p, X ^ p : Polynomial ℚ)` the set `Finset.range p` is coerced
to a `Sort` (its coercion to a type with `p` elements), so `i` ranges over that
`Fintype`, but the summand `X ^ p` does **not** depend on `i`.  Hence the sum is the
constant sum `p • X ^ p = C (p : ℚ) * X ^ p`, and not `1 + X + ⋯ + X ^ (p-1)`.
Such a monomial is reducible for every prime `p`, since `p ≥ 2` lets us split off a
factor of `X`. -/

/-- Step 1: identify the (misformalized) sum as the monomial `X * (C p * X ^ (p-1))`. -/
theorem herstein_4_5_25_sum_eq {p : ℕ} (hp : Nat.Prime p) :
    (∑ _i : Finset.range p, X ^ p : Polynomial ℚ)
      = X * (Polynomial.C (p : ℚ) * (X ^ (p - 1) : Polynomial ℚ)) := by
  -- Step 1.1: the summand is constant, so the sum is `card • (X ^ p)`.
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_coe, Finset.card_range,
    nsmul_eq_mul, ← Polynomial.C_eq_natCast]
  -- Step 1.2: reassociate `C p * X ^ p` as `X * (C p * X ^ (p-1))`.
  rw [mul_comm (X : Polynomial ℚ), mul_assoc, ← pow_succ]
  -- Step 1.3: `p - 1 + 1 = p` because `p` is prime, hence `p ≥ 2 > 0`.
  congr 2
  have := hp.two_le
  omega

/-- Step 2: for every prime `p` the misformalized polynomial is *not* irreducible. -/
theorem herstein_4_5_25_not_irreducible {p : ℕ} (hp : Nat.Prime p) :
    ¬ Irreducible (∑ _i : Finset.range p, X ^ p : Polynomial ℚ) := by
  rw [herstein_4_5_25_sum_eq hp]
  intro h
  -- Step 2.1: irreducibility forces one of the two displayed factors to be a unit.
  rcases h.isUnit_or_isUnit rfl with hu | hu
  · -- Step 2.2: `X` is never a unit in `ℚ[X]`.
    exact Polynomial.not_isUnit_X hu
  · -- Step 2.3: `C p * X ^ (p-1)` has degree `p - 1 ≥ 1` (as `p ≥ 2`), so it is no unit.
    rw [Polynomial.isUnit_iff_degree_eq_zero,
      Polynomial.degree_C_mul_X_pow _ (by exact_mod_cast hp.ne_zero)] at hu
    have hz : p - 1 = 0 := by exact_mod_cast hu
    have := hp.two_le
    omega

/-! ## Refutation
The original statement `Herstein_exercise_4_5_25` is false: `Herstein_exercise_4_5_25_neg` proves the negation of its elaborated type. -/
theorem Herstein_exercise_4_5_25_neg : ¬ (type_of% @Herstein_exercise_4_5_25) := by
  -- Step 3: instantiate the universally quantified claim at the concrete prime `p = 2`.
  intro h
  -- Step 3.1: `h Nat.prime_two : Irreducible (∑ _ : Finset.range 2, X ^ 2)`, i.e.
  -- `Irreducible (C 2 * X ^ 2 : ℚ[X])`, which contradicts Step 2.
  exact herstein_4_5_25_not_irreducible Nat.prime_two (h Nat.prime_two)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Set Real Ideal Polynomial
open scoped BigOperators

theorem Herstein_exercise_4_5_25_corrected {p : ℕ} (hp : Nat.Prime p) :
  Irreducible (∑ i ∈ Finset.range p, X ^ i : Polynomial ℚ) := by
  classical
  -- Step 1: Upgrade the given proof that `p` is prime to a `Fact` instance so cyclotomic lemmas pick it up.
  haveI : Fact (Nat.Prime p) := ⟨hp⟩
  -- Step 2: Identify the geometric sum with the `p`-th cyclotomic polynomial over `ℚ`.
  have hGeom :
      (∑ i ∈ Finset.range p, (X : Polynomial ℚ) ^ i) = Polynomial.cyclotomic p ℚ := by
    -- Step 2.1: Apply the closed form for cyclotomic polynomials when the index is prime.
    simpa using (Polynomial.cyclotomic_prime ℚ p).symm
  -- Step 3: Record the irreducibility of the `p`-th cyclotomic polynomial over `ℚ`.
  have hIrrCyclo : Irreducible (Polynomial.cyclotomic p ℚ) := by
    -- Step 3.1: Use the general lemma once we note that every prime number is positive.
    simpa using (Polynomial.cyclotomic.irreducible_rat (show 0 < p from hp.pos))
  -- Step 4: Transfer the irreducibility statement back to the original polynomial via the identification above.
  -- Step 4.1: Rewrite with `hGeom` so the goals match exactly and conclude.
  simpa [hGeom] using hIrrCyclo
