import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $\varphi: R \rightarrow S$ be a surjective homomorphism of rings. Prove that the image of the center of $R$ is contained in the center of $S$.
-/

/-Informal Proof

Suppose $r \in \varphi[Z(R)]$. Then $r=\varphi(z)$ for some $z \in Z(R)$. Now let $x \in S$. Since $\varphi$ is surjective, we have $x=\varphi y$ for some $y \in R$. Now
$$
x r=\varphi(y) \varphi(z)=\varphi(y z)=\varphi(z y)=\varphi(z) \varphi(y)=r x .
$$
Thus $r \in Z(S)$.
-/

theorem Dummit_Foote_exercise_7_3_16 {R S : Type*} [Ring R] [Ring S]
  {φ : R →+* S} (hf : Function.Surjective φ) :
  φ '' (center R) ⊂ center S := by
  sorry

/-! ## Refutation
The original statement `Dummit_Foote_exercise_7_3_16` is false: `Dummit_Foote_exercise_7_3_16_neg` proves the negation of its elaborated type. -/
/-- Step 0 (helper): the identity ring homomorphism on `ℤ` is surjective.
Every `x : ℤ` is hit by itself, since `(RingHom.id ℤ) x` is definitionally `x`. -/
theorem Dummit_Foote_exercise_7_3_16_id_surj :
    Function.Surjective (RingHom.id ℤ) := fun x => ⟨x, rfl⟩

/-- Step 0' (helper): the image of `Set.center ℤ` under the identity ring hom is
`Set.center ℤ` itself.  The coercion of `RingHom.id ℤ` to a function is `id`,
and `id '' s = s`. -/
theorem Dummit_Foote_exercise_7_3_16_image_center :
    (RingHom.id ℤ) '' (Set.center ℤ) = Set.center ℤ := by
  simp

/-!
### Why the statement is false

The formalization writes strict inclusion `⊂` (`Set.SSubset`) where the informal
exercise only claims containment `⊆`.  Strictness fails as soon as `φ` is onto and
`center S` is entirely hit, e.g. for any isomorphism.  The elaborated statement puts
`R : Type u_1` and `S : Type u_2` in two *different* fixed universes, so the
counterexample has to be universe-polymorphic; the one-element ring `PUnit` exists in
every universe, so we take

  `R = PUnit.{u_1+1}`,  `S = PUnit.{u_2+1}`,  `φ = the (unique) zero ring hom`.

`φ` is surjective because `S` is a subsingleton, and `φ '' center R = center S`
(both are all of `PUnit`), so the strict inclusion cannot hold.
-/

/-- Step 1: the zero map into a subsingleton ring is a ring homomorphism.
All the homomorphism axioms are instances of `Subsingleton.elim`, since the target
has exactly one element. -/
def Dummit_Foote_exercise_7_3_16_zeroHom (α : Type*) (β : Type*) [Ring α] [Ring β]
    [Subsingleton β] : α →+* β where
  toFun _ := 0
  map_one' := Subsingleton.elim _ _
  map_mul' _ _ := Subsingleton.elim _ _
  map_zero' := rfl
  map_add' _ _ := Subsingleton.elim _ _

/-- Step 2: that homomorphism is surjective: any `y : β` equals `0 = φ 0`
because `β` is a subsingleton. -/
theorem Dummit_Foote_exercise_7_3_16_zeroHom_surj (α : Type*) (β : Type*) [Ring α] [Ring β]
    [Subsingleton β] :
    Function.Surjective (Dummit_Foote_exercise_7_3_16_zeroHom α β) :=
  fun _ => ⟨0, Subsingleton.elim _ _⟩

/-- Step 3: for that homomorphism the strict inclusion of the conclusion fails.

Indeed, `Set.exists_of_ssubset` would produce some `x ∈ center β` that is *not* in the
image `φ '' center α`.  But `0 ∈ center α` (`Set.zero_mem_center`) and `φ 0 = 0 = x`
(again `Subsingleton.elim`), so every `x` *is* in the image — contradiction. -/
theorem Dummit_Foote_exercise_7_3_16_not_ssubset (α : Type*) (β : Type*) [Ring α] [Ring β]
    [Subsingleton β] :
    ¬ ((Dummit_Foote_exercise_7_3_16_zeroHom α β) '' (Set.center α) ⊂ Set.center β) := by
  -- Step 3.1: assume the strict inclusion holds.
  intro hlt
  -- Step 3.2: strictness gives a witness `x` in `center β` outside the image.
  obtain ⟨x, -, hx⟩ := Set.exists_of_ssubset hlt
  -- Step 3.3: but `x` is in the image, witnessed by `0 ∈ center α`.
  exact hx ⟨0, Set.zero_mem_center, Subsingleton.elim _ _⟩

theorem Dummit_Foote_exercise_7_3_16_neg : ¬ (type_of% @Dummit_Foote_exercise_7_3_16) := by
  -- Step 4: assume the (universally quantified) statement.
  intro h
  -- Step 5: instantiate it at `R = S = PUnit` (in the respective fixed universes) and
  -- `φ = the zero ring hom`, whose surjectivity is Step 2.  This yields exactly the
  -- strict inclusion refuted in Step 3.
  exact Dummit_Foote_exercise_7_3_16_not_ssubset PUnit PUnit
    (h (Dummit_Foote_exercise_7_3_16_zeroHom_surj PUnit PUnit))

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_7_3_16_corrected {R S : Type*} [Ring R] [Ring S]
   {φ : R →+* S} (hf : Function.Surjective φ) :
   φ '' (center R) ⊆ center S := by
  -- Step 1: Fix an arbitrary element of the image; unpack it as φ z with z central in R.
  intro s hs
  rcases hs with ⟨z, hz, rfl⟩
  -- Step 2: Translate the statement "φ z is central in S" into pairwise commutation statements.
  apply (Semigroup.mem_center_iff).2
  -- Step 3: Choose an arbitrary element t of S and pull it back to R using surjectivity of φ.
  intro t
  obtain ⟨r, rfl⟩ := hf t
  -- Step 4: Extract the commutation relation inside R guaranteed by centrality of z.
  have hz_comm := (Semigroup.mem_center_iff.mp hz) r
  -- Step 5: Apply φ to that commutation relation and use the homomorphism property to translate it to S.
  have := congrArg φ hz_comm
  -- Step 6: Use the homomorphism property to convert the mapped equality into the desired commutation in S.
  simpa [map_mul] using this
