import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that the intersection of an arbitrary nonempty collection of normal subgroups of a group is a normal subgroup (do not assume the collection is countable).
-/

/-Informal Proof

Let $\left\{H_i \mid i \in I\right\}$ be an arbitrary collection of normal subgroups of $G$ and consider the intersection
$$
\bigcap_{i \in I} H_i
$$
Take an element $a$ in the intersection and an arbitrary element $g \in G$. Then $g a g^{-1} \in H_i$ because $H_i$ is normal for any $i \in H$
By the definition of the intersection, this shows that $g a g^{-1} \in \bigcap_{i \in I} H_i$ and therefore it is a normal subgroup.
-/

theorem Dummit_Foote_exercise_3_1_22b {G : Type*} [Group G] (I : Type*)
  (H : I → Subgroup G) (hH : ∀ i : I, Normal (H i)) :
  Normal (⨅ (i : I), H i) := by
  -- Step 1: To show a subgroup is normal it suffices to provide the `conj_mem`
  -- field: for every `a` in the subgroup and every `g : G`, `g * a * g⁻¹` is
  -- again in the subgroup.  (`Subgroup.Normal` is a one-field structure.)
  constructor
  -- Step 2: Fix `a` in the intersection, a proof `ha` of that membership,
  -- and an arbitrary conjugating element `g : G`.
  intro a ha g
  -- Step 3: Unfold membership in an indexed infimum of subgroups on both sides.
  -- `Subgroup.mem_iInf` says `x ∈ ⨅ i, S i ↔ ∀ i, x ∈ S i`, so `ha` becomes the
  -- family of facts `a ∈ H i`, and the goal becomes `∀ i, g * a * g⁻¹ ∈ H i`.
  rw [Subgroup.mem_iInf] at ha ⊢
  -- Step 4: Fix an index `i`.
  intro i
  -- Step 5: `H i` is normal by hypothesis `hH i`, and `a ∈ H i` by `ha i`,
  -- hence `g * a * g⁻¹ ∈ H i`.  Since `i` was arbitrary, the conjugate lies in
  -- every `H i`, i.e. in the intersection.  Note that no nonemptiness of `I` is
  -- needed: for empty `I` the infimum is `⊤`, which is trivially normal.
  exact (hH i).conj_mem a (ha i) g

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_3_1_22b_corrected {G : Type*} [Group G] (I : Type*) [Nonempty I]
  (H : I → Subgroup G) (hH : ∀ i : I, Normal (H i)) :
  Normal (⨅ (i : I), H i):= by
  -- Step 1: Recognize that the infimum `⨅ (i : I), H i` is definitionally the `iInf` of the family `H`.
  -- Step 2: Aim to invoke `Subgroup.normal_iInf_normal`, which states that the infimum of normal subgroups is normal.
  -- Step 2.1: Supply the lemma with the hypothesis `hH`, witnessing that each `H i` is normal.
  exact Subgroup.normal_iInf_normal (fun i => hH i)
