import Mathlib


open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators InnerProductSpace

/-Informal Statement

Suppose $T \in \mathcal{L}(V)$ is self-adjoint, $\lambda \in \mathbf{F}$, and $\epsilon>0$. Prove that if there exists $v \in V$ such that $\|v\|=1$ and $\|T v-\lambda v\|<\epsilon,$ then $T$ has an eigenvalue $\lambda^{\prime}$ such that $\left|\lambda-\lambda^{\prime}\right|<\epsilon$.
-/

/-Informal Proof

Let $T \in \mathcal{L}(V)$ be a self-adjoint, and let $\lambda \in \mathbf{F}$ and $\epsilon>0$.
By the Spectral Theorem, there is $e_1, \ldots, e_n$ an orthonormal basis of $V$ consisting of eigenvectors of $T$ and let $\lambda_1, \ldots, \lambda_n$ denote their corresponding eigenvalues.
Choose an eigenvalue $\lambda^{\prime}$ of $T$ such that $\left|\lambda^{\prime}-\lambda\right|^2$ is minimized.
There are $a_1, \ldots, a_n \in \mathbb{F}$ such that
$$
v=a_1 e_1+\cdots+a_n e_n .
$$
Thus, we have
$$
\begin{aligned}
\epsilon^2 & >|| T v-\left.\lambda v\right|^2 \\
& =\left|\left\langle T v-\lambda v, e_1\right\rangle\right|^2+\cdots+\left|\left\langle T v-\lambda v, e_n\right\rangle\right|^2 \\
& =\left|\lambda_1 a_1-\lambda a_1\right|^2+\cdots+\left|\lambda_n a_n-\lambda a_n\right|^2 \\
& =\left|a_1\right|^2\left|\lambda_1-\lambda\right|^2+\cdots+\left|a_n\right|^2\left|\lambda_n-\lambda\right|^2 \\
& \geq\left|a_1\right|^2\left|\lambda^{\prime}-\lambda\right|^2+\cdots+\left|a_n\right|^2\left|\lambda^{\prime}-\lambda\right|^2 \\
& =\left|\lambda^{\prime}-\lambda\right|^2
\end{aligned}
$$
where the second and fifth lines follow from $6.30$ (the fifth because $\|v\|=1$ ). Now, we taking the square root.
Hence, $T$ has an eigenvalue $\lambda^{\prime}$ such that $\left|\lambda^{\prime}-\lambda\right|<\epsilon$
-/

theorem Axler_exercise_7_14 {𝕜 V : Type*} [RCLike 𝕜] [NormedAddCommGroup V]
  [InnerProductSpace 𝕜 V] [FiniteDimensional 𝕜 V]
  {T : End 𝕜 V} (hT : IsSelfAdjoint T)
  {l : 𝕜} {ε : ℝ} (he : ε > 0) : ∃ v : V, ‖v‖= 1 ∧ (‖T v - l • v‖ < ε →
  (∃ l' : T.Eigenvalues, ‖l - l'‖ < ε)) := by
  sorry

/-!
### Why the formalization is false

The informal exercise *hypothesizes* the existence of a unit vector `v` with
`‖T v - λ v‖ < ε` and concludes that `T` has an eigenvalue near `λ`.  The formalization
misplaces the existential quantifier: it asserts

  `∃ v : V, ‖v‖ = 1 ∧ (‖T v - l • v‖ < ε → ∃ l', ‖l - l'‖ < ε)`,

which *unconditionally* demands the existence of a vector of norm `1` in `V`.  Nothing in
the hypotheses makes `V` nontrivial, so the statement already fails on the zero-dimensional
inner product space, where the only vector is `0` and hence no vector has norm `1`.
(The implication inside the conjunction is irrelevant: the counterexample kills the
`‖v‖ = 1` conjunct.  Triviality is the only obstruction — adding `[Nontrivial V]` makes
the statement provable, by taking `v` to be a unit eigenvector supplied by the spectral
theorem.)

**Counterexample.** `𝕜 = ℝ`, `V = 0` (the trivial inner product space), `T = 0`
(self-adjoint), `l = 0`, `ε = 1`.  Then `ε > 0` and `T` is self-adjoint, but every
`v : V` satisfies `v = 0`, so `‖v‖ = 0 ≠ 1`.

Since the negated statement is universe polymorphic (`𝕜 : Type u_1`, `V : Type u_2`) while
the only `RCLike` fields in Mathlib (`ℝ`, `ℂ`) live in `Type 0`, the counterexample has to
be transported into arbitrary universes with `ULift`.  Mathlib has no `RCLike (ULift ℝ)`
instance and no `InnerProductSpace` instance on a `ULift`, so both are built below (as
plain `def`s, so that no ambient instance is added to the file).
-/

/-- Step A: the (trivial) star structure on `ULift ℝ`, needed as a parent of `RCLike`. -/
def pn27Star.{u} : StarRing (ULift.{u} ℝ) where
  star x := x
  star_involutive := fun _ => rfl
  star_mul := fun a b => mul_comm a b
  star_add := fun _ _ => rfl

/-- Step B: `ULift ℝ` is a normed field.  Everything is inherited from the existing `Field`
and `NormedRing` instances on `ULift ℝ`; only multiplicativity of the norm has to be
supplied, and `‖x‖ = |x.down|` holds by definition. -/
noncomputable def pn27NF.{u} : NormedField (ULift.{u} ℝ) :=
  { (inferInstance : Field (ULift.{u} ℝ)), (inferInstance : NormedRing (ULift.{u} ℝ)) with
    norm_mul := fun a b => abs_mul a.down b.down }

/-- Step C: the norm on `ULift ℝ` has dense range, since the norm on `ℝ` does. -/
noncomputable def pn27DNF.{u} : DenselyNormedField (ULift.{u} ℝ) :=
  { pn27NF.{u} with
    lt_norm_lt := fun x y h0 hxy => by
      obtain ⟨a, ha1, ha2⟩ := DenselyNormedField.lt_norm_lt (α := ℝ) x y h0 hxy
      exact ⟨ULift.up a, ha1, ha2⟩ }

/-- Step D: `ULift ℝ` is an `RCLike` field, with `re = ULift.down`, `im = 0` and `I = 0`
(the "real" shape of `RCLike`).  The `NormedAlgebra ℝ`, `CompleteSpace` and `PartialOrder`
parents already exist in Mathlib for `ULift`. -/
noncomputable def pn27RCLike.{u} : RCLike (ULift.{u} ℝ) :=
  { pn27DNF.{u}, pn27Star.{u}, (inferInstance : NormedAlgebra ℝ (ULift.{u} ℝ)),
    (inferInstance : CompleteSpace (ULift.{u} ℝ)),
    (inferInstance : PartialOrder (ULift.{u} ℝ)) with
    re := { toFun := ULift.down, map_zero' := rfl, map_add' := fun _ _ => rfl }
    im := 0
    I := 0
    I_re_ax := rfl
    I_mul_I_ax := Or.inl rfl
    re_add_im_ax := fun z => by ext; simp
    ofReal_re_ax := fun r => rfl
    ofReal_im_ax := fun r => rfl
    mul_re_ax := fun z w => by simp
    mul_im_ax := fun z w => by simp
    conj_re_ax := fun z => rfl
    conj_im_ax := fun z => by simp
    conj_I_ax := by simp
    norm_sq_eq_def_ax := fun z => by
      -- `‖z‖ = |z.down|`, so this is `|r| * |r| = r * r`.
      have hz : ‖z‖ * ‖z‖ = z.down * z.down := abs_mul_abs_self z.down
      simpa [sq] using hz
    mul_im_I_ax := fun z => by simp
    le_iff_re_im := by
      -- the order on `ULift ℝ` is the order on `ℝ`, and the imaginary parts are both `0`
      intro z w
      exact ⟨fun h => ⟨h, rfl⟩, fun h => h.1⟩
    toDecidableEq := Classical.decEq _ }

/-- Step E: the zero-dimensional inner product space, in an arbitrary universe:
`ULift PUnit` over `ULift ℝ`, with the identically-zero inner product.  Its norm is
identically `0` (that is `PUnit.normedAddCommGroup`, lifted), so every axiom is trivial. -/
noncomputable def pn27IPS.{u, v} :
    @InnerProductSpace (ULift.{u} ℝ) (ULift.{v} PUnit.{1}) pn27RCLike.{u} inferInstance :=
  letI := pn27RCLike.{u}
  { toNormedSpace :=
      -- Step E.1: the module structure is Mathlib's `ULift` one; `‖a • b‖ = 0 = ‖a‖ * 0`.
      { __ := (inferInstance : Module (ULift.{u} ℝ) (ULift.{v} PUnit.{1}))
        norm_smul_le := fun a b => by
          show ‖a • b‖ ≤ ‖a‖ * ‖b‖
          have h1 : ‖a • b‖ = 0 := rfl
          have h2 : ‖b‖ = (0:ℝ) := rfl
          rw [h1, h2, mul_zero] }
    -- Step E.2: the inner product of the trivial space is `0`.
    inner := fun _ _ => 0
    -- Step E.3: `‖x‖ ^ 2 = 0 = re 0`.
    norm_sq_eq_re_inner := fun x => by
      show ‖x‖ ^ 2 = RCLike.re (0 : ULift.{u} ℝ)
      have h2 : ‖x‖ = (0:ℝ) := rfl
      rw [h2]
      simp
    -- Step E.4: hermitian symmetry, additivity and conjugate-homogeneity all read `0 = 0`.
    conj_inner_symm := fun x y => by
      show (starRingEnd (ULift.{u} ℝ)) 0 = 0
      simp
    add_left := fun x y z => by
      show (0 : ULift.{u} ℝ) = 0 + 0
      simp
    smul_left := fun x y r => by
      show (0 : ULift.{u} ℝ) = (starRingEnd (ULift.{u} ℝ)) r * 0
      simp }

/-! ## Refutation
The original statement `Axler_exercise_7_14` is false: `Axler_exercise_7_14_neg` proves the negation of its elaborated type. -/
theorem Axler_exercise_7_14_neg : ¬ (type_of% @Axler_exercise_7_14) := by
  -- Step 1: assume the statement holds for every self-adjoint operator on every
  -- finite-dimensional inner product space.
  intro h
  -- Step 2: install the counterexample structures of Steps D and E as local instances:
  -- `𝕜 = ULift ℝ` and `V = ULift PUnit`, in the universes the statement quantifies over.
  letI instK := pn27RCLike.{u_1}
  letI instI := pn27IPS.{u_1, u_2}
  -- Step 3: `V` is finite (it is a subsingleton), hence a finite-dimensional `ULift ℝ`-module.
  haveI : FiniteDimensional (ULift.{u_1} ℝ) (ULift.{u_2} PUnit.{1}) := inferInstance
  -- Step 4: specialise the assumption to `T = 0` (self-adjoint by `IsSelfAdjoint.zero`),
  -- `l = 0` and `ε = 1 > 0`.  It hands us a vector `v : V` of norm `1`.
  obtain ⟨v, hv, -⟩ := @h (ULift.{u_1} ℝ) (ULift.{u_2} PUnit.{1}) instK inferInstance instI
    inferInstance 0 (IsSelfAdjoint.zero _) 0 1 one_pos
  -- Step 5: but the norm on the trivial space is identically `0`, so `hv` says `0 = 1`.
  have h0 : ‖v‖ = (0:ℝ) := rfl
  rw [h0] at hv
  -- Step 6: contradiction.
  exact zero_ne_one hv


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators

theorem Axler_exercise_7_14_corrected {𝕜 V : Type*} [RCLike 𝕜] [NormedAddCommGroup V]
  [InnerProductSpace 𝕜 V] [FiniteDimensional 𝕜 V]
  {T : Module.End 𝕜 V} (hT : IsSelfAdjoint T)
  {l : 𝕜} {ε : ℝ} (he : ε > 0) : (∃ v : V, ‖v‖= 1 ∧ ‖T v - l • v‖ < ε) →
  (∃ l' : T.Eigenvalues, ‖l - l'‖ < ε) := by
  -- Step 1: introduce classical logic and destruct the approximate eigenvector data.
  classical
  intro hApprox
  -- Step 1.1: pick a unit vector `v` with the stated approximation property.
  rcases hApprox with ⟨v, hvnorm, hvapprox⟩
  -- Step 2: upgrade the self-adjoint assumption to the symmetric form given by the spectral theorem.
  have hSym : LinearMap.IsSymmetric T :=
    (LinearMap.isSymmetric_iff_isSelfAdjoint T).mpr hT
  -- Step 2.1: choose the orthonormal eigenbasis and the corresponding eigenvalues.
  let n := Module.finrank 𝕜 V
  have hn : Module.finrank 𝕜 V = n := rfl
  let b := hSym.eigenvectorBasis hn
  let coords : Fin n → 𝕜 := b.repr v
  let lam : Fin n → 𝕜 := fun i => ((hSym.eigenvalues hn i : ℝ) : 𝕜)
  -- Step 3: record the coordinate formula for `T v` in the eigenbasis.
  have h_repr_mul :
      ∀ i : Fin n, (b.repr (T v)) i = lam i * coords i := by
    intro i
    -- Step 3.1: apply the diagonalization lemma and rewrite using current notation.
    simpa [b, coords, lam] using hSym.eigenvectorBasis_apply_self_apply hn v i
  -- Step 4: express the coordinates of the residual vector `T v - l • v`.
  have h_repr_res :
      ∀ i : Fin n, (b.repr (T v - l • v)) i = (lam i - l) * coords i := by
    intro i
    -- Step 4.1: expand linearity and collapse with Step 3.
    have hSub :
        (b.repr (T v - l • v)) i =
          (b.repr (T v)) i - (b.repr (l • v)) i := by
      simp [map_sub]
    have hS := h_repr_mul i
    have hSmul : (b.repr (l • v)) i = l * coords i := by
      simp [coords]
    -- Step 4.2: combine the two identities and factor common terms.
    rw [hSub, hS, hSmul]
    ring
  -- Step 5: turn the coordinate formula into an equality of squared norms.
  have h_coord_sq :
      ∀ i : Fin n, ‖(b.repr (T v - l • v)) i‖ ^ 2 =
        ‖lam i - l‖ ^ 2 * ‖coords i‖ ^ 2 := by
    intro i
    -- Step 5.1: compute the norm of the scalar product in the base field.
    rw [h_repr_res i, norm_mul, mul_pow]
  -- Step 6: identify the weighted sum of squares with `‖T v - l • v‖^2`.
  have h_sum_eq :
      ∑ i : Fin n, ‖lam i - l‖ ^ 2 * ‖coords i‖ ^ 2 = ‖T v - l • v‖ ^ 2 := by
    -- Step 6.1: rewrite each summand as the square of a scalar multiple.
    have h₁ :
        ∑ i : Fin n, ‖lam i - l‖ ^ 2 * ‖coords i‖ ^ 2 =
          ∑ i : Fin n, ‖(lam i - l) * coords i‖ ^ 2 := by
      refine Finset.sum_congr rfl ?_
      intro i _
      simp [pow_two, norm_mul, mul_comm, mul_left_comm, mul_assoc]
    -- Step 6.2: replace each scalar multiple by the corresponding coordinate.
    have h₂ :
        ∑ i : Fin n, ‖(lam i - l) * coords i‖ ^ 2 =
          ∑ i : Fin n, ‖(b.repr (T v - l • v)) i‖ ^ 2 := by
      refine Finset.sum_congr rfl ?_
      intro i _
      rw [h_repr_res i]
    -- Step 6.3: express the remaining sum via the Euclidean norm.
    have h₃ :
        ∑ i : Fin n, ‖(b.repr (T v - l • v)) i‖ ^ 2 =
          ‖b.repr (T v - l • v)‖ ^ 2 := by
      simpa using (EuclideanSpace.norm_sq_eq (b.repr (T v - l • v))).symm
    -- Step 6.4: transfer the norm back to `V`.
    have h_isometry :=
      LinearIsometryEquiv.norm_map (b.repr) (T v - l • v)
    have h₄_norm : ‖b.repr (T v) - l • b.repr v‖ = ‖T v - l • v‖ := by
      simpa [map_sub] using h_isometry
    have h₄ :
        ‖b.repr (T v - l • v)‖ ^ 2 = ‖T v - l • v‖ ^ 2 := by
      simpa [h_isometry]
    -- Step 6.5: assemble the equalities.
    calc
      ∑ i : Fin n, ‖lam i - l‖ ^ 2 * ‖coords i‖ ^ 2
          = ∑ i, ‖(lam i - l) * coords i‖ ^ 2 := h₁
      _ = ∑ i, ‖(b.repr (T v - l • v)) i‖ ^ 2 := h₂
      _ = ‖b.repr (T v - l • v)‖ ^ 2 := h₃
      _ = ‖b.repr (T v) - l • b.repr v‖ ^ 2 := by
        simp [map_sub]
      _ = ‖T v - l • v‖ ^ 2 := by
        simp [h₄_norm]
  -- Step 7: note that the squared coordinates of `v` add up to `1`.
  have h_weight_sum : ∑ i : Fin n, ‖coords i‖ ^ 2 = 1 := by
    -- Step 7.1: rewrite the sum as the squared norm in the eigenbasis.
    have h_coords_sq :
        ∑ i : Fin n, ‖coords i‖ ^ 2 = ‖b.repr v‖ ^ 2 := by
      simpa [coords] using (EuclideanSpace.norm_sq_eq (b.repr v)).symm
    -- Step 7.2: translate the squared norm back to `V`.
    have h_isometry :=
      LinearIsometryEquiv.norm_map (b.repr) v
    have h_norm_sq : ‖b.repr v‖ ^ 2 = ‖v‖ ^ 2 := by
      simp [h_isometry]
    -- Step 7.3: use the unit-length condition on `v`.
    have h_unit : ‖v‖ ^ 2 = 1 := by simp [hvnorm]
    simp [h_coords_sq, h_unit]
  -- Step 8: deduce a strict upper bound on the weighted sum.
  have h_sum_lt : ∑ i : Fin n, ‖lam i - l‖ ^ 2 * ‖coords i‖ ^ 2 < ε ^ 2 := by
    -- Step 8.1: square the approximation inequality.
    have h_sq_lt : ‖T v - l • v‖ ^ 2 < ε ^ 2 :=
      (sq_lt_sq₀ (norm_nonneg _) (le_of_lt he)).mpr hvapprox
    -- Step 8.2: translate via the identity from Step 6.
    simpa [h_sum_eq]
  -- Step 9: prove that some index realises a strict quadratic bound.
  have h_exists_sq :
      ∃ i : Fin n, ‖lam i - l‖ ^ 2 < ε ^ 2 := by
    classical
    -- Step 9.1: argue by contradiction using the non-negativity of the weights.
    by_contra hcontra
    -- Step 9.2: convert the negated existence into pointwise inequalities.
    have hforall' : ∀ i : Fin n, ε ^ 2 ≤ ‖lam i - l‖ ^ 2 := by
      intro i
      have hnot := (not_exists.mp hcontra) i
      exact not_lt.mp hnot
    -- Step 9.3: bound the weighted sum from below by `ε^2`.
    have h_sum_ge :
        ∑ i : Fin n, ε ^ 2 * ‖coords i‖ ^ 2 ≤
          ∑ i : Fin n, ‖lam i - l‖ ^ 2 * ‖coords i‖ ^ 2 := by
      refine Finset.sum_le_sum ?_
      intro i _
      have h_nonneg : 0 ≤ ‖coords i‖ ^ 2 := sq_nonneg _
      have h_mul :=
        mul_le_mul_of_nonneg_right (hforall' i) h_nonneg
      simpa [pow_two, mul_comm, mul_left_comm, mul_assoc] using h_mul
    -- Step 9.4: evaluate the left-hand sum using Step 7.
    have h_left_sum :
        ∑ i : Fin n, ε ^ 2 * ‖coords i‖ ^ 2 = ε ^ 2 := by
      classical
      calc
        ∑ i : Fin n, ε ^ 2 * ‖coords i‖ ^ 2
            = ε ^ 2 * ∑ i, ‖coords i‖ ^ 2 := by
              simp [Finset.mul_sum]
        _ = ε ^ 2 * 1 := by simp [h_weight_sum]
        _ = ε ^ 2 := mul_one _
    -- Step 9.5: combine the bounds to contradict Step 8.
    have h_ge : ε ^ 2 ≤ ∑ i : Fin n, ‖lam i - l‖ ^ 2 * ‖coords i‖ ^ 2 := by
      simpa [h_left_sum] using h_sum_ge
    exact (not_le_of_gt h_sum_lt) h_ge
  -- Step 10: choose the index and drop the square to obtain the desired inequality.
  obtain ⟨i₀, hi₀⟩ := h_exists_sq
  have hi₀_linear :
      ‖lam i₀ - l‖ < ε :=
    (sq_lt_sq₀ (norm_nonneg _) (le_of_lt he)).1 hi₀
  -- Step 11: package the eigenvalue and conclude.
  have h_eig : HasEigenvalue T (lam i₀) := by
    simpa [lam] using hSym.hasEigenvalue_eigenvalues hn i₀
  refine ⟨⟨lam i₀, h_eig⟩, ?_⟩
  -- Step 11.1: rewrite the norm in the requested order.
  simpa [lam, norm_sub_rev] using hi₀_linear
