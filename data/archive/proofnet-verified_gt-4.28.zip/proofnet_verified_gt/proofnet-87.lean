import Mathlib


open Fintype Set Real Ideal Polynomial
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $R$ be the ring of $2 \times 2$ matrices over the real numbers; suppose that $I$ is an ideal of $R$. Show that $I = (0)$ or $I = R$.
-/

/-Informal Proof

Suppose that $I$ is a nontrivial ideal of $R$, and let
$$
A=\left(\begin{array}{ll}
a & b \\
c & d
\end{array}\right)
$$
where not all of $a, b, c d$ are zero. Suppose, without loss of generality -- our steps would be completely analogous, modulo some different placement of 1 s in our matrices, if we assumed some other element to be nonzero -- that $a \neq 0$. Then we have that
$$
\left(\begin{array}{ll}
1 & 0 \\
0 & 0
\end{array}\right)\left(\begin{array}{ll}
a & b \\
c & d
\end{array}\right)=\left(\begin{array}{ll}
a & b \\
0 & 0
\end{array}\right) \in I
$$
and so
$$
\left(\begin{array}{ll}
a & b \\
0 & 0
\end{array}\right)\left(\begin{array}{ll}
1 & 0 \\
0 & 0
\end{array}\right)=\left(\begin{array}{ll}
a & 0 \\
0 & 0
\end{array}\right) \in I
$$
so that
$$
\left(\begin{array}{ll}
x & 0 \\
0 & 0
\end{array}\right) \in I
$$
for any real $x$. Now, also for any real $x$,
$$
\left(\begin{array}{ll}
x & 0 \\
0 & 0
\end{array}\right)\left(\begin{array}{ll}
0 & 1 \\
0 & 0
\end{array}\right)=\left(\begin{array}{ll}
0 & x \\
0 & 0
\end{array}\right) \in I .
$$
Likewise
$$
\left(\begin{array}{ll}
0 & 0 \\
1 & 0
\end{array}\right)\left(\begin{array}{ll}
0 & x \\
0 & 0
\end{array}\right)=\left(\begin{array}{ll}
0 & 0 \\
0 & x
\end{array}\right) \in I
$$
and
$$
\left(\begin{array}{ll}
0 & 0 \\
0 & x
\end{array}\right)\left(\begin{array}{ll}
0 & 0 \\
1 & 0
\end{array}\right)=\left(\begin{array}{ll}
0 & 0 \\
x & 0
\end{array}\right)
$$
Thus, as
$$
\left(\begin{array}{ll}
a & b \\
c & d
\end{array}\right)=\left(\begin{array}{ll}
a & 0 \\
0 & 0
\end{array}\right)+\left(\begin{array}{ll}
0 & b \\
0 & 0
\end{array}\right)+\left(\begin{array}{ll}
0 & 0 \\
c & 0
\end{array}\right)+\left(\begin{array}{ll}
0 & 0 \\
0 & d
\end{array}\right)
$$
and since all the terms on the right side are in $I$ and $I$ is an additive group, it follows that
$$
\left(\begin{array}{ll}
a & b \\
c & d
\end{array}\right)
$$
for arbitrary $a, b, c, d$ is in $I$, i.e. $I=R$
Note that the intuition for picking these matrices is that, if we denote by $E_{i j}$ the matrix with 1 at position $(i, j)$ and 0 elsewhere, then
$$
E_{i j}\left(\begin{array}{ll}
a_{1,1} & a_{1,2} \\
a_{2,1} & a_{2,2}
\end{array}\right) E_{n m}=a_{j, n} E_{i m}
$$
-/

theorem Herstein_exercise_4_3_25 (I : Ideal (Matrix (Fin 2) (Fin 2) ℝ)) :
  I = ⊥ ∨ I = ⊤ := by
  sorry

/-! ## Counterexample

Mathlib's `Ideal R` is by definition `Submodule R R`, i.e. the type of **left** ideals
(see `Mathlib/RingTheory/Ideal/Defs.lean`: "the type of (left) ideals over a ring `R`");
two-sided ideals are `TwoSidedIdeal`.  Herstein 4.3.25 is a statement about *two-sided*
ideals: the matrix ring `M₂(ℝ)` is simple only in that sense.  As a left module over
itself it is *not* simple — the set of matrices whose second column vanishes is a left
ideal which is neither `⊥` nor `⊤`.  That is the counterexample below. -/

/-- The left ideal of `2 × 2` real matrices whose **second column** is zero.
It is closed under left multiplication because the second column of `B * A` is `B`
applied to the second column of `A`. -/
def secondColZero : Ideal (Matrix (Fin 2) (Fin 2) ℝ) where
  carrier := {A | A 0 1 = 0 ∧ A 1 1 = 0}
  -- Step 1: closed under addition — entrywise, `0 + 0 = 0`.
  add_mem' := by
    intro a b ha hb
    exact ⟨by simp [Matrix.add_apply, ha.1, hb.1], by simp [Matrix.add_apply, ha.2, hb.2]⟩
  -- Step 2: contains `0`, whose entries are all `0`.
  zero_mem' := by exact ⟨rfl, rfl⟩
  -- Step 3: closed under left multiplication by an arbitrary matrix `c`.
  -- `(c * x) i 1 = ∑ j, c i j * x j 1`, and every `x j 1` vanishes by hypothesis.
  smul_mem' := by
    intro c x hx
    have h01 : x 0 1 = 0 := hx.1
    have h11 : x 1 1 = 0 := hx.2
    refine ⟨?_, ?_⟩
    · rw [smul_eq_mul, Matrix.mul_apply, Fin.sum_univ_two, h01, h11]
      ring
    · rw [smul_eq_mul, Matrix.mul_apply, Fin.sum_univ_two, h01, h11]
      ring

/-- The matrix unit `E₀₀`, which lies in `secondColZero` but is nonzero. -/
def E00 : Matrix (Fin 2) (Fin 2) ℝ := !![1, 0; 0, 0]

/-- Step 4: `E₀₀` belongs to `secondColZero` (its second column is zero). -/
theorem E00_mem : E00 ∈ secondColZero := by
  constructor <;> simp [E00]

/-- Step 5: `E₀₀ ≠ 0`, since its `(0,0)` entry is `1`. -/
theorem E00_ne_zero : E00 ≠ 0 := by
  intro h
  have h00 : E00 0 0 = (0 : Matrix (Fin 2) (Fin 2) ℝ) 0 0 := by rw [h]
  simp [E00] at h00

/-- Step 6: `1 ∉ secondColZero`, since `(1 : Matrix _ _ ℝ) 1 1 = 1 ≠ 0`. -/
theorem one_not_mem : (1 : Matrix (Fin 2) (Fin 2) ℝ) ∉ secondColZero := by
  intro h
  have h11 : (1 : Matrix (Fin 2) (Fin 2) ℝ) 1 1 = 0 := h.2
  rw [Matrix.one_apply_eq] at h11
  exact one_ne_zero h11

/-! ## Refutation
The original statement `Herstein_exercise_4_3_25` is false: `Herstein_exercise_4_3_25_neg` proves the negation of its elaborated type. -/
theorem Herstein_exercise_4_3_25_neg : ¬ (type_of% @Herstein_exercise_4_3_25) := by
  -- Step 7: assume every left ideal of `M₂(ℝ)` is `⊥` or `⊤`, and apply it to `secondColZero`.
  intro h
  rcases h secondColZero with hbot | htop
  · -- Step 7.1: if it were `⊥`, then `E₀₀ ∈ ⊥`, forcing `E₀₀ = 0`, a contradiction.
    have : E00 ∈ (⊥ : Ideal (Matrix (Fin 2) (Fin 2) ℝ)) := hbot ▸ E00_mem
    exact E00_ne_zero (Submodule.mem_bot _ |>.mp this)
  · -- Step 7.2: if it were `⊤`, then `1` would be a member, contradicting `one_not_mem`.
    exact one_not_mem ((Ideal.eq_top_iff_one _).mp htop)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Set Real Ideal Polynomial
open scoped BigOperators

/-
Step 1: Written explanation of the failure of the original Lean statement.
-/

namespace Proofnet87

open scoped Matrix BigOperators

noncomputable section

local notation "ι₀" => (0 : Fin 2)
local notation "ι₁" => (1 : Fin 2)
local notation "E₀₀" => Matrix.single ι₀ ι₀ (1 : ℝ)
local notation "E₀₁" => Matrix.single ι₀ ι₁ (1 : ℝ)

end

end Proofnet87

/-
Step 4: State and prove the corrected version using two-sided ideals.
-/
/-
Step 4.1: Correction — when `I` ranges over `TwoSidedIdeal`, the statement becomes true.
Step 4.2: Proof outline — rely on the instance `[IsSimpleRing (Matrix (Fin 2) (Fin 2) ℝ)]`
          supplied by mathlib.
-/

/-- Step 4: Corrected version for two-sided ideals. -/
theorem Herstein_exercise_4_3_25_corrected
    (I : TwoSidedIdeal (Matrix (Fin 2) (Fin 2) ℝ)) :
    I = ⊥ ∨ I = ⊤ := by
  classical
  -- Step 4.1: Invoke the simple-ring structure of the full matrix ring.
  have hsimple :
      IsSimpleOrder (TwoSidedIdeal (Matrix (Fin 2) (Fin 2) ℝ)) :=
    IsSimpleRing.simple (R := Matrix (Fin 2) (Fin 2) ℝ)
  -- Step 4.2: Apply the `eq_bot_or_eq_top` property from the simple order.
  exact hsimple.eq_bot_or_eq_top _
