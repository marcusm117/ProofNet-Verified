import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

For any two real sequences $\left\{a_{n}\right\},\left\{b_{n}\right\}$, prove that $\limsup _{n \rightarrow \infty}\left(a_{n}+b_{n}\right) \leq \limsup _{n \rightarrow \infty} a_{n}+\limsup _{n \rightarrow \infty} b_{n},$ provided the sum on the right is not of the form $\infty-\infty$.
-/

/-Informal Proof

Since the case when $\limsup _{n \rightarrow \infty} a_n=+\infty$ and $\limsup _{n \rightarrow \infty} b_n=-\infty$ has been excluded from consideration, we note that the inequality is obvious if $\limsup _{n \rightarrow \infty} a_n=+\infty$. Hence we shall assume that $\left\{a_n\right\}$ is bounded above.

Let $\left\{n_k\right\}$ be a subsequence of the positive integers such that $\lim _{k \rightarrow \infty}\left(a_{n_k}+\right.$ $\left.b_{n_k}\right)=\limsup _{n \rightarrow \infty}\left(a_n+b_n\right)$. Then choose a subsequence of the positive integers $\left\{k_m\right\}$ such that
$$
\lim _{m \rightarrow \infty} a_{n_{k_m}}=\limsup _{k \rightarrow \infty} a_{n_k} .
$$
The subsequence $a_{n_{k_m}}+b_{n_{k_m}}$ still converges to the same limit as $a_{n_k}+b_{n_k}$, i.e., to $\limsup _{n \rightarrow \infty}\left(a_n+b_n\right)$. Hence, since $a_{n_k}$ is bounded above (so that $\limsup _{k \rightarrow \infty} a_{n_k}$ is finite), it follows that $b_{n_{k_m}}$ converges to the difference
$$
\lim _{m \rightarrow \infty} b_{n_{k_m}}=\lim _{m \rightarrow \infty}\left(a_{n_{k_m}}+b_{n_{k_m}}\right)-\lim _{m \rightarrow \infty} a_{n_{k_m}} .
$$
Thus we have proved that there exist subsequences $\left\{a_{n_{k_m}}\right\}$ and $\left\{b_{n_{k_m}}\right\}$ which converge to limits $a$ and $b$ respectively such that $a+b=\limsup _{n \rightarrow \infty}\left(a_n+b_n^*\right)$. Since $a$ is the limit of a subsequence of $\left\{a_n\right\}$ and $b$ is the limit of a subsequence of $\left\{b_n\right\}$, it follows that $a \leq \limsup _{n \rightarrow \infty} a_n$ and $b \leq \limsup _{n \rightarrow \infty} b_n$, from which the desired inequality follows.
-/

theorem Rudin_exercise_3_5
  (a b : ℕ → ℝ)
  (h : limsup a + limsup b ≠ 0) :
  limsup (λ n => a n + b n) ≤ limsup a + limsup b := by
  sorry

/-! ## Refutation
The original statement `Rudin_exercise_3_5` is false: `Rudin_exercise_3_5_neg` proves the negation of its elaborated type. -/
theorem Rudin_exercise_3_5_neg : ¬ (type_of% @Rudin_exercise_3_5) := by
  -- Step 0: `limsup a` has no filter argument, so it is the function
  -- `Filter.limsup a : Filter ℕ → ℝ`; hypothesis and conclusion are Pi-type (pointwise) statements.
  -- Counterexample: a n = n, b n = 1 - n. Evaluating the conclusion at `atTop` gives 1 ≤ 0.
  intro H
  have key := H (fun n => (n : ℝ)) (fun n => 1 - (n : ℝ)) ?_ atTop
  · -- Step 1: evaluate the three limsups along `atTop`.
    -- Step 1.1: a n + b n = 1 is constant, so its limsup is 1.
    have h1 : limsup (fun n : ℕ => (n : ℝ) + (1 - (n : ℝ))) atTop = 1 := by
      have : (fun n : ℕ => (n : ℝ) + (1 - (n : ℝ))) = fun _ => (1 : ℝ) := by
        funext n; ring
      rw [this, limsup_const]
    -- Step 1.2: `n` is unbounded above, so the set of eventual upper bounds is empty
    -- and `limsup = sInf ∅ = 0` (Real's junk value).
    have h2 : limsup (fun n : ℕ => (n : ℝ)) atTop = 0 := by
      rw [limsup_eq]
      convert Real.sInf_empty
      ext x
      simp only [Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false]
      intro hx
      obtain ⟨N, hN⟩ := eventually_atTop.1 hx
      obtain ⟨m, hm⟩ := exists_nat_gt x
      have := hN (max N m) (le_max_left _ _)
      have : (m : ℝ) ≤ (max N m : ℕ) := by exact_mod_cast le_max_right N m
      linarith
    -- Step 1.3: `1 - n → -∞`, so every real is an eventual upper bound
    -- and `limsup = sInf univ = 0`.
    have h3 : limsup (fun n : ℕ => 1 - (n : ℝ)) atTop = 0 := by
      rw [limsup_eq]
      convert Real.sInf_univ
      ext x
      simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
      obtain ⟨m, hm⟩ := exists_nat_gt (1 - x)
      refine eventually_atTop.2 ⟨m, fun n hn => ?_⟩
      have : (m : ℝ) ≤ n := by exact_mod_cast hn
      linarith
    -- Step 1.4: the conclusion at `atTop` reads 1 ≤ 0 + 0, contradiction.
    simp only [Pi.add_apply] at key
    rw [h1, h2, h3] at key
    norm_num at key
  · -- Step 2: the hypothesis `limsup a + limsup b ≠ 0` (as functions on filters).
    -- Evaluate at `pure 0`: limsup along `pure 0` is the value at 0, giving 0 + 1 = 1 ≠ 0.
    intro h0
    have := congrFun h0 (pure 0)
    simp only [Pi.add_apply, Pi.zero_apply] at this
    -- Step 2.1: unfold limsup at `pure 0` to `sInf (Ici 0)` and `sInf (Ici 1)`.
    rw [limsup_eq, limsup_eq] at this
    simp only [eventually_pure, Nat.cast_zero, sub_zero] at this
    rw [show {x : ℝ | (0:ℝ) ≤ x} = Set.Ici 0 from rfl, show {x : ℝ | (1:ℝ) ≤ x} = Set.Ici 1 from rfl,
      csInf_Ici, csInf_Ici] at this
    -- Step 2.2: 0 + 1 = 0 is false.
    norm_num at this

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

-- We always consider limsups of sequences along the filter `atTop`.
local notation "limsup" => fun u : ℕ → EReal => Filter.limsup u Filter.atTop

namespace Proofnet343

theorem _root_.Rudin_exercise_3_5_corrected
    (a b : ℕ → ℝ)
    (h1 : limsup (fun n => (a n : EReal)) ≠ ⊥ ∨ limsup (fun n => (b n : EReal)) ≠ ⊤)
    (h2 : limsup (fun n => (a n : EReal)) ≠ ⊤ ∨ limsup (fun n => (b n : EReal)) ≠ ⊥) :
    limsup (fun n => ((a n + b n : ℝ) : EReal)) ≤
      limsup (fun n => (a n : EReal)) + limsup (fun n => (b n : EReal)) := by
  -- Step 1: Rewrite the LHS to use pointwise EReal addition, since (↑(a + b)) = (↑a) + (↑b).
  have hcast : (fun n => ((a n + b n : ℝ) : EReal)) = (fun n => (a n : EReal) + (b n : EReal)) := by
    funext n; exact_mod_cast rfl
  rw [hcast]
  -- Step 2: Apply Mathlib's `EReal.limsup_add_le`.
  exact EReal.limsup_add_le h1 h2

end Proofnet343
