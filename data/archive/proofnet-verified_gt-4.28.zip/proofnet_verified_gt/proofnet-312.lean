import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

/-Informal Statement

Show that if $X$ is regular, every pair of points of $X$ have neighborhoods whose closures are disjoint.
-/

/-Informal Proof

Let $x, y \in X$ be two points such that $x \neq y$. Since $X$ is regular (and thus Hausdorff), there exist disjoint open sets $U, V \subseteq X$ such that $x \in U$ and $y \in V$.
Note that $y \notin \bar{U}$. Otherwise $V$ must intersect $U$ in a point different from $y$ since $V$ is an open neighborhood of $y$, which is a contradiction since $U$ and $V$ are disjoint.
Since $X$ is regular and $\bar{U}$ is closed, there exist disjoint open sets $U^{\prime}, V^{\prime} \subseteq X$ such that $\bar{U} \subseteq U^{\prime}$ and $y \in V^{\prime}$.

And now $U$ and $V^{\prime}$ are neighborhoods of $x$ and $y$ whose closures are disjoint. If $\bar{U} \cap \overline{V^{\prime}} \neq \emptyset$, then it follows that $U^{\prime} \supseteq U$ intersects $\overline{V^{\prime}}$. Since $U^{\prime}$ is open, it follows that $U^{\prime}$ intersects $V^{\prime}$, which is a contradiction.
-/

theorem Munkres_exercise_31_1 {X : Type*} [TopologicalSpace X]
  (hX : RegularSpace X) (x y : X) :
  ∃ (U V : Set X), IsOpen U ∧ IsOpen V ∧ x ∈ U ∧ y ∈ V ∧ closure U ∩ closure V = ∅ := by
  sorry

/-! ## Refutation
The original statement `Munkres_exercise_31_1` is false: `Munkres_exercise_31_1_neg` proves the negation of its elaborated type. -/
theorem Munkres_exercise_31_1_neg : ¬ (type_of% @Munkres_exercise_31_1) := by
  intro h
  -- Step 1: Specialise to the one-point space `X = PUnit` (in the statement's universe),
  -- which is regular, and take the *same* point twice: `x = y = PUnit.unit`.
  -- The formal statement has no hypothesis `x ≠ y`, so this is allowed.
  obtain ⟨U, V, -, -, hU, hV, hUV⟩ := h (X := PUnit) inferInstance PUnit.unit PUnit.unit
  -- Step 2: The point lies in `U ⊆ closure U` and in `V ⊆ closure V`,
  -- hence in `closure U ∩ closure V`.
  have hmem : PUnit.unit ∈ closure U ∩ closure V := ⟨subset_closure hU, subset_closure hV⟩
  -- Step 3: But that intersection was claimed to be empty — contradiction.
  rw [hUV] at hmem
  exact hmem

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace
open scoped Topology

/-
The original formalization is not faithful to the informal statement.

The informal statement's hypothesis is that X is "regular" in Munkres' sense (T1 + regular,
i.e., T3), and the conclusion is that any two distinct points have neighborhoods with disjoint
closures (the T2.5 property). The Lean formalization replaces the hypothesis "regular" with
`[T25Space X]`, which already asserts exactly the conclusion — making the theorem a tautology
("T2.5 implies T2.5") rather than the substantive "T3 implies T2.5".

The correction uses `[RegularSpace X]` and `[T1Space X]` separately (which together give
Munkres' "regular" = T3). In Mathlib, `RegularSpace + T1Space` implies `T3Space`, which in
turn implies `T25Space` (via `T3Space.t25Space`), so the conclusion follows.
-/

theorem Munkres_exercise_31_1_corrected {X : Type*} [TopologicalSpace X]
    [RegularSpace X] [T1Space X]
    (x y : X) (hxy : x ≠ y) :
    ∃ U V : Set X, IsOpen U ∧ IsOpen V ∧ x ∈ U ∧ y ∈ V ∧
      closure U ∩ closure V = (∅ : Set X) := by
  classical
  -- Step 1: RegularSpace + T1Space gives T3Space, which implies T2.5 in Mathlib.
  haveI : T25Space X := T3Space.t25Space
  -- Step 2: Use the T2.5 separation lemma to obtain open neighbourhoods with disjoint closures.
  obtain ⟨U, hxU, hUopen, V, hyV, hVopen, hdisj⟩ :=
    exists_open_nhds_disjoint_closure (x := x) (y := y) hxy
  -- Step 3: Convert the disjointness information into the required equality of intersections.
  have hcl : closure U ∩ closure V = (∅ : Set X) := by
    -- Step 3.1: Show every point in the intersection would contradict disjointness.
    apply Set.eq_empty_of_subset_empty
    intro z hz
    exact (Set.disjoint_left.mp hdisj hz.1 hz.2).elim
  -- Step 4: Package the data into the target existential statement.
  refine ⟨U, V, hUopen, hVopen, hxU, hyV, hcl⟩
