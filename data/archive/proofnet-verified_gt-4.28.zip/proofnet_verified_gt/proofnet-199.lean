import Mathlib


open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators InnerProductSpace

/-Informal Statement

Prove that if $a \in \mathbf{F}$, $v \in V$, and $av = 0$, then $a = 0$ or $v = 0$.
-/

/-Informal Proof

If $a=0$, then we immediately have our result. So suppose $a \neq 0$. Then, because $a$ is some nonzero real or complex number, it has a multiplicative inverse $\frac{1}{a}$. Now suppose that $v$ is some vector such that
$$
a v=0
$$
Multiply by $\frac{1}{a}$ on both sides of this equation to get
$$
\begin{aligned}
\frac{1}{a}(a v) & =\frac{1}{a} 0 & & \\
\frac{1}{a}(a v) & =0 & & \\
\left(\frac{1}{a} \cdot a\right) v & =0 & & \text { (associativity) } \\
1 v & =0 & & \text { (definition of } 1/a) \\
v & =0 & & \text { (multiplicative identity) }
\end{aligned}
$$
Hence either $a=0$ or, if $a \neq 0$, then $v=0$.
-/

theorem Axler_exercise_1_4 {F V : Type*} [AddCommGroup V] [Field F]
  [Module F V] (v : V) (a : F): a • v = 0 ↔ a = 0 ∨ v = 0 := by
  -- Step 1: split the iff into its two implications.
  constructor
  · -- Step 2: forward direction. Assume `a • v = 0`; show `a = 0 ∨ v = 0`.
    intro h
    -- Step 2.1: it suffices to show `v = 0` under the extra assumption `a ≠ 0`.
    rcases eq_or_ne a 0 with ha | ha
    · -- Step 2.2: if `a = 0` we are immediately in the left disjunct.
      exact Or.inl ha
    · -- Step 2.3: `a ≠ 0` in a field, so `a` is invertible; multiply `a • v = 0` by `a⁻¹`.
      refine Or.inr ?_
      -- Step 2.4: `v = 1 • v = (a⁻¹ * a) • v = a⁻¹ • (a • v) = a⁻¹ • 0 = 0`.
      calc v = (1 : F) • v := (one_smul F v).symm
        _ = (a⁻¹ * a) • v := by rw [inv_mul_cancel₀ ha]
        _ = a⁻¹ • (a • v) := mul_smul a⁻¹ a v
        _ = a⁻¹ • (0 : V) := by rw [h]
        _ = 0 := smul_zero a⁻¹
  · -- Step 3: backward direction. Either factor being zero kills the scalar multiple.
    rintro (rfl | rfl)
    · -- Step 3.1: `0 • v = 0`.
      exact zero_smul F v
    · -- Step 3.2: `a • 0 = 0`.
      exact smul_zero a


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators

theorem Axler_exercise_1_4_corrected {F V : Type*} [AddCommGroup V] [Field F]
  [Module F V] (v : V) (a : F): a • v = 0 → a = 0 ∨ v = 0 := by
  -- Step 1: Introduce the hypothesis `a • v = 0` so we can reason with it directly.
  intro h
  -- Step 2: Interpret the equality `a • v = 0` via the lemma `smul_eq_zero` that holds over fields.
  have hDisj : a = 0 ∨ v = 0 := by
    -- Step 2.1: Apply `smul_eq_zero.mp` to translate the equality into the desired disjunction.
    simpa using (smul_eq_zero.mp h)
  -- Step 3: Output the disjunction computed in Step 2 to prove the goal.
  exact hDisj
