import Mathlib


open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-Informal Statement

Suppose $f$ is an analytic function defined everywhere in $\mathbb{C}$ and such that for each $z_0 \in \mathbb{C}$ at least one coefficient in the expansion $f(z) = \sum_{n=0}^\infty c_n(z - z_0)^n$ is equal to 0. Prove that $f$ is a polynomial.
-/

/-Informal Proof

Say that at least one of the coefficients of the Taylor series vanishes is the same as saying that for every $a \in \mathbb{C}$ there is $m \in \mathbb{N}$ such that $f^{(m)}(a)=0$.
Consider $A_n:=\left\{z \in \mathbb{C}: f^{(n)}(z)=0\right\}$ for each $n \in \mathbb{N}$. Note that:
$f$ is polynomial iff $A_n$ is not countable for some $n \in \mathbb{N}$.
Indeed, if $f$ is polynomial of degree $n$, then $f^{(n+1)}(z)=0$ for all $z \in \mathbb{C}$, then $A_{n+1}=\mathbb{C}$, so, $A_{n+1}$ is not countable. Conversely, if there is $n \in \mathbb{C}$ such that $A_n$ is not countable, then $A_n$ has a limit point, then by Identity principle we have $f^{(n)}(z)=0$ for all $z \in \mathbb{C}$, so, $f$ is a polynomial of degree at most $n-1$.

Therefore, tt suffices to show that there is $n \in \mathbb{N}$ such that $A_n$ is not countable. Indeed, consider $\bigcup_{n \in \mathbb{N}} A_n$, by hypothesis for each $a \in \mathbb{C}$ there is $m \in \mathbb{N}$ such that $f^{(m)}(a)=0$, then $\mathbb{C} \subseteq \bigcup_{n \in \mathbb{N}} A_n$. Therefore, $\bigcup_{n \in \mathbb{N}} A_n$ is not countable, then there is $n \in \mathbb{N}$ such that $A_n$ is not countable.
-/

theorem Shakarchi_exercise_2_13 {f : ℂ → ℂ}
    (hf : ∀ z₀ : ℂ, ∃ (s : Set ℂ) (c : ℕ → ℂ), IsOpen s ∧ z₀ ∈ s ∧
      ∀ z ∈ s, Tendsto (λ n => ∑ i ∈ range n, (c i) * (z - z₀)^i) atTop (𝓝 (f z₀))
      ∧ ∃ i, c i = 0) :
    ∃ (c : ℕ → ℂ) (n : ℕ), f = λ z => ∑ i ∈ range n, (c i) * z ^ n := by
  sorry

/-! ## Refutation
The original statement `Shakarchi_exercise_2_13` is false: `Shakarchi_exercise_2_13_neg` proves the negation of its elaborated type. -/
theorem Shakarchi_exercise_2_13_neg : ¬ (type_of% @Shakarchi_exercise_2_13) := by
  intro H
  -- Step 1: the constant function 1 satisfies the hypothesis, with its genuine
  -- Taylor coefficients c = (1, 0, 0, ...) and s = univ.
  obtain ⟨c, n, hc⟩ := @H (fun _ => (1 : ℂ)) (by
    intro z₀
    refine ⟨Set.univ, fun i => if i = 0 then 1 else 0, isOpen_univ, Set.mem_univ _, ?_⟩
    intro z _
    -- Step 1.1: the coefficient c 1 vanishes.
    refine ⟨?_, ⟨1, by simp⟩⟩
    -- Step 1.2: every partial sum with at least one term equals 1, so the
    -- partial sums are eventually constant 1 = f z₀.
    refine tendsto_const_nhds.congr' ?_
    filter_upwards [eventually_ge_atTop 1] with m hm
    rw [Finset.sum_eq_single 0]
    · simp
    · intro b _ hb; simp [hb]
    · intro h; exact absurd (Finset.mem_range.2 (by omega)) h)
  -- Step 2: evaluating the conclusion at 0 gives 1 = ∑ c i * 0^n = 0.
  have h0 := congrFun hc 0
  simp only at h0
  -- Step 2.1: case n = 0 (empty sum) and case n > 0 (0^n = 0).
  rcases Nat.eq_zero_or_pos n with rfl | hn
  · simp at h0
  · simp [zero_pow hn.ne'] at h0


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Complex Filter Function Metric Finset
open scoped BigOperators Topology

open scoped Topology

noncomputable section

theorem Shakarchi_exercise_2_13_corrected
    {f : ℂ → ℂ}
    (hf_diff : Differentiable ℂ f)
    (hf_vanish : ∀ z₀ : ℂ, ∃ n : ℕ,
      iteratedDeriv n f z₀ / (n.factorial : ℂ) = 0) :
    ∃ (p : Polynomial ℂ), f = fun z => Polynomial.aeval z p := by
  classical
  -- Step 1: Convert the literal Taylor-coefficient hypothesis into the derivative-zero form.
  -- Step 1.1: Define the zero set of the `n`-th iterated derivative.
  let Z : ℕ → Set ℂ := fun n => {z : ℂ | iteratedDeriv n f z = 0}

  -- Step 1.2: Since `n!` is nonzero in `ℂ`, a zero Taylor coefficient means
  -- `iteratedDeriv n f z = 0`.
  have hf_vanish_deriv : ∀ z₀ : ℂ, ∃ n : ℕ, iteratedDeriv n f z₀ = 0 := by
    intro z₀
    rcases hf_vanish z₀ with ⟨n, hn⟩
    refine ⟨n, ?_⟩
    have hfact : (n.factorial : ℂ) ≠ 0 := by
      exact_mod_cast Nat.factorial_ne_zero n
    exact (div_eq_zero_iff.mp hn).resolve_right hfact

  -- Step 2: Use Baire category to find one derivative order whose zero set has interior.
  -- Step 2.1: Entire functions are smooth, so every iterated derivative is continuous.
  have hf_contDiff : ContDiff ℂ ⊤ f := hf_diff.contDiff

  -- Step 2.2: Each `Z n` is closed as the preimage of `{0}` under a continuous function.
  have hZ_closed : ∀ n : ℕ, IsClosed (Z n) := by
    intro n
    have hcont : Continuous (iteratedDeriv n f) :=
      hf_contDiff.continuous_iteratedDeriv n (by simp)
    simpa [Z] using isClosed_singleton.preimage hcont

  -- Step 2.3: The pointwise vanishing hypothesis says that the closed sets `Z n`
  -- cover the whole complex plane.
  have hZ_cover : (⋃ n : ℕ, Z n) = Set.univ := by
    ext z
    constructor
    · intro _
      trivial
    · intro _
      rcases hf_vanish_deriv z with ⟨n, hn⟩
      exact Set.mem_iUnion.mpr ⟨n, hn⟩

  -- Step 2.4: By Baire's theorem, at least one `Z N` has nonempty interior.
  obtain ⟨N, hN_interior⟩ :=
    nonempty_interior_of_iUnion_of_closed (X := ℂ) (f := Z) hZ_closed hZ_cover

  -- Step 2.5: Choose a point in that interior.
  rcases hN_interior with ⟨w, hw⟩

  -- Step 3: Promote local vanishing of the `N`-th derivative to global vanishing.
  -- Step 3.1: Membership in `interior (Z N)` gives eventual equality to zero near `w`.
  have hN_eventually_zero : iteratedDeriv N f =ᶠ[𝓝 w] (fun _ : ℂ => 0) := by
    refine Filter.eventuallyEq_iff_exists_mem.mpr ?_
    refine ⟨interior (Z N), isOpen_interior.mem_nhds hw, ?_⟩
    intro z hz
    have hzZ : z ∈ Z N := interior_subset hz
    exact hzZ

  -- Step 3.2: The original entire function is analytic on all of `ℂ`.
  have hf_analytic : AnalyticOnNhd ℂ f Set.univ := fun z _ => hf_diff.analyticAt z

  -- Step 3.3: Therefore the `N`-th iterated derivative is analytic on all of `ℂ`.
  have hN_analytic : AnalyticOnNhd ℂ (iteratedDeriv N f) Set.univ := by
    simpa [iteratedDeriv_eq_iterate] using hf_analytic.iterated_deriv N

  -- Step 3.4: The zero function is analytic on all of `ℂ`.
  have hzero_analytic : AnalyticOnNhd ℂ (0 : ℂ → ℂ) Set.univ := analyticOnNhd_const

  -- Step 3.5: The identity principle makes the local equality global.
  have hN_zero_fun : iteratedDeriv N f = (0 : ℂ → ℂ) :=
    hN_analytic.eq_of_eventuallyEq hzero_analytic hN_eventually_zero

  -- Step 4: Build the polynomial from the Taylor coefficients of `f` at `0`.
  -- Step 4.1: Name the Taylor coefficients at the origin in the literal normalized form.
  let c : ℕ → ℂ := fun n => iteratedDeriv n f 0 / (n.factorial : ℂ)

  -- Step 4.2: The polynomial is the finite Taylor sum up to order `N - 1`.
  let p : Polynomial ℂ := ∑ i ∈ Finset.range N, Polynomial.C (c i) * Polynomial.X ^ i

  -- Step 5: Show all Taylor coefficients from order `N` onward vanish.
  -- Step 5.1: First rewrite global vanishing in terms of iterated `deriv`.
  have hN_zero_iterate : deriv^[N] f = (0 : ℂ → ℂ) := by
    simpa [← iteratedDeriv_eq_iterate] using hN_zero_fun

  -- Step 5.2: If `m ≥ N`, write `m = N + k` and differentiate the zero `N`-th
  -- derivative `k` more times.
  have hcoeff_tail : ∀ m : ℕ, N ≤ m → c m = 0 := by
    intro m hm
    obtain ⟨k, rfl⟩ := exists_add_of_le hm
    have hderiv_zero : iteratedDeriv (N + k) f 0 = 0 := by
      rw [Nat.add_comm N k, iteratedDeriv_eq_iterate]
      rw [Function.iterate_add_apply]
      rw [hN_zero_iterate]
      simp [← iteratedDeriv_eq_iterate]
    simp [c, hderiv_zero]

  -- Step 6: Use the analytic Taylor expansion at `0` and the tail vanishing to get
  -- local equality with the finite polynomial `p`.
  -- Step 6.1: The Taylor series of an analytic function has coefficients
  -- `iteratedDeriv n f 0 / n!`.
  have hf_power :
      HasFPowerSeriesAt f (FormalMultilinearSeries.ofScalars ℂ c) 0 := by
    simpa [c] using (hf_diff.analyticAt 0).hasFPowerSeriesAt

  -- Step 6.2: Choose a ball on which this power series represents `f`.
  rcases hf_power with ⟨r, hr⟩

  -- Step 6.3: Upgrade the power series to a finite power series using the coefficient tail.
  have hf_finite :
      HasFiniteFPowerSeriesOnBall f (FormalMultilinearSeries.ofScalars ℂ c) 0 N r :=
    { hr with
      finite := by
        intro m hm
        simp [hcoeff_tail m hm] }

  -- Step 6.4: On that ball, the finite power series is exactly the polynomial `p`.
  have hf_eq_poly_near :
      f =ᶠ[𝓝 (0 : ℂ)] fun z : ℂ => Polynomial.aeval (R := ℂ) (A := ℂ) z p := by
    refine Filter.eventuallyEq_iff_exists_mem.mpr ?_
    refine ⟨Metric.eball (0 : ℂ) r, Metric.eball_mem_nhds _ hr.r_pos, ?_⟩
    intro z hz
    have hpartial := hf_finite.eq_partialSum' z hz N le_rfl
    rw [hpartial]
    simp [p, FormalMultilinearSeries.partialSum, FormalMultilinearSeries.ofScalars]

  -- Step 7: Extend the local equality to global equality by the analytic identity theorem.
  -- Step 7.1: The polynomial function is analytic on the whole complex plane.
  have hp_analytic :
      AnalyticOnNhd ℂ (fun z : ℂ => Polynomial.aeval (R := ℂ) (A := ℂ) z p) Set.univ := by
    simpa using
      ((analyticOnNhd_id : AnalyticOnNhd ℂ (fun z : ℂ => z) Set.univ).aeval_polynomial
        (A := ℂ) p)

  -- Step 7.2: Since both functions are entire and agree near `0`, they agree everywhere.
  have hglobal : f = fun z : ℂ => Polynomial.aeval (R := ℂ) (A := ℂ) z p :=
    hf_analytic.eq_of_eventuallyEq hp_analytic hf_eq_poly_near

  -- Step 8: Package the polynomial witness.
  exact ⟨p, by simpa using hglobal⟩

end
