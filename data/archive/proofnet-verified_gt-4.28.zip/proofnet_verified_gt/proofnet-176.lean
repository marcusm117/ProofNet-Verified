import Mathlib
import Mathlib.Analysis.Complex.OpenMapping


open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-Informal Statement

Suppose that $f$ is holomorphic in an open set $\Omega$. Prove that if $\text{Re}(f)$ is constant, then $f$ is constant.
-/

/-Informal Proof

Let $f(z)=f(x, y)=u(x, y)+i v(x, y)$, where $z=x+i y$.
Since $\operatorname{Re}(f)=$ constant,
$$
\frac{\partial u}{\partial x}=0, \frac{\partial u}{\partial y}=0 .
$$
By the Cauchy-Riemann equations,
$$
\frac{\partial v}{\partial x}=-\frac{\partial u}{\partial y}=0 .
$$
Thus, in $\Omega$,
$$
f^{\prime}(z)=\frac{\partial f}{\partial x}=\frac{\partial u}{\partial x}+i \frac{\partial v}{\partial x}=0+0=0 .
$$
3
Thus $f(z)$ is constant.
-/

theorem Shakarchi_exercise_1_13a {f : ℂ → ℂ} (Ω : Set ℂ) (a b : Ω) (h : IsOpen Ω)
  (hf : DifferentiableOn ℂ f Ω) (hc : ∃ (c : ℝ), ∀ z ∈ Ω, (f z).re = c) :
  f a = f b := by
  sorry

/-!
### Counterexample construction

The formalization drops the *connectedness* hypothesis on `Ω`: the informal exercise
concerns a domain (connected open set), where `Re f` constant forces `f` constant.
With only `IsOpen Ω`, a function that is locally constant on a *disconnected* `Ω`
is holomorphic there and may take two different values sharing the same real part.

Concretely we take
* `Om = {z | z.re < 1} ∪ {z | 9 < z.re}`  (open, but disconnected), and
* `gcex z = if z.re < 5 then 0 else I`,

so that `Re (gcex z) = 0` on all of `Om`, yet `gcex 0 = 0 ≠ I = gcex 10`
with `0, 10 ∈ Om`.
-/

/-- The locally constant, globally non-constant witness. -/
noncomputable def gcex176 : ℂ → ℂ := fun z => if z.re < 5 then 0 else Complex.I

/-- The disconnected open set. -/
def Om176 : Set ℂ := {z : ℂ | z.re < 1} ∪ {z : ℂ | 9 < z.re}

/-- Step 1: `Om176` is open, being a union of two open half-planes. -/
theorem Om176_isOpen : IsOpen Om176 :=
  -- Step 1.1: `{z | z.re < 1}` is open since `Complex.re` is continuous.
  (isOpen_lt Complex.continuous_re continuous_const).union
    -- Step 1.2: likewise for `{z | 9 < z.re}`.
    (isOpen_lt continuous_const Complex.continuous_re)

/-- Step 2: `gcex176` is (complex) differentiable on `Om176`, because near every point of
`Om176` it agrees with a constant function. -/
theorem gcex176_differentiableOn : DifferentiableOn ℂ gcex176 Om176 := by
  -- Step 2.1: it suffices to prove differentiability at each point of `Om176`.
  intro z hz
  refine DifferentiableAt.differentiableWithinAt ?_
  rcases hz with h | h
  · -- Step 2.2: on the left piece `z.re < 1 < 5`, so the open set `{w | w.re < 5}`
    -- is a neighbourhood of `z` on which `gcex176` is identically `0`.
    have hU : {w : ℂ | w.re < 5} ∈ 𝓝 z :=
      (isOpen_lt Complex.continuous_re continuous_const).mem_nhds
        (by simpa using h.trans (by norm_num))
    have he : gcex176 =ᶠ[𝓝 z] (fun _ => (0 : ℂ)) := by
      filter_upwards [hU] with w hw; simp [gcex176, hw]
    -- Step 2.3: a constant function is differentiable, and differentiability is local.
    exact (differentiableAt_const (0 : ℂ)).congr_of_eventuallyEq he
  · -- Step 2.4: on the right piece `5 < 9 < z.re`, so `{w | 5 < w.re}` is a
    -- neighbourhood of `z` on which `gcex176` is identically `I`.
    have hU : {w : ℂ | 5 < w.re} ∈ 𝓝 z :=
      (isOpen_lt continuous_const Complex.continuous_re).mem_nhds
        (by simpa using (by norm_num : (5:ℝ) < 9).trans h)
    have he : gcex176 =ᶠ[𝓝 z] (fun _ => Complex.I) := by
      filter_upwards [hU] with w hw
      have hnot : ¬ (w.re < 5) := not_lt.2 (le_of_lt hw)
      simp [gcex176, hnot]
    exact (differentiableAt_const Complex.I).congr_of_eventuallyEq he

/-- Step 3: the real part of `gcex176` is constantly `0` (both branch values, `0` and `I`,
have real part `0`). -/
theorem gcex176_re_const : ∃ (c : ℝ), ∀ z ∈ Om176, (gcex176 z).re = c :=
  ⟨0, by intro z _; by_cases h : z.re < 5 <;> simp [gcex176, h]⟩

/-! ## Refutation
The original statement `Shakarchi_exercise_1_13a` is false: `Shakarchi_exercise_1_13a_neg` proves the negation of its elaborated type. -/
theorem Shakarchi_exercise_1_13a_neg : ¬ (type_of% @Shakarchi_exercise_1_13a) := by
  -- Step 4: assume the (false) statement and specialise it to the counterexample.
  intro thm
  -- Step 4.1: apply it with `f := gcex176`, `Ω := Om176`, `a := 0`, `b := 10`.
  --   `0 ∈ Om176` via the left piece (`(0:ℂ).re = 0 < 1`);
  --   `10 ∈ Om176` via the right piece (`9 < 10 = (10:ℂ).re`).
  have key : gcex176 (0 : ℂ) = gcex176 (10 : ℂ) :=
    thm (f := gcex176) Om176 ⟨0, Or.inl (by norm_num)⟩ ⟨10, Or.inr (by norm_num)⟩
      Om176_isOpen gcex176_differentiableOn gcex176_re_const
  -- Step 4.2: but `gcex176 0 = 0` and `gcex176 10 = I`, and `0 ≠ I`.
  revert key
  norm_num [gcex176, Complex.ext_iff]


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Complex Filter Function Metric Finset
open scoped BigOperators Topology

namespace Exercise_1_13a

open Set Metric

noncomputable section

lemma open_subset_verticalLine_eq_empty {s : Set ℂ} {c : ℝ}
    (hs : IsOpen s) (hsub : s ⊆ {w : ℂ | w.re = c}) : s = ∅ := by
  classical
  -- Step 1: Prove emptiness by contradiction; assume there exists `z ∈ s`.
  apply by_contra fun hne =>
  have hnonempty : (Set.Nonempty s) := Set.nonempty_iff_ne_empty.mpr hne
  let z : ℂ := hnonempty.choose
  have hz : z ∈ s := by
    simpa [z] using hnonempty.choose_spec
  -- Step 2: Use openness to find a radius `r` with `ball z r ⊆ s`.
  have hposball : ∃ r, 0 < r ∧ ball z r ⊆ s := (Metric.isOpen_iff.mp hs) z hz
  let r : ℝ := hposball.choose
  have hrpos : 0 < r := by
    simpa [r] using (hposball.choose_spec).1
  have hrsubset : ball z r ⊆ s := by
    simpa [r, z] using (hposball.choose_spec).2
  -- Step 3: Consider the point obtained by shifting `z` along the real axis.
  let w : ℂ := z + (r / 2 : ℝ)
  have hw_ball : w ∈ ball z r := by
    -- Step 3.1: The displacement has norm `r / 2`, which is strictly smaller than `r`.
    have hdiff : w - z = (r / 2 : ℝ) := by
      simp [w, sub_eq_add_neg, add_comm, add_left_comm]
    have hdist : dist w z = r / 2 := by
      have hnorm : dist w z = ‖((r / 2 : ℝ) : ℂ)‖ := by
        simp [dist_eq, hdiff]
      have hnormReal :
          ‖((r / 2 : ℝ) : ℂ)‖ = r / 2 := by
        have h₁ : ‖((r / 2 : ℝ) : ℂ)‖ = ‖r / 2‖ := by
          simp [Complex.norm_real]
        have h₂ : ‖r / 2‖ = |r / 2| := Real.norm_eq_abs _
        have h₃ : |r / 2| = r / 2 := abs_of_nonneg (half_pos hrpos).le
        exact h₁.trans (h₂.trans h₃)
      exact hnorm.trans hnormReal
    -- Step 3.2: Turn the distance computation into ball membership.
    have : dist w z < r := by
      simpa [hdist] using (half_lt_self hrpos)
    simpa [Metric.mem_ball] using this
  -- Step 4: Both `z` and `w` belong to `s`, so their real parts equal `c`.
  have hz_line : z.re = c := by
    simpa using hsub hz
  have hw_mem : w ∈ s := hrsubset hw_ball
  have hw_line : w.re = c := by
    simpa using hsub hw_mem
  -- Step 5: Compute `w.re` explicitly to see that it differs from `c`.
  have hw_re : w.re = z.re + r / 2 := by
    simp [w]
  have hsum : c = c + r / 2 := by
    calc
      c = w.re := hw_line.symm
      _ = z.re + r / 2 := hw_re
      _ = c + r / 2 := by simp [hz_line]
  -- Step 6: Deduce the impossible inequality `r / 2 = 0`.
  have hr_half_zero : (r / 2 : ℝ) = 0 := by
    have := congrArg (fun t : ℝ => t - c) hsum
    simpa using this.symm
  -- Step 7: Conclude by contradicting the positivity of `r / 2`.
  (half_pos hrpos).ne' (by simpa using hr_half_zero)

/-
Corrected formal statement:
If `Ω` is open *and preconnected* and `f` is holomorphic on `Ω` with constant real part, then
`f` is constant on `Ω`.
-/

theorem _root_.Shakarchi_exercise_1_13a_corrected {f : ℂ → ℂ} (Ω : Set ℂ) (a b : Ω) (hΩ : IsOpen Ω)
    (hconn : IsPreconnected Ω) (hf : DifferentiableOn ℂ f Ω)
    (hc : ∃ c : ℝ, ∀ z ∈ Ω, (f z).re = c) : f a = f b := by
  classical
  -- Step 1: Extract the real constant and restate the image constraint.
  rcases hc with ⟨c, hc⟩
  -- Step 2: Upgrade differentiability to analyticity on the open set.
  have hAnalytic : AnalyticOnNhd ℂ f Ω := hf.analyticOnNhd hΩ
  -- Step 3: Apply the open mapping dichotomy on preconnected sets.
  have hDichotomy := AnalyticOnNhd.is_constant_or_isOpen (g := f) (U := Ω) hAnalytic hconn
  rcases hDichotomy with hconst | hopen
  · -- Step 3.1: In the constant case, evaluate both points directly.
    rcases hconst with ⟨w, hw⟩
    -- Step 3.1.1: Use the provided equalities `f z = w` for the relevant points.
    have ha : f a = w := hw a a.property
    have hb : f b = w := hw b b.property
    -- Step 3.1.2: Combine both equalities to reach the desired equality.
    exact ha.trans hb.symm
  · -- Step 3.2: In the "open image" case, we derive a contradiction.
    have hOpenImage : IsOpen (f '' Ω) := hopen Ω (Subset.rfl) hΩ
    -- Step 3.2.1: Every value of `f` on `Ω` has real part `c`, so the image sits inside a line.
    have hsubset : f '' Ω ⊆ {w : ℂ | w.re = c} := by
      intro w hw
      rcases hw with ⟨z, hz, rfl⟩
      simpa using hc z hz
    -- Step 3.2.2: Invoke the geometric lemma to deduce that the image must be empty.
    have hEmpty : f '' Ω = ∅ := open_subset_verticalLine_eq_empty hOpenImage hsubset
    -- Step 3.2.3: Produce an explicit element of the image, contradicting emptiness.
    have hmem : f a ∈ f '' Ω := ⟨a, a.property, rfl⟩
    simp [hEmpty] at hmem
end

end Exercise_1_13a
