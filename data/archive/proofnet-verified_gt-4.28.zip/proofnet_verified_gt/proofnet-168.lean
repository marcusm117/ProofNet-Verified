import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $E$ be a bounded set in $R^{1}$. Prove that there exists a real function $f$ such that $f$ is uniformly continuous and is not bounded on $E$.
-/

/-Informal Proof

Since $E$ is bounded in $\mathbb{R}$, it is totally bounded. A uniformly continuous function maps totally bounded sets to totally bounded sets. In $\mathbb{R}$, totally bounded sets are bounded, so $f(E)$ is bounded.
-/

theorem Rudin_exercise_4_8b
  (E : Set ℝ) :
  ∃ f : ℝ → ℝ, UniformContinuousOn f E ∧ ¬ Bornology.IsBounded (Set.image f E) := by
  sorry

/-! ## Refutation of the original ProofNet formalization

The original Lean declaration asks for such a function on *every* set of reals.
Take the empty set. Its image under every function is empty and hence bounded.
-/
theorem Rudin_exercise_4_8b_neg : ¬ (type_of% @Rudin_exercise_4_8b) := by
  intro h
  obtain ⟨f, _, hunbounded⟩ := h ∅
  apply hunbounded
  rw [Set.image_empty]
  exact Bornology.isBounded_empty

/-! ## Why the benchmark's informal statement is false

The benchmark transcription explicitly assumes that E is bounded. Every bounded
subset of ℝ is totally bounded, since its closure is compact. Uniform continuity
preserves total boundedness of the image, which implies boundedness. Thus no
function can satisfy the requested conditions on a bounded E.
-/
theorem Rudin_exercise_4_8b_bounded_refutation (E : Set ℝ) (hE : Bornology.IsBounded E) :
    ¬ ∃ f : ℝ → ℝ, UniformContinuousOn f E ∧ ¬ Bornology.IsBounded (Set.image f E) := by
  rintro ⟨f, hf, hunbounded⟩
  have htot : TotallyBounded E := hE.isCompact_closure.totallyBounded.subset subset_closure
  let g : E → ℝ := fun x => f x
  have hg : UniformContinuous g := uniformContinuousOn_iff_restrict.mp hf
  have hdom : TotallyBounded (Set.univ : Set E) :=
    (totallyBounded_image_iff (isUniformInducing_val E)).mp (by simpa using htot)
  apply hunbounded
  have hrange : Set.range g = Set.image f E := by
    ext y
    constructor
    · rintro ⟨x, rfl⟩
      exact ⟨x.val, x.property, rfl⟩
    · rintro ⟨x, hx, rfl⟩
      exact ⟨⟨x, hx⟩, rfl⟩
  simpa only [Set.image_univ, hrange] using (hdom.image hg).isBounded

end

/-! ## Corrected statement

In Chapter 4, Exercise 8 of Rudin's *Principles of Mathematical Analysis*, the
first sentence gives the bounded-domain theorem (item 351). The second asks for
a counterexample when the boundedness assumption is omitted. It suffices to
choose one domain and one function. We take all of ℝ and the identity map.

Let $f$ be a real uniformly continuous function on a set $E$ in $\mathbb{R}^{1}$.
Show that $f$ need not be bounded on $E$.
-/
theorem Rudin_exercise_4_8b_corrected :
    ∃ (E : Set ℝ) (f : ℝ → ℝ),
      UniformContinuousOn f E ∧ ¬ Bornology.IsBounded (Set.image f E) := by
  refine ⟨Set.univ, id, uniformContinuous_id.uniformContinuousOn, ?_⟩
  rw [Set.image_id]
  exact fun h => not_bddAbove_univ h.bddAbove
