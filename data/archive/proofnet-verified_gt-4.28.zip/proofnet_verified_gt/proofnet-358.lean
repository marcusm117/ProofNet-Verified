import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Suppose $f^{\prime}(x), g^{\prime}(x)$ exist, $g^{\prime}(x) \neq 0$, and $f(x)=g(x)=0$. Prove that $\lim _{t \rightarrow x} \frac{f(t)}{g(t)}=\frac{f^{\prime}(x)}{g^{\prime}(x)}.$
-/

/-Informal Proof

Since $f(x)=g(x)=0$, we have
$$
\begin{aligned}
\lim _{t \rightarrow x} \frac{f(t)}{g(t)} &=\lim _{t \rightarrow x} \frac{\frac{f(t)-f(x)}{t-x}}{\frac{g(t)-g(x)}{t-x}} \\
&=\frac{\lim _{t \rightarrow x} \frac{f(t)-f(x)}{t-x}}{\lim _{t \rightarrow x} \frac{g(t)-g(x)}{t-x}} \\
&=\frac{f^{\prime}(x)}{g^{\prime}(x)}
\end{aligned}
$$
-/

theorem Rudin_exercise_5_7
  {f g : ℝ → ℝ} {x : ℝ}
  (hf' : DifferentiableAt ℝ f 0)
  (hg' : DifferentiableAt ℝ g 0)
  (hg'_ne_0 : deriv g 0 ≠ 0)
  (f0 : f 0 = 0) (g0 : g 0 = 0) :
  Tendsto (λ x => f x / g x) (𝓝 x) (𝓝 (deriv f x / deriv g x)) := by
  sorry

/-! ## Refutation
The original statement `Rudin_exercise_5_7` is false: `Rudin_exercise_5_7_neg` proves the negation of its elaborated type. -/
theorem Rudin_exercise_5_7_neg : ¬ (type_of% @Rudin_exercise_5_7) := by
  intro h
  -- Step 1: instantiate with f = g = id and x = 0. All hypotheses hold:
  -- id is differentiable at 0, deriv id 0 = 1 ≠ 0, and id 0 = 0.
  have key := @h (fun t => t) (fun t => t) 0 differentiableAt_id differentiableAt_id
    (by simp) rfl rfl
  -- Step 2: the target value is deriv id 0 / deriv id 0 = 1 / 1 = 1.
  simp only [deriv_id''] at key
  -- Step 3: since {y | y ≠ 0} is an open neighbourhood of the limit 1, the function
  -- t ↦ t / t must eventually (along the full filter 𝓝 0) avoid 0.
  have hev : ∀ᶠ t in 𝓝 (0:ℝ), t / t ≠ 0 :=
    key.eventually (isOpen_ne.mem_nhds (by norm_num))
  -- Step 4: 𝓝 0 is not punctured, so the eventual property holds at t = 0 itself,
  -- giving 0 / 0 ≠ 0, which contradicts Lean's convention 0 / 0 = 0.
  exact hev.self_of_nhds (by simp)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

/--
Corrected formal statement: when we take the limit of the quotient along the punctured filter
`𝓝[≠] x` (the usual notion of limit as `t → x`), the quotient converges to
`deriv f x / deriv g x`.  The proof rewrites the quotient in terms of slopes and uses the usual
limit characterization of derivatives.
-/
theorem Rudin_exercise_5_7_corrected
  {f g : ℝ → ℝ} {x : ℝ}
  (hf' : DifferentiableAt ℝ f x)
  (hg' : DifferentiableAt ℝ g x)
  (hg'_ne_0 : deriv g x ≠ 0)
  (f0 : f x = 0) (g0 : g x = 0) :
  Tendsto (λ t => f t / g t) (𝓝[≠] x) (𝓝 (deriv f x / deriv g x)) := by
  classical
  -- Step 1: Convert differentiability information into slope limits for both numerator and denominator.
  have hf_deriv : HasDerivAt f (deriv f x) x := hf'.hasDerivAt
  have hg_deriv : HasDerivAt g (deriv g x) x := hg'.hasDerivAt
  have hf_slope : Tendsto (slope f x) (𝓝[≠] x) (𝓝 (deriv f x)) :=
    (hasDerivAt_iff_tendsto_slope.mp hf_deriv)
  have hg_slope : Tendsto (slope g x) (𝓝[≠] x) (𝓝 (deriv g x)) :=
    (hasDerivAt_iff_tendsto_slope.mp hg_deriv)
  -- Step 2: Use continuity of inversion and multiplication to get the limit for the ratio of slopes.
  have h_slope_ratio :
      Tendsto (fun t => slope f x t / slope g x t) (𝓝[≠] x)
        (𝓝 (deriv f x / deriv g x)) := by
    have hmul :=
      hf_slope.mul ((hg_slope.inv₀ hg'_ne_0))
    simpa [div_eq_mul_inv] using hmul
  -- Step 3: Show that away from `x`, the raw quotient agrees with the slope ratio.
  have h_ne : ∀ᶠ t in 𝓝[≠] x, t ≠ x := by
    have : ({x}ᶜ : Set ℝ) ∈ 𝓝[{x}ᶜ] x := self_mem_nhdsWithin
    simpa [Filter.Eventually, Set.mem_setOf_eq] using this
  have h_eventually_eq :
      (fun t => f t / g t) =ᶠ[𝓝[≠] x] fun t => slope f x t / slope g x t := by
    refine h_ne.mono ?_
    intro t ht
    -- Step 3.1: Rewrite `f t` and `g t` using the slope identity because `t ≠ x` and `f x = g x = 0`.
    have htx : t - x ≠ 0 := sub_ne_zero_of_ne ht
    have hf_expanded : f t = (t - x) * slope f x t := by
      have hf_prod : (t - x) * slope f x t = f t - f x := by
        have hf_formula : slope f x t = (f t - f x) / (t - x) :=
          by simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using
              (slope_def_field (f := f) (a := x) (b := t))
        simpa [hf_formula] using (mul_div_cancel₀ (a := f t - f x) (b := t - x) htx)
      have hf_add : f t = f t - f x + f x := (sub_add_cancel (f t) (f x)).symm
      calc
        f t = f t - f x + f x := hf_add
        _ = (t - x) * slope f x t + f x := by simp [hf_prod]
        _ = (t - x) * slope f x t := by simp [f0]
    have hg_expanded : g t = (t - x) * slope g x t := by
      have hg_prod : (t - x) * slope g x t = g t - g x := by
        have hg_formula : slope g x t = (g t - g x) / (t - x) :=
          by simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using
              (slope_def_field (f := g) (a := x) (b := t))
        simpa [hg_formula] using (mul_div_cancel₀ (a := g t - g x) (b := t - x) htx)
      have hg_add : g t = g t - g x + g x := (sub_add_cancel (g t) (g x)).symm
      calc
        g t = g t - g x + g x := hg_add
        _ = (t - x) * slope g x t + g x := by simp [hg_prod]
        _ = (t - x) * slope g x t := by simp [g0]
    -- Step 3.2: Cancel the common factor `(t - x)` in the quotient.
    calc
      f t / g t = ((t - x) * slope f x t) / ((t - x) * slope g x t) := by
        simp [hf_expanded, hg_expanded]
      _ = slope f x t / slope g x t := by
        simpa [mul_comm, mul_left_comm, mul_assoc] using
          (mul_div_mul_left (a := slope f x t) (b := slope g x t) (c := t - x) htx)
  -- Step 4: Transfer the slope-limit result back to the original quotient via eventual equality.
  exact (tendsto_congr' h_eventually_eq).2 h_slope_ratio
