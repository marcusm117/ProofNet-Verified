import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Suppose $f$ is a real function with domain $R^{1}$ which has the intermediate value property: if $f(a)<c<f(b)$, then $f(x)=c$ for some $x$ between $a$ and $b$. Suppose also, for every rational $r$, that the set of all $x$ with $f(x)=r$ is closed. Prove that $f$ is continuous.
-/

/-Informal Proof

The contradiction is evidently that $x_0$ is a limit point of the set of $t$ such that $f(t)=r$, yet, $x_0$ does not belong to this set. This contradicts the hypothesis that the set is closed.
-/

theorem Rudin_exercise_4_19
  {f : ℝ → ℝ} (hf : ∀ a b c, a < b → f a < c → c < f b → ∃ x, a < x ∧ x < b ∧ f x = c)
  (hg : ∀ r : ℚ, IsClosed {x | f x = r}) : Continuous f := by
  sorry

/-!
## Counterexample

The formalized intermediate-value hypothesis `hf` is strictly weaker than the informal
one: it only demands a witness when `a < b` **and** `f a < c < f b`, i.e. only in the
*increasing* direction.  The informal statement asks for `f x = c` whenever `c` lies
strictly between `f a` and `f b`, in either order.

Consequently every **strictly decreasing** function satisfies `hf` vacuously: `a < b`
forces `f b < f a`, so `f a < c < f b` is impossible.  A strictly decreasing function is
injective, so each level set `{x | f x = r}` is a subsingleton and hence closed, giving
`hg`.  But a strictly decreasing function need not be continuous.

Concretely we take
  `g x = -x`      for `x < 0`,
  `g x = -x - 1`  for `x ≥ 0`,
which is strictly decreasing but jumps at `0`: its range misses the interval `(-1, 0)`.
-/

/-- The counterexample: strictly decreasing with a jump of size `1` at `0`. -/
def Rudin_exercise_4_19_g : ℝ → ℝ := fun x => if x < 0 then -x else -x - 1

/-- Step 1: `Rudin_exercise_4_19_g` is strictly decreasing.

On each of the two pieces it is `x ↦ -x` resp. `x ↦ -x - 1`, and the lower piece
(`x < 0`) takes values in `(0, ∞)` while the upper piece (`x ≥ 0`) takes values in
`(-∞, -1]`, so the pieces are ordered correctly.  All four cases are linear arithmetic. -/
theorem Rudin_exercise_4_19_g_anti : StrictAnti Rudin_exercise_4_19_g := by
  intro a b hab
  -- Step 1.1: split on which piece each of `a`, `b` lies in and finish by `linarith`.
  by_cases hb : b < 0 <;> by_cases ha : a < 0 <;>
    simp only [Rudin_exercise_4_19_g, hb, ha, if_true, if_false] <;> linarith

/-! ## Refutation
The original statement `Rudin_exercise_4_19` is false: `Rudin_exercise_4_19_neg` proves the negation of its elaborated type. -/
theorem Rudin_exercise_4_19_neg : ¬ (type_of% @Rudin_exercise_4_19) := by
  -- Step 2: assume the statement and instantiate it at the counterexample `g`.
  intro H
  -- Step 2.1: the intermediate-value hypothesis holds *vacuously*.
  -- Given `a < b` we have `g b < g a` by strict antitonicity, so `g a < c < g b`
  -- is contradictory.
  have hf : ∀ a b c : ℝ, a < b → Rudin_exercise_4_19_g a < c → c < Rudin_exercise_4_19_g b →
      ∃ x, a < x ∧ x < b ∧ Rudin_exercise_4_19_g x = c := by
    intro a b c hab hac hcb
    have hba := Rudin_exercise_4_19_g_anti hab
    linarith
  -- Step 2.2: every level set is closed, because `g` is injective and hence each
  -- level set has at most one element.
  have hg : ∀ r : ℚ, IsClosed {x | Rudin_exercise_4_19_g x = (r : ℝ)} := by
    intro r
    refine Set.Subsingleton.isClosed ?_
    intro x hx y hy
    exact Rudin_exercise_4_19_g_anti.injective (hx.trans hy.symm)
  -- Step 2.3: so the (false) statement would make `g` continuous.
  have hcont : Continuous Rudin_exercise_4_19_g := H (f := Rudin_exercise_4_19_g) hf hg
  -- Step 3: derive `False` from continuity, using the intermediate value theorem
  -- on `[-1, 0]`.  We have `g 0 = -1` and `g (-1) = 1`, so `-1/2` lies in between
  -- and must be attained; but `g` never takes a value in `(-1, 0)`.
  have hsub := intermediate_value_Icc' (by norm_num : (-1:ℝ) ≤ 0) hcont.continuousOn
  have hmem : (-1/2 : ℝ) ∈ Set.Icc (Rudin_exercise_4_19_g 0) (Rudin_exercise_4_19_g (-1)) := by
    constructor <;> simp [Rudin_exercise_4_19_g] <;> norm_num
  obtain ⟨x, -, hx⟩ := hsub hmem
  -- Step 3.1: on the branch `x < 0` we get `-x = -1/2`, i.e. `x = 1/2 > 0`; contradiction.
  by_cases h : x < 0
  · simp only [Rudin_exercise_4_19_g, h, if_true] at hx; linarith
  -- Step 3.2: on the branch `0 ≤ x` we get `-x - 1 = -1/2`, i.e. `x = -1/2 < 0`; contradiction.
  · push_neg at h
    simp only [Rudin_exercise_4_19_g, if_neg (not_lt.mpr h)] at hx
    linarith

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

noncomputable section

/-
Corrected version:
To recover the intended result, the intermediate value property must work in
both directions.  We add the symmetric hypothesis

`hf_symm : ∀ a b c, a < b →
    ((f a < c ∧ c < f b) ∨ (f b < c ∧ c < f a)) →
    ∃ x, a < x ∧ x < b ∧ f x = c`.

With this genuine Darboux property, the closure of every rational level set
forces continuity.
-/

theorem Rudin_exercise_4_19_corrected
  {f : ℝ → ℝ}
  (hf : ∀ a b c, a < b →
      ((f a < c ∧ c < f b) ∨ (f b < c ∧ c < f a)) →
      ∃ x, a < x ∧ x < b ∧ f x = c)
  (hg : ∀ r : ℚ, IsClosed {x | f x = r}) : Continuous f := by
  -- Step 1: reduce global continuity to continuity at each point.
  refine continuous_iff_continuousAt.2 ?_
  intro x0
  -- Step 2: assume (for contradiction) that `f` is not continuous at `x0`.
  by_contra hcont
  -- Step 2.1: restate non-continuity as failure of the `Tendsto` criterion.
  have hcont' : ¬ Tendsto f (𝓝 x0) (𝓝 (f x0)) := by
    simpa [ContinuousAt] using hcont
  -- Step 2.2: use the sequential characterization to pick a convergent sequence with bad images.
  have hseq :=
    (tendsto_nhds_iff_seq_tendsto (X := ℝ) (Y := ℝ)).not.mp hcont'
  classical
  rcases not_forall.mp hseq with ⟨xn, hx⟩
  rcases Classical.not_imp.mp hx with ⟨hxn_tendsto, hxn_bad⟩
  -- Step 3: from non-convergence of `(f ∘ xn)` obtain a positive gap seen infinitely often.
  have hgap : ∃ ε > (0 : ℝ), ∃ᶠ n in atTop, |f (xn n) - f x0| ≥ ε := by
    classical
    -- Step 3.1: pick a neighborhood where the convergence of `f ∘ xn` fails.
    obtain ⟨s, hs_mem, hs_freq⟩ :=
      (Filter.not_tendsto_iff_exists_frequently_notMem).mp hxn_bad
    rcases Metric.mem_nhds_iff.1 hs_mem with ⟨ε, εpos, hball⟩
    -- Step 3.2: shrinking to a ball gives a concrete gap `ε`.
    have hfreq_ball : ∃ᶠ n in atTop, f (xn n) ∉ Metric.ball (f x0) ε := by
      refine hs_freq.mono ?_
      intro n hn hmem
      exact hn (hball hmem)
    have hfreq_abs : ∃ᶠ n in atTop, |f (xn n) - f x0| ≥ ε := by
      refine hfreq_ball.mono ?_
      intro n hn
      have hnotlt : ¬ dist (f (xn n)) (f x0) < ε := by
        intro hlt
        exact hn (by simpa [Metric.mem_ball] using hlt)
      have hdist : ε ≤ dist (f (xn n)) (f x0) := not_lt.mp hnotlt
      -- Rewrite the distance on `ℝ` as an absolute value.
      simpa [Real.dist_eq, abs_sub_comm] using hdist
    exact ⟨ε, εpos, hfreq_abs⟩
  rcases hgap with ⟨ε, εpos, hfreq_gap⟩
  -- Step 4: split the large deviations into the two one-sided inequalities.
  let p : ℕ → Prop := fun n => f (xn n) ≥ f x0 + ε
  let q : ℕ → Prop := fun n => f (xn n) ≤ f x0 - ε
  have hfreq_or : ∃ᶠ n in atTop, p n ∨ q n := by
    -- Each deviation contributes to one of the two cases.
    refine hfreq_gap.mono ?_
    intro n hlarge
    by_cases hsign : f (xn n) - f x0 ≥ 0
    · -- If the difference is nonnegative, the absolute value drops.
      have habs : |f (xn n) - f x0| = f (xn n) - f x0 := abs_of_nonneg hsign
      have hdiff : f (xn n) - f x0 ≥ ε := by linarith [hlarge, habs]
      have : p n := by linarith [hdiff]
      exact Or.inl this
    · -- If the difference is negative, flip the inequality using the absolute value.
      have hneg : f (xn n) - f x0 < 0 := lt_of_not_ge hsign
      have habs : |f (xn n) - f x0| = -(f (xn n) - f x0) := abs_of_neg hneg
      have hdiff : f x0 - f (xn n) ≥ ε := by linarith [hlarge, habs]
      have : q n := by linarith [hdiff]
      exact Or.inr this
  rcases frequently_or_distrib.mp hfreq_or with hfreq_high | hfreq_low
  · -- Step 4.1: Case 1 — infinitely many `xn n` sit above `f x0 + ε`.
    -- Step 4.1.1: choose a rational level strictly between `f x0` and those high values.
    rcases exists_rat_btwn (by linarith : f x0 < f x0 + ε) with ⟨r, hr_low, hr_high⟩
    -- Step 4.1.2: extract a monotone subsequence where the high inequality always holds.
    rcases extraction_of_frequently_atTop hfreq_high with ⟨φ, hφ_mono, hφ_high⟩
    let yn : ℕ → ℝ := fun n => xn (φ n)
    have hyn_tendsto : Tendsto yn atTop (𝓝 x0) := hxn_tendsto.comp hφ_mono.tendsto_atTop
    -- Step 4.1.3: for each `n`, apply the Darboux property to produce `z` with `f z = r`.
    have hmid : ∀ n, ∃ z, min x0 (yn n) < z ∧ z < max x0 (yn n) ∧ f z = r := by
      intro n
      have hval : f (yn n) ≥ f x0 + ε := by simpa [p, yn] using hφ_high n
      -- Step 4.1.3.1: set the interval endpoints and show they are distinct.
      set a := min x0 (yn n)
      set b := max x0 (yn n)
      have hxneq : x0 ≠ yn n := by
        have hgt : f (yn n) > f x0 := by linarith
        intro hEq
        have : f (yn n) = f x0 := by simp [hEq]
        linarith
      have hlt_ab : a < b := by
        rcases lt_or_gt_of_ne hxneq with hlt | hgt
        · have ha : a = x0 := by simp [a, hlt.le]
          have hb : b = yn n := by simp [b, hlt.le]
          simpa [ha, hb] using hlt
        · have ha : a = yn n := by simp [a, (le_of_lt hgt)]
          have hb : b = x0 := by simp [b, (le_of_lt hgt)]
          simpa [ha, hb] using hgt
      -- Step 4.1.3.2: arrange the inequalities so `r` lies between `f a` and `f b`.
      have hbetween : ((f a < r ∧ r < f b) ∨ (f b < r ∧ r < f a)) := by
        by_cases horder : x0 ≤ yn n
        · have ha : a = x0 := by simp [a, horder]
          have hb : b = yn n := by simp [b, horder]
          have hr_lt_fb : r < f b := by
            have : (r : ℝ) < f x0 + ε := hr_high
            have : (r : ℝ) < f (yn n) := by linarith
            simpa [hb] using this
          have hfa_lt_r : f a < r := by
            have : f x0 < (r : ℝ) := hr_low
            simpa [ha] using this
          exact Or.inl ⟨hfa_lt_r, hr_lt_fb⟩
        · have horder' : yn n ≤ x0 := le_of_not_ge horder
          have ha : a = yn n := by simp [a, horder']
          have hb : b = x0 := by simp [b, horder']
          have hfb_lt_r : f b < r := by
            have : f x0 < (r : ℝ) := hr_low
            simpa [hb] using this
          have hr_lt_fa : r < f a := by
            have : f (yn n) ≥ f x0 + ε := hval
            have : (r : ℝ) < f (yn n) := by linarith
            simpa [ha] using this
          exact Or.inr ⟨hfb_lt_r, hr_lt_fa⟩
      rcases hf a b r hlt_ab hbetween with ⟨z, hz1, hz2, hzval⟩
      exact ⟨z, hz1, hz2, hzval⟩
    -- Step 4.1.4: assemble the sequence `z n` hitting the rational `r`.
    classical
    choose z hz1 hz2 hzval using hmid
    -- Step 4.1.5: show `|z n - x0|` is bounded by `|yn n - x0|`.
    have hbound : ∀ n, |z n - x0| ≤ |yn n - x0| := by
      intro n
      by_cases horder : x0 ≤ yn n
      · have hz_between : x0 ≤ z n ∧ z n ≤ yn n := by
          have hz1' : min x0 (yn n) < z n := hz1 n
          have hz2' : z n < max x0 (yn n) := hz2 n
          have ha : min x0 (yn n) = x0 := by simp [min_eq_left horder]
          have hb : max x0 (yn n) = yn n := by simp [max_eq_right horder]
          have hz1'' : x0 < z n := by simpa [ha] using hz1'
          have hz2'' : z n < yn n := by simpa [hb] using hz2'
          exact ⟨hz1''.le, hz2''.le⟩
        have hz_nonneg : z n - x0 ≥ 0 := by linarith
        have hyn_nonneg : yn n - x0 ≥ 0 := by linarith
        have hz_abs : |z n - x0| = z n - x0 := abs_of_nonneg hz_nonneg
        have hyn_abs : |yn n - x0| = yn n - x0 := abs_of_nonneg hyn_nonneg
        linarith
      · have horder' : yn n ≤ x0 := le_of_not_ge horder
        have hz_between : yn n ≤ z n ∧ z n ≤ x0 := by
          have hz1' : min x0 (yn n) < z n := hz1 n
          have hz2' : z n < max x0 (yn n) := hz2 n
          have ha : min x0 (yn n) = yn n := by simp [min_eq_right horder']
          have hb : max x0 (yn n) = x0 := by simp [max_eq_left horder']
          have hz1'' : yn n < z n := by simpa [ha] using hz1'
          have hz2'' : z n < x0 := by simpa [hb] using hz2'
          exact ⟨hz1''.le, hz2''.le⟩
        have hz_nonpos : z n - x0 ≤ 0 := by linarith
        have hyn_nonpos : yn n - x0 ≤ 0 := by linarith
        have hz_abs : |z n - x0| = -(z n - x0) := abs_of_nonpos hz_nonpos
        have hyn_abs : |yn n - x0| = -(yn n - x0) := abs_of_nonpos hyn_nonpos
        linarith
    -- Step 4.1.6: squeeze the distances to deduce `z n → x0`.
    have hz_tendsto : Tendsto z atTop (𝓝 x0) := by
      refine tendsto_iff_norm_sub_tendsto_zero.2 ?_
      have hnorm_bound : ∀ n, ‖z n - x0‖ ≤ ‖yn n - x0‖ := by
        intro n; simpa [Real.norm_eq_abs] using hbound n
      have hnonneg : ∀ᶠ n in atTop, 0 ≤ ‖z n - x0‖ :=
        Filter.eventually_atTop.mpr ⟨0, by intro n hn; exact norm_nonneg _⟩
      have hbound_ev : ∀ᶠ n in atTop, ‖z n - x0‖ ≤ ‖yn n - x0‖ :=
        Filter.eventually_atTop.mpr ⟨0, by intro n hn; exact hnorm_bound n⟩
      have hlim : Tendsto (fun n => ‖yn n - x0‖) atTop (𝓝 0) := by
        simpa [tendsto_iff_norm_sub_tendsto_zero] using hyn_tendsto
      exact squeeze_zero' hnonneg hbound_ev hlim
    -- Step 4.1.7: closedness of the fiber forces `x0` itself to satisfy `f x0 = r`.
    have hclosed := hg r
    have hz_in : ∀ᶠ n in atTop, z n ∈ {x : ℝ | f x = r} := by
      refine Filter.eventually_atTop.mpr ?_
      refine ⟨0, ?_⟩
      intro n hn
      simpa using hzval n
    have hx0_in : x0 ∈ {x : ℝ | f x = r} :=
      hclosed.mem_of_tendsto hz_tendsto hz_in
    have hx0_val : f x0 = r := hx0_in
    linarith
  · -- Step 4.2: Case 2 — infinitely many `xn n` sit below `f x0 - ε` (mirror argument).
    -- Step 4.2.1: choose a rational level strictly between the low values and `f x0`.
    rcases exists_rat_btwn (by linarith : f x0 - ε < f x0) with ⟨r, hr_low, hr_high⟩
    -- Step 4.2.2: extract a monotone subsequence satisfying the low inequality.
    rcases extraction_of_frequently_atTop hfreq_low with ⟨φ, hφ_mono, hφ_low⟩
    let yn : ℕ → ℝ := fun n => xn (φ n)
    have hyn_tendsto : Tendsto yn atTop (𝓝 x0) := hxn_tendsto.comp hφ_mono.tendsto_atTop
    -- Step 4.2.3: for each `n`, use the intermediate value property to hit the rational `r`.
    have hmid : ∀ n, ∃ z, min x0 (yn n) < z ∧ z < max x0 (yn n) ∧ f z = r := by
      intro n
      have hval : f (yn n) ≤ f x0 - ε := by simpa [q, yn] using hφ_low n
      set a := min x0 (yn n)
      set b := max x0 (yn n)
      have hxneq : x0 ≠ yn n := by
        have hlt : f (yn n) < f x0 := by linarith
        intro hEq
        have : f (yn n) = f x0 := by simp [hEq]
        linarith
      have hlt_ab : a < b := by
        rcases lt_or_gt_of_ne hxneq with hlt | hgt
        · have ha : a = x0 := by simp [a, hlt.le]
          have hb : b = yn n := by simp [b, hlt.le]
          simpa [ha, hb] using hlt
        · have ha : a = yn n := by simp [a, (le_of_lt hgt)]
          have hb : b = x0 := by simp [b, (le_of_lt hgt)]
          simpa [ha, hb] using hgt
      -- Step 4.2.3.1: position `r` between the endpoint values.
      have hbetween : ((f a < r ∧ r < f b) ∨ (f b < r ∧ r < f a)) := by
        by_cases horder : x0 ≤ yn n
        · have ha : a = x0 := by simp [a, horder]
          have hb : b = yn n := by simp [b, horder]
          have hfb_lt_r : f b < r := by
            have : f (yn n) ≤ f x0 - ε := hval
            have : f b ≤ f x0 - ε := by simpa [hb] using this
            linarith [hr_low]
          have hr_lt_fa : r < f a := by
            have : (r : ℝ) < f x0 := hr_high
            simpa [ha] using this
          exact Or.inr ⟨hfb_lt_r, hr_lt_fa⟩
        · have horder' : yn n ≤ x0 := le_of_not_ge horder
          have ha : a = yn n := by simp [a, horder']
          have hb : b = x0 := by simp [b, horder']
          have hfa_lt_r : f a < r := by
            have : f (yn n) ≤ f x0 - ε := hval
            have : f a ≤ f x0 - ε := by simpa [ha] using this
            linarith [hr_low]
          have hr_lt_fb : r < f b := by
            have : (r : ℝ) < f x0 := hr_high
            simpa [hb] using this
          exact Or.inl ⟨hfa_lt_r, hr_lt_fb⟩
      rcases hf a b r hlt_ab hbetween with ⟨z, hz1, hz2, hzval⟩
      exact ⟨z, hz1, hz2, hzval⟩
    classical
    choose z hz1 hz2 hzval using hmid
    -- Step 4.2.4: compare the distances of `z n` and `yn n` to `x0`.
    have hbound : ∀ n, |z n - x0| ≤ |yn n - x0| := by
      intro n
      by_cases horder : x0 ≤ yn n
      · have hz_between : x0 ≤ z n ∧ z n ≤ yn n := by
          have ha : min x0 (yn n) = x0 := by simp [min_eq_left horder]
          have hb : max x0 (yn n) = yn n := by simp [max_eq_right horder]
          have hz1' : x0 < z n := by simpa [ha] using hz1 n
          have hz2' : z n < yn n := by simpa [hb] using hz2 n
          exact ⟨hz1'.le, hz2'.le⟩
        have hz_nonneg : z n - x0 ≥ 0 := by linarith
        have hyn_nonneg : yn n - x0 ≥ 0 := by linarith
        have hz_abs : |z n - x0| = z n - x0 := abs_of_nonneg hz_nonneg
        have hyn_abs : |yn n - x0| = yn n - x0 := abs_of_nonneg hyn_nonneg
        linarith
      · have horder' : yn n ≤ x0 := le_of_not_ge horder
        have hz_between : yn n ≤ z n ∧ z n ≤ x0 := by
          have ha : min x0 (yn n) = yn n := by simp [min_eq_right horder']
          have hb : max x0 (yn n) = x0 := by simp [max_eq_left horder']
          have hz1' : yn n < z n := by simpa [ha] using hz1 n
          have hz2' : z n < x0 := by simpa [hb] using hz2 n
          exact ⟨hz1'.le, hz2'.le⟩
        have hz_nonpos : z n - x0 ≤ 0 := by linarith
        have hyn_nonpos : yn n - x0 ≤ 0 := by linarith
        have hz_abs : |z n - x0| = -(z n - x0) := abs_of_nonpos hz_nonpos
        have hyn_abs : |yn n - x0| = -(yn n - x0) := abs_of_nonpos hyn_nonpos
        linarith
    -- Step 4.2.5: deduce `z n → x0` from the bound and `yn n → x0`.
    have hz_tendsto : Tendsto z atTop (𝓝 x0) := by
      refine tendsto_iff_norm_sub_tendsto_zero.2 ?_
      have hnorm_bound : ∀ n, ‖z n - x0‖ ≤ ‖yn n - x0‖ := by
        intro n; simpa [Real.norm_eq_abs] using hbound n
      have hnonneg : ∀ᶠ n in atTop, 0 ≤ ‖z n - x0‖ :=
        Filter.eventually_atTop.mpr ⟨0, by intro n hn; exact norm_nonneg _⟩
      have hbound_ev : ∀ᶠ n in atTop, ‖z n - x0‖ ≤ ‖yn n - x0‖ :=
        Filter.eventually_atTop.mpr ⟨0, by intro n hn; exact hnorm_bound n⟩
      have hlim : Tendsto (fun n => ‖yn n - x0‖) atTop (𝓝 0) := by
        simpa [tendsto_iff_norm_sub_tendsto_zero] using hyn_tendsto
      exact squeeze_zero' hnonneg hbound_ev hlim
    -- Step 4.2.6: closed fiber forces `f x0 = r`, contradicting the inequalities.
    have hclosed := hg r
    have hz_in : ∀ᶠ n in atTop, z n ∈ {x : ℝ | f x = r} := by
      refine Filter.eventually_atTop.mpr ?_
      refine ⟨0, ?_⟩
      intro n hn
      simpa using hzval n
    have hx0_in : x0 ∈ {x : ℝ | f x = r} :=
      hclosed.mem_of_tendsto hz_tendsto hz_in
    have hx0_val : f x0 = r := hx0_in
    linarith
