import Mathlib


open Function Fintype Subgroup Ideal Polynomial Submodule Zsqrtd
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that $x^3 + 6x + 12$ is irreducible in $\mathbb{Q}$.
-/

/-Informal Proof

Apply Eisenstein's criterion with $p=3$.
-/

theorem Artin_exercise_11_4_1b {F : Type*} [Field F] [Fintype F] (hF : card F = 2) :
  Irreducible (12 + 6 * X + X ^ 3 : Polynomial F) := by
  sorry

/-! ## Refutation
The original statement `Artin_exercise_11_4_1b` is false: `Artin_exercise_11_4_1b_neg` proves the negation of its elaborated type. -/
/-! ### Helper lemmas for the refutation

The informal statement is about `ℚ`, where `x^3 + 6x + 12` is indeed irreducible
by Eisenstein at `p = 3`.  The formalization instead quantifies over an arbitrary
field `F` with `Fintype.card F = 2`, i.e. `F ≃ ZMod 2`, which has characteristic 2.
In such a field `12 = 6 = 0`, so the polynomial degenerates to `X ^ 3 = X * (X * X)`,
a manifestly reducible polynomial.  The concrete counterexample is `F := ZMod 2`
(lifted with `ULift` so that it lives in the universe the statement quantifies over).
-/

/-- Step A: in a field of cardinality `2` the numeral `2` is zero, hence so is the
constant polynomial `2`. -/
private lemma pn11_two_eq_zero {F : Type*} [Field F] [Fintype F] (hF : Fintype.card F = 2) :
    (2 : Polynomial F) = 0 := by
  -- Step A.1: the characteristic divides (in fact equals) the cardinality, so `(2 : F) = 0`.
  have h2 : (2 : F) = 0 := by
    have h := FiniteField.cast_card_eq_zero F
    rw [hF] at h
    exact_mod_cast h
  -- Step A.2: push the numeral through `Polynomial.C` and rewrite with Step A.1.
  have hn : ((2 : ℕ) : F) = 0 := by exact_mod_cast h2
  calc (2 : Polynomial F) = ((2 : ℕ) : Polynomial F) := by norm_cast
    _ = Polynomial.C ((2 : ℕ) : F) := (Polynomial.C_eq_natCast 2).symm
    _ = 0 := by rw [hn, map_zero]

/-- Step B: the polynomial of the statement collapses to `X * (X * X)` in characteristic 2. -/
private lemma pn11_poly_eq {F : Type*} [Field F] [Fintype F] (hF : Fintype.card F = 2) :
    (12 + 6 * X + X ^ 3 : Polynomial F) = X * (X * X) := by
  have e2 := pn11_two_eq_zero hF
  -- Step B.1: `6 = 3 * 2 = 0`.
  have e6 : (6 : Polynomial F) = 0 := by
    have h : (6 : Polynomial F) = 3 * 2 := by norm_num
    rw [h, e2, mul_zero]
  -- Step B.2: `12 = 6 * 2 = 0`.
  have e12 : (12 : Polynomial F) = 0 := by
    have h : (12 : Polynomial F) = 6 * 2 := by norm_num
    rw [h, e2, mul_zero]
  -- Step B.3: what is left is `X ^ 3`, which is `X * (X * X)`.
  rw [e6, e12]; ring

/-- Step C: therefore the polynomial is *not* irreducible over such a field. -/
private lemma pn11_not_irreducible {F : Type*} [Field F] [Fintype F]
    (hF : Fintype.card F = 2) : ¬ Irreducible (12 + 6 * X + X ^ 3 : Polynomial F) := by
  -- Step C.1: rewrite the polynomial as the product `X * (X * X)`.
  rw [pn11_poly_eq hF]
  intro hirr
  -- Step C.2: irreducibility forces one of the two factors to be a unit.
  rcases hirr.isUnit_or_isUnit rfl with h | h
  · -- Step C.3: `X` is never a unit.
    exact Polynomial.not_isUnit_X h
  · -- Step C.4: if `X * X` were a unit, then so would be its left factor `X`.
    exact Polynomial.not_isUnit_X (isUnit_of_mul_isUnit_left h)

theorem Artin_exercise_11_4_1b_neg : ¬ (type_of% @Artin_exercise_11_4_1b) := by
  -- Step 1: assume the (universally quantified) statement holds.
  intro h
  -- Step 2: specialise it to the two-element field `ULift (ZMod 2)`, which is a field
  -- of cardinality 2 living in the universe quantified over by the statement.
  have hcard : Fintype.card (ULift (ZMod 2)) = 2 := by
    rw [Fintype.card_ulift, ZMod.card]
  have hirr := h (F := ULift (ZMod 2)) hcard
  -- Step 3: contradict Step C.
  exact pn11_not_irreducible hcard hirr

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Function Fintype Subgroup Ideal Polynomial Submodule Zsqrtd
open scoped BigOperators

theorem Artin_exercise_11_4_1b_corrected :
  Irreducible (12 + 6 * X + X ^ 3 : Polynomial ℚ) := by
  -- Step 1: Switch to classical logic so that divisibility and case splits on natural numbers are decidable.
  classical
  -- Step 2: Introduce the integer polynomial whose rational image is the target cubic.
  set gℤ : Polynomial ℤ :=
      C (1 : ℤ) * X ^ 3 + C 0 * X ^ 2 + C 6 * X + C 12 with hgℤ
  -- Step 2.1: Compute the structural data (monicity and degree) of the integer polynomial.
  have hNatDegree : gℤ.natDegree = 3 := by
    -- Step 2.1.1: Apply the dedicated cubic lemma with coefficients (1,0,6,12).
    simpa [hgℤ] using
      (Polynomial.natDegree_cubic (R := ℤ) (a := (1 : ℤ)) (b := 0) (c := 6) (d := 12)
        (by decide : (1 : ℤ) ≠ 0))
  have hMonic : gℤ.Monic := by
    -- Step 2.1.2: Read off the leading coefficient via the cubic helper lemma.
    have hLead :
        gℤ.leadingCoeff = (1 : ℤ) := by
          simpa [hgℤ] using
            (Polynomial.leadingCoeff_cubic (R := ℤ) (a := (1 : ℤ)) (b := 0) (c := 6)
              (d := 12) (by decide : (1 : ℤ) ≠ 0))
    -- Step 2.1.3: Turn the leading-coefficient statement into monicity.
    exact hLead
  -- Step 2.2: Record the explicit coefficients that will be used to verify Eisenstein's hypotheses.
  have hCoeff0 : gℤ.coeff 0 = (12 : ℤ) := by
    -- Step 2.2.1: Simplify the constant term of the cubic.
    simp [hgℤ, coeff_X_pow, coeff_X]
  have hCoeff1 : gℤ.coeff 1 = (6 : ℤ) := by
    -- Step 2.2.2: Simplify the linear coefficient.
    simp [hgℤ, coeff_X_pow, coeff_X]
  have hCoeff2 : gℤ.coeff 2 = (0 : ℤ) := by
    -- Step 2.2.3: Note that the quadratic coefficient vanishes.
    simp [hgℤ, coeff_X_pow, coeff_X]
  -- Step 3: Fix the prime ideal generated by 3, which will be used in Eisenstein's criterion.
  set P : Ideal ℤ := Ideal.span ({(3 : ℤ)} : Set ℤ) with hPDef
  -- Step 3.1: Establish that the ideal is proper and prime.
  have hPneTop : P ≠ ⊤ := by
    -- Step 3.1.1: An ideal generated by a non-unit integer (here, 3) is not the whole ring.
    have h3notUnit : ¬ IsUnit (3 : ℤ) := by decide
    -- Step 3.1.2: Translate the non-unit statement into the ideal-theoretic formulation.
    simpa [P, Ideal.span_singleton_eq_top] using h3notUnit
  have hPPrime : P.IsPrime := by
    -- Step 3.1.3: 3 is a prime number in ℤ, hence the principal ideal it generates is prime.
    have hPrimeInt :
        Prime (3 : ℤ) := by
          have hNat : Nat.Prime 3 := by decide
          have hNatAbs : Nat.Prime (Int.natAbs (3 : ℤ)) := by simpa using hNat
          exact (Int.prime_iff_natAbs_prime).2 hNatAbs
    -- Step 3.1.4: Transfer primality of the element to primality of the ideal.
    simpa [P] using
      (Ideal.span_singleton_prime (by decide : (3 : ℤ) ≠ 0)).2 hPrimeInt
  -- Step 3.2: Verify that every lower-degree coefficient lies in the ideal generated by 3.
  have hMem :
      ∀ ⦃n : ℕ⦄, n < gℤ.natDegree → gℤ.coeff n ∈ P := by
    -- Step 3.2.1: Convert the upper bound on the index into a concrete inequality `n < 3`.
    intro n hn
    have hnlt3 : n < 3 := by simpa [hNatDegree] using hn
    -- Step 3.2.2: Perform a finite case split on the possible values of `n`.
    revert hnlt3
    -- Step 3.2.3: Handle the constant term (n = 0).
    cases n with
    | zero =>
        intro _
        -- Step 3.2.3.1: Show 3 divides the constant coefficient 12.
        have hDiv : (3 : ℤ) ∣ 12 := ⟨4, by decide⟩
        -- Step 3.2.3.2: Convert back to membership in the generating ideal.
        simpa [hCoeff0, P] using Ideal.mem_span_singleton.mpr hDiv
    | succ n =>
        -- Step 3.2.4: Handle the linear term (n = 1).
        cases n with
        | zero =>
            intro _
            -- Step 3.2.4.1: Verify that 3 divides 6.
            have hDiv : (3 : ℤ) ∣ 6 := ⟨2, by decide⟩
            -- Step 3.2.4.2: Pull the divisibility information back to the ideal membership.
            simpa [hCoeff1, P] using Ideal.mem_span_singleton.mpr hDiv
        | succ n =>
            -- Step 3.2.5: Handle the quadratic term (n = 2).
            cases n with
            | zero =>
                intro _
                -- Step 3.2.5.1: The vanishing coefficient obviously belongs to every ideal.
                simp [hCoeff2]
            | succ n =>
                -- Step 3.2.6: Any larger index contradicts the assumption `n < 3`.
                intro hnlt3
                have hge :
                    3 ≤ Nat.succ (Nat.succ (Nat.succ n)) :=
                  Nat.succ_le_succ <|
                    Nat.succ_le_succ <|
                      Nat.succ_le_succ (Nat.zero_le _)
                exact (Nat.not_lt_of_ge hge hnlt3).elim
  -- Step 3.3: Check that the constant coefficient is not in the square of the ideal (i.e., 9 ∤ 12).
  have hCoeff0Not :
      gℤ.coeff 0 ∉ P ^ 2 := by
    -- Step 3.3.1: Observe that 9 does not divide 12.
    have hNoDiv : ¬ ((3 : ℤ) ^ 2 ∣ (12 : ℤ)) := by decide
    -- Step 3.3.2: Rewrite ideal-theoretic membership in terms of this divisibility.
    intro hMemPow
    have hDiv :
        (3 : ℤ) ^ 2 ∣ gℤ.coeff 0 := by
      have :
          gℤ.coeff 0 ∈ Ideal.span ({((3 : ℤ) ^ 2)} : Set ℤ) := by
        simpa [P, pow_two, hCoeff0, Ideal.span_singleton_mul_span_singleton,
          mul_comm, mul_left_comm, mul_assoc] using hMemPow
      exact Ideal.mem_span_singleton.mp this
    simp [hCoeff0] at hDiv
  -- Step 3.4: Confirm that the leading coefficient lies outside the ideal (1 is not divisible by 3).
  have hLeadNotMem :
      gℤ.leadingCoeff ∉ P := by
    -- Step 3.4.1: Establish that 3 does not divide 1.
    have hNoDiv : ¬ (3 : ℤ) ∣ (1 : ℤ) := by decide
    -- Step 3.4.2: Translate the divisibility failure back to the ideal membership condition.
    intro hMem
    have hDiv : (3 : ℤ) ∣ gℤ.leadingCoeff :=
      Ideal.mem_span_singleton.mp hMem
    simp [hMonic.leadingCoeff] at hDiv
  -- Step 4: Assemble the Eisenstein witness using the data collected so far.
  have hEisenstein : gℤ.IsEisensteinAt P := by
    -- Step 4.1: Apply the monic Eisenstein constructor with the membership and non-membership facts.
    exact
      Polynomial.Monic.isEisensteinAt_of_mem_of_notMem (f := gℤ) hMonic hPneTop
        (fun {n} hn => hMem hn) hCoeff0Not
  -- Step 4.2: Record that the polynomial is primitive (a monic integer polynomial is primitive).
  have hPrimitive : gℤ.IsPrimitive := hMonic.isPrimitive
  -- Step 4.3: Eisenstein delivers irreducibility over ℤ together with the degree positivity.
  have hIrredZ :
      Irreducible gℤ :=
    Polynomial.IsEisensteinAt.irreducible hEisenstein hPPrime hPrimitive
      (by -- Step 4.3.1: Convert `natDegree = 3` into the required positivity hypothesis.
        simp [hNatDegree])
  -- Step 5: Transport irreducibility to ℚ via Gauss's lemma.
  have hIrredQ :
      Irreducible (gℤ.map (Int.castRingHom ℚ)) :=
    (Polynomial.IsPrimitive.Int.irreducible_iff_irreducible_map_cast hPrimitive).1 hIrredZ
  -- Step 5.1: Evaluate the map to rewrite it as the original polynomial over ℚ.
  have hMap :
      gℤ.map (Int.castRingHom ℚ) =
        (12 + 6 * X + X ^ 3 : Polynomial ℚ) := by
    -- Step 5.1.1: Simplify the ring homomorphism action coefficient-wise.
    simp [hgℤ, add_comm, add_assoc]
  -- Step 5.2: Conclude irreducibility of the initial polynomial.
  simpa [hMap] using hIrredQ
