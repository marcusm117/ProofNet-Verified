import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Suppose $g$ is a real function on $R^{1}$, with bounded derivative (say $\left|g^{\prime}\right| \leq M$ ). Fix $\varepsilon>0$, and define $f(x)=x+\varepsilon g(x)$. Prove that $f$ is one-to-one if $\varepsilon$ is small enough.
-/

/-Informal Proof

If $0<\varepsilon<\frac{1}{M}$, we certainly have
$$
f^{\prime}(x) \geq 1-\varepsilon M>0,
$$
and this implies that $f(x)$ is one-to-one, by the preceding problem.
-/

theorem Rudin_exercise_5_3 {g : ℝ → ℝ} (hg : Continuous g)
  (hg' : ∃ M : ℝ, ∀ x : ℝ, |deriv g x| ≤ M) :
  ∃ N, ∀ ε > 0, ε < N → Function.Injective (λ x : ℝ => x + ε * g x) := by
  -- Step 1: The statement only asks for *some* threshold `N`, with no positivity
  -- requirement. Choose `N = 0`.
  refine ⟨0, ?_⟩
  -- Step 2: Any `ε` with `0 < ε` and `ε < 0` yields a contradiction, so the
  -- injectivity claim holds vacuously.
  intro ε hε hεN
  exact absurd (lt_trans hε hεN) (lt_irrefl 0)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

theorem Rudin_exercise_5_3_corrected
  {g : ℝ → ℝ} (hgDiff : Differentiable ℝ g)
  (hg' : ∃ M : ℝ, ∀ x : ℝ, |deriv g x| ≤ M) :
  ∃ N > 0, ∀ ε > 0, ε < N → Function.Injective (λ x : ℝ => x + ε * g x) := by
  classical
  -- Step 1: extract a uniform bound `M` on the derivative and note `M ≥ 0`.
  obtain ⟨M, hM⟩ := hg'
  have hM_nonneg : 0 ≤ M := by
    -- Since `|deriv g 0| ≤ M` and absolute values are non‑negative, `M` must be non‑negative.
    have h := hM 0
    have h_abs : 0 ≤ |deriv g 0| := abs_nonneg _
    exact le_trans h_abs h

  -- Step 2: turn the derivative bound into a global Lipschitz bound for `g`.
  have hLip : LipschitzWith ⟨M, hM_nonneg⟩ g := by
    -- Step 2.1: upgrade the real bound to the `ℝ≥0` bound required by the lemma.
    have hBound : ∀ x, ‖deriv g x‖₊ ≤ ⟨M, hM_nonneg⟩ := by
      intro x
      have hreal : ‖deriv g x‖ ≤ M := by
        -- For real numbers `‖·‖ = |·|`.
        simpa [Real.norm_eq_abs] using hM x
      exact_mod_cast hreal
    -- Step 2.2: apply the mean value inequality specialized to one variable.
    exact lipschitzWith_of_nnnorm_deriv_le hgDiff hBound

  -- Step 3: choose a concrete admissible size for `ε`.
  -- We take `N = 1 / (M + 1)` so that `ε < N` implies `ε * M < 1`.
  refine ⟨1 / (M + 1), div_pos one_pos (by linarith), ?_⟩
  intro ε hεpos hεlt
  -- Step 3.1: show the crucial inequality `ε * M < 1`.
  have hεM_lt_one : ε * M < 1 := by
    -- Because `ε < 1/(M+1)` we have `ε*(M+1) < 1`, and `ε*M ≤ ε*(M+1)`.
    have h1 : ε * (M + 1) < 1 := by
      -- since `0 < M+1`, we can multiply the inequality by `(M+1)`
      have hpos : 0 < M + 1 := by linarith
      have hmult : ε * (M + 1) < (1 / (M + 1)) * (M + 1) :=
        mul_lt_mul_of_pos_right hεlt hpos
      have hcancel : (M + 1)⁻¹ * (M + 1) = (1 : ℝ) := by
        have hposne : (M + 1) ≠ 0 := by linarith
        field_simp [hposne]
      simpa [one_div, hcancel] using hmult
    have h2 : ε * M ≤ ε * (M + 1) := by nlinarith
    exact lt_of_le_of_lt h2 h1

  -- Step 4: prove injectivity using the Lipschitz bound.
  intro x y hEq
  -- Step 4.1: rearrange the assumed equality.
  have hDiff : x - y = ε * (g y - g x) := by
    linarith
  -- Step 4.2: take absolute values to prepare for estimates.
  have hAbs : |x - y| = ε * |g y - g x| := by
    have h := congrArg abs hDiff
    have hε : |ε| = ε := abs_of_pos hεpos
    -- `abs (a*b) = |a|*|b|`
    simpa [hε, abs_mul] using h

  -- Step 4.3: bound `|g y - g x|` using Lipschitzness.
  have hLip' : |g y - g x| ≤ M * |y - x| := by
    have h := hLip.dist_le_mul y x
    -- `dist` on `ℝ` is `|·|`; coercion of `ℝ≥0` to `ℝ` is the real value.
    simpa [Real.dist_eq, mul_comm] using h

  -- Step 4.4: combine the two estimates.
  have hAbs_le : |x - y| ≤ ε * (M * |x - y|) := by
    calc
      |x - y| = ε * |g y - g x| := hAbs
      _ ≤ ε * (M * |y - x|) := by
            have : |g y - g x| ≤ M * |y - x| := hLip'
            nlinarith
      _ = ε * (M * |x - y|) := by
        -- `|y - x| = |x - y|`
        have : |y - x| = |x - y| := by simp [abs_sub_comm]
        nlinarith

  -- Step 4.5: deduce `x = y` from the inequality.
  by_cases hxy : x = y
  · exact hxy
  · have hxydist_pos : 0 < |x - y| := abs_pos.mpr (sub_ne_zero.mpr hxy)
    -- Divide the inequality by `|x - y| > 0` to obtain `1 ≤ ε * M`, contradicting `ε*M < 1`.
    have hOne : 1 ≤ ε * M := by
      -- `|x - y| ≤ ε*M*|x - y|` with `|x-y|>0` implies `1 ≤ ε*M`.
      have := hAbs_le
      nlinarith
    have hContr : False := not_le_of_gt hεM_lt_one hOne
    exact (hContr.elim)
