import Mathlib


open Filter Real Function
open scoped Topology
noncomputable section

/-Informal Statement

Give a direct proof that the nested decreasing intersection of nonempty covering compact sets is nonempty.
-/

/-Informal Proof

Let
$$
A_1 \supset A_2 \supset \cdots \supset A_n \supset \cdots
$$
be a nested decreasing sequence of compacts. Suppose that $\bigcap A_n=\emptyset$. Take $U_n=A_n^c$, then
$$
\bigcup U_n=\bigcup A_n^c=\left(\bigcap A_n\right)^c=A_1 .
$$
Here, I'm thinking of $A_1$ as the main metric space. Since $\left\{U_n\right\}$ is an open covering of $A_1$, we can extract a finite subcovering, that is,
$$
A_{\alpha_1}^c \cup A_{\alpha_2}^c \cup \cdots \cup A_{\alpha_m}^c \supset A_1
$$
or
$$
\left(A_1 \backslash A_{\alpha_1}\right) \cup\left(A_1 \backslash A_{\alpha_2}\right) \cup \cdots \cup\left(A_1 \backslash A_{\alpha_m}\right) \supset A_1 .
$$
But, this is true only if $A_{\alpha_i}=\emptyset$ for some $i$, a contradiction.
-/

theorem Pugh_exercise_2_92 {α : Type*} [TopologicalSpace α]
  {s : ℕ → Set α}
  (hs : ∀ i, IsCompact (s i))
  (hs : ∀ i, (s i).Nonempty)
  (hs : ∀ i, (s i) ⊃ (s (i + 1))) :
  (⋂ i, s i).Nonempty := by
  sorry

/-! ## Refutation
The original statement `Pugh_exercise_2_92` is false: `Pugh_exercise_2_92_neg` proves the negation of its elaborated type. -/
theorem Pugh_exercise_2_92_neg : ¬ (type_of% @Pugh_exercise_2_92) := by
  intro h
  -- Step 1: The counterexample space is `ULift ℕ` (to live in an arbitrary universe)
  -- with the indiscrete topology `⊤`, which is not Hausdorff.
  letI : TopologicalSpace (ULift ℕ) := ⊤
  haveI : IndiscreteTopology (ULift ℕ) := ⟨rfl⟩
  -- Step 2: In the indiscrete topology every nonempty set is compact:
  -- all neighbourhood filters are `⊤`, so any `NeBot` filter clusters at every point.
  have hc : ∀ t : Set (ULift ℕ), t.Nonempty → IsCompact t := by
    intro t ⟨x, hx⟩ f hf _
    refine ⟨x, hx, ?_⟩
    show (𝓝 x ⊓ f).NeBot
    rw [IndiscreteTopology.nhds_eq, top_inf_eq]
    exact hf
  -- Step 3: The sets `s i = {x | i ≤ x.down}` are nonempty (`i` belongs to `s i`).
  have hne : ∀ i : ℕ, ({x : ULift ℕ | i ≤ x.down}).Nonempty :=
    fun i => ⟨ULift.up i, le_refl i⟩
  -- Step 4: Apply the (false) statement; we must check strict nesting `s i ⊃ s (i+1)`.
  obtain ⟨x, hx⟩ := h (s := fun i : ℕ => {x : ULift ℕ | i ≤ x.down})
    (fun i => hc _ (hne i)) hne
    (fun i => by
      -- Step 4.1: `s (i+1) ⊆ s i` since `i ≤ i + 1`.
      refine ⟨fun y (hy : i + 1 ≤ y.down) => (show i ≤ y.down by omega), fun hsub => ?_⟩
      -- Step 4.2: `s i ⊄ s (i+1)` because `up i ∈ s i` but `up i ∉ s (i+1)`.
      have := hsub (show ULift.up i ∈ {x : ULift ℕ | i ≤ x.down} from le_refl i)
      simp at this)
  -- Step 5: But the intersection is empty: `x ∉ s (x.down + 1)`.
  have := Set.mem_iInter.mp hx (x.down + 1)
  simp at this

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Real Function Set
open scoped Topology

/-
The informal proof forgets that compact subsets need not be closed when the ambient space is not
Hausdorff. In a non-Hausdorff compact space (for instance the cofinite topology on `ℕ`), one can
produce nested, nonempty, compact sets whose intersection is empty. The failure happens precisely
because compactness alone does not force the finite intersection property for nested families
unless the sets are also closed in a compact space.
-/

namespace Exercise292

open scoped Topology

/-
Corrected statement: in a Hausdorff space (e.g. a metric space), compact subsets are closed, so a
nested sequence of nonempty compact sets has the finite intersection property inside the compact
set `s 0`, forcing the overall intersection to be nonempty.
-/

theorem _root_.Pugh_exercise_2_92_corrected {α : Type*} [TopologicalSpace α] [T2Space α]
    {s : ℕ → Set α}
    (hcomp : ∀ i, IsCompact (s i))
    (hne : ∀ i, (s i).Nonempty)
    (hmono : ∀ i, s i ⊇ s (i + 1)) :
    (⋂ i, s i).Nonempty := by
  -- Step 1: package the monotonicity assumption in the `⊆` direction.
  have hmono' : ∀ i, s (i + 1) ⊆ s i := fun i => hmono i
  -- Step 2: note that compact subsets are closed in a Hausdorff space.
  have hclosed : ∀ i, IsClosed (s i) := fun i => (hcomp i).isClosed
  -- Step 3: appeal to the Cantor intersection theorem for decreasing sequences of compact sets.
  exact
    IsCompact.nonempty_iInter_of_sequence_nonempty_isCompact_isClosed s hmono' hne
      (hcomp 0) hclosed

end Exercise292
