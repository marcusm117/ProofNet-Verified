import Mathlib


open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-Informal Statement

Suppose $f$ is continuous in a region $\Omega$. Prove that any two primitives of $f$ (if they exist) differ by a constant.
-/

/-Informal Proof

Suppose $F_1$ and $F_2$ are primitives of $F$. Then $(F_1-F_2)^\prime = f - f = 0$, therefore $F_1$ and $F_2$ differ by a constant.
-/

theorem Shakarchi_exercise_1_26
  (f F₁ F₂ : ℂ → ℂ) (Ω : Set ℂ) (h1 : IsOpen Ω) (h2 : IsConnected Ω)
  (hF₁ : DifferentiableOn ℂ F₁ Ω) (hF₂ : DifferentiableOn ℂ F₂ Ω)
  (hdF₁ : ∀ x ∈ Ω, deriv F₁ x = f x) (hdF₂ : ∀ x ∈ Ω, deriv F₂ x = f x)
  : ∃ c : ℂ, ∀ x, F₁ x = F₂ x + c := by
  sorry

/-! ## Refutation
The original statement `Shakarchi_exercise_1_26` is false: `Shakarchi_exercise_1_26_neg` proves the negation of its elaborated type. -/
/-! ### Counterexample data

The formal statement's conclusion `∃ c, ∀ x, F₁ x = F₂ x + c` quantifies over **all** of `ℂ`,
while every hypothesis only constrains `F₁`, `F₂` on the region `Ω`.  So the values of the
primitives outside `Ω` are completely unconstrained, and the statement is false.

Take `Ω = Metric.ball 0 1` (open, connected, nonempty), `f = 0`, `F₁ = 0`, and
`F₂ z = if ‖z‖ < 1 then 0 else 1`.  Since `Ω` is open, `F₂` coincides with the zero function on a
whole neighbourhood of each point of `Ω`, hence it is differentiable there with derivative `0 = f`.
But `F₁ 0 = F₂ 0 + c` forces `c = 0`, while at `x = 2 ∉ Ω` the conclusion asserts `0 = 1`. -/

/-- The "bad" primitive: it agrees with `0` on the unit ball but jumps to `1` outside. -/
private noncomputable def badPrim179 : ℂ → ℂ := fun z => if ‖z‖ < 1 then 0 else 1

/-- On the open unit ball, `badPrim179` is *locally* equal to the zero function. -/
private theorem badPrim179_eventuallyEq {x : ℂ} (hx : x ∈ Metric.ball (0 : ℂ) 1) :
    badPrim179 =ᶠ[nhds x] (fun _ => (0 : ℂ)) := by
  -- Step 1: the ball is open, so it is a neighbourhood of each of its points.
  filter_upwards [Metric.isOpen_ball.mem_nhds hx] with y hy
  -- Step 2: for `y` in the ball we have `‖y‖ < 1`, so the `if` takes its first branch.
  have hy' : ‖y‖ < 1 := by simpa [Complex.dist_eq] using hy
  simp [badPrim179, hy']

theorem Shakarchi_exercise_1_26_neg : ¬ (type_of% @Shakarchi_exercise_1_26) := by
  -- Step 1: assume the statement holds for all `f, F₁, F₂, Ω`.
  intro h
  -- Step 2: the region `Ω = Metric.ball 0 1` is open and connected (it is a nonempty convex set).
  have hΩopen : IsOpen (Metric.ball (0 : ℂ) 1) := Metric.isOpen_ball
  have hΩconn : IsConnected (Metric.ball (0 : ℂ) 1) :=
    ⟨⟨0, Metric.mem_ball_self one_pos⟩, (convex_ball (0 : ℂ) 1).isPreconnected⟩
  -- Step 3: `badPrim179` is differentiable on `Ω`, being locally constant there.
  have hdiff : DifferentiableOn ℂ badPrim179 (Metric.ball (0 : ℂ) 1) := by
    intro x hx
    exact ((((badPrim179_eventuallyEq hx).differentiableAt_iff).2
      (differentiableAt_const 0)).differentiableWithinAt)
  -- Step 4: and its derivative on `Ω` is `0`, matching `f = 0`.
  have hderiv : ∀ x ∈ Metric.ball (0 : ℂ) 1, deriv badPrim179 x = 0 := by
    intro x hx
    rw [(badPrim179_eventuallyEq hx).deriv_eq]
    simp
  -- Step 5: specialise the hypothesis to `f = 0`, `F₁ = 0`, `F₂ = badPrim179`, `Ω = ball 0 1`.
  obtain ⟨c, hc⟩ := h 0 (fun _ => 0) badPrim179 (Metric.ball (0 : ℂ) 1) hΩopen hΩconn
    (differentiableOn_const 0) hdiff (by intro x _; simp)
    (by intro x hx; simpa using hderiv x hx)
  -- Step 6: evaluating at `0 ∈ Ω` gives `0 = badPrim179 0 + c = 0 + c`, hence `c = 0`.
  have h0 := hc 0
  -- Step 7: evaluating at `2 ∉ Ω` gives `0 = badPrim179 2 + c = 1 + c`, hence `c = -1`.
  have h2 := hc 2
  simp [badPrim179] at h0 h2
  -- Step 8: `c = 0` and `1 + c = 0` are contradictory.
  rw [← h0] at h2
  norm_num at h2


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Complex Filter Function Metric Finset Set
open scoped BigOperators Topology

namespace Proofnet179

noncomputable section

/-
Corrected version: the same hypotheses only guarantee that F₁ and F₂ differ by a constant on the
region Ω itself (the domain where the primitives are compared). Globally extending Ω can fail, so
the quantifier in the conclusion must be restricted to x ∈ Ω.
-/

theorem _root_.Shakarchi_exercise_1_26_corrected :
    ∀ (f F₁ F₂ : ℂ → ℂ) (Ω : Set ℂ),
      Nonempty Ω → IsOpen Ω → IsConnected Ω →
      ContinuousOn f Ω → DifferentiableOn ℂ F₁ Ω → DifferentiableOn ℂ F₂ Ω →
      (∀ x ∈ Ω, deriv F₁ x = f x) → (∀ x ∈ Ω, deriv F₂ x = f x) →
      ∃ c : ℂ, ∀ x ∈ Ω, F₁ x = F₂ x + c := by
  classical
  -- Step 1: Introduce arbitrary data satisfying the hypotheses.
  intro f F₁ F₂ Ω hΩ_nonempty hΩ_open hΩ_connected hf hF₁ hF₂ hdF₁ hdF₂
  -- Step 2: Convert connectedness into the preconnectedness needed by the library lemma.
  have hΩ_preconnected : IsPreconnected Ω := hΩ_connected.isPreconnected
  -- Step 3: Show that the derivatives of F₁ and F₂ agree pointwise on Ω.
  have hderiv_eq : Ω.EqOn (deriv F₁) (deriv F₂) := by
    intro z hz
    -- Step 3.1: Rewrite both derivatives through the shared integrand f.
    have h₁ := hdF₁ z hz
    have h₂ := hdF₂ z hz
    simp [h₁, h₂]
  -- Step 4: Apply the analytic uniqueness lemma to obtain the desired constant.
  obtain ⟨c, hc⟩ :=
    hΩ_open.exists_eq_add_of_deriv_eq hΩ_preconnected hF₁ hF₂ hderiv_eq
  -- Step 5: Read the equality off as an explicit formula on Ω.
  refine ⟨c, ?_⟩
  intro x hx
  -- Step 5.1: The EqOn statement exactly gives F₁ x = F₂ x + c for each x ∈ Ω.
  simpa using hc hx

end

end Proofnet179
