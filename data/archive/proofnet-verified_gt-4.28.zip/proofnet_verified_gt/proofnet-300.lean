import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

/-Informal Statement

Let $p: X \rightarrow Y$ be a continuous map. Show that if there is a continuous map $f: Y \rightarrow X$ such that $p \circ f$ equals the identity map of $Y$, then $p$ is a quotient map.
-/

/-Informal Proof

Let $1_Y: Y \rightarrow Y$ be the identity map in $Y$. If $U$ is a subset of $Y$ and $p^{-1}(U)$ is open in $X$, then $f^{-1}\left(p^{-1}(U)\right)=1_Y^{-1}(U)=U$ is open in $Y$ by continuity of $f$. Thus $p$ is a quotient map.
-/

theorem Munkres_exercise_22_2a {X Y : Type*} [TopologicalSpace X]
  [TopologicalSpace Y] (p : X → Y) (h : Continuous p) :
  IsQuotientMap p ↔ ∃ (f : Y → X), Continuous f ∧ p ∘ f = id := by
  sorry

/-! ## Counterexample helpers

The formal statement is an `↔`, but only `←` holds (that is the textbook exercise).
The `→` direction says every continuous quotient map has a continuous section, which is false.
Counterexample: glue `(-∞,0] ⊔ [0,∞)` onto `ℝ`. This is a quotient map (a continuous closed
surjection), but a continuous section `ℝ → (-∞,0] ⊔ [0,∞)` would have to land in a single
summand because `ℝ` is connected, so it cannot hit both `1` and `-1`.
Since the negated statement is universe polymorphic, we transport everything along `ULift`. -/

/-- The gluing map `(-∞,0] ⊔ [0,∞) → ℝ`. -/
def glue300 : (Iic (0:ℝ)) ⊕ (Ici (0:ℝ)) → ℝ := Sum.elim Subtype.val Subtype.val

/-- Step 1: the gluing map is continuous (each branch is a subtype inclusion). -/
theorem glue300_continuous : Continuous glue300 :=
  Continuous.sumElim continuous_subtype_val continuous_subtype_val

/-- Step 2: the gluing map is a quotient map. -/
theorem glue300_isQuotientMap : IsQuotientMap glue300 := by
  refine IsClosedMap.isQuotientMap ?_ glue300_continuous ?_
  · -- Step 2.1: closed map, since both inclusions of closed half-lines are closed maps.
    exact IsClosedMap.sumElim isClosed_Iic.isClosedMap_subtype_val
      isClosed_Ici.isClosedMap_subtype_val
  · -- Step 2.2: surjective, since every real is `≤ 0` or `≥ 0`.
    intro y
    rcases le_total y 0 with hy | hy
    · exact ⟨Sum.inl ⟨y, hy⟩, rfl⟩
    · exact ⟨Sum.inr ⟨y, hy⟩, rfl⟩

/-- Step 3: the gluing map has no continuous section. -/
theorem glue300_no_section :
    ¬ ∃ (f : ℝ → (Iic (0:ℝ)) ⊕ (Ici (0:ℝ))), Continuous f ∧ glue300 ∘ f = id := by
  rintro ⟨f, hf, hpf⟩
  -- Step 3.1: `isLeft ∘ f : ℝ → Bool` is continuous, hence constant as `ℝ` is connected.
  have hc : ∀ x y : ℝ, Sum.isLeft (f x) = Sum.isLeft (f y) := fun x y =>
    PreconnectedSpace.constant inferInstance (continuous_isLeft.comp hf)
  -- Step 3.2: the section equations at `1` and `-1`.
  have h1 : glue300 (f 1) = 1 := congrFun hpf 1
  have h2 : glue300 (f (-1)) = -1 := congrFun hpf (-1)
  have h12 := hc 1 (-1)
  -- Step 3.3: case on which summand `f 1` and `f (-1)` land in.
  rcases hA : f 1 with a | a <;> rcases hB : f (-1) with b | b
  · -- Step 3.3.1: both left: `f 1 = inl a` forces `1 = a ≤ 0`.
    rw [hA] at h1
    have := a.2; simp only [mem_Iic] at this
    simp only [glue300, Sum.elim_inl] at h1; linarith
  · -- Step 3.3.2: different summands contradict Step 3.1.
    rw [hA, hB] at h12; simp at h12
  · -- Step 3.3.3: different summands contradict Step 3.1.
    rw [hA, hB] at h12; simp at h12
  · -- Step 3.3.4: both right: `f (-1) = inr b` forces `-1 = b ≥ 0`.
    rw [hB] at h2
    have := b.2; simp only [mem_Ici] at this
    simp only [glue300, Sum.elim_inr] at h2; linarith

/-- The gluing map transported to arbitrary universes via `ULift`. -/
def glueLift300.{u, v} :
    ULift.{u} ((Iic (0:ℝ)) ⊕ (Ici (0:ℝ))) → ULift.{v} ℝ :=
  fun x => ULift.up (glue300 x.down)

/-- Step 4: the lifted gluing map is continuous. -/
theorem glueLift300_continuous.{u, v} : Continuous glueLift300.{u, v} :=
  continuous_uliftUp.comp (glue300_continuous.comp continuous_uliftDown)

/-- Step 5: the lifted gluing map is a quotient map
(homeomorphism ∘ quotient map ∘ homeomorphism). -/
theorem glueLift300_isQuotientMap.{u, v} : IsQuotientMap glueLift300.{u, v} :=
  ((Homeomorph.ulift.{v, 0}).symm.isQuotientMap.comp glue300_isQuotientMap).comp
    (Homeomorph.ulift.{u, 0}).isQuotientMap

/-- Step 6: the lifted gluing map has no continuous section; a section would descend
to a continuous section of `glue300`, contradicting Step 3. -/
theorem glueLift300_no_section.{u, v} :
    ¬ ∃ (f : ULift.{v} ℝ → ULift.{u} ((Iic (0:ℝ)) ⊕ (Ici (0:ℝ)))),
      Continuous f ∧ glueLift300 ∘ f = id := by
  rintro ⟨f, hf, hpf⟩
  -- Step 6.1: the descended section `g = down ∘ f ∘ up`.
  refine glue300_no_section ⟨fun y => (f (ULift.up y)).down,
    continuous_uliftDown.comp (hf.comp continuous_uliftUp), ?_⟩
  -- Step 6.2: it is a section, by applying `down` to the lifted section equation.
  funext y
  have := congrArg ULift.down (congrFun hpf (ULift.up y))
  simpa [glueLift300] using this

/-! ## Refutation
The original statement `Munkres_exercise_22_2a` is false: `Munkres_exercise_22_2a_neg` proves the negation of its elaborated type. -/
theorem Munkres_exercise_22_2a_neg : ¬ (type_of% @Munkres_exercise_22_2a) := by
  -- Step 7: specialise to the lifted gluing map; the `→` direction would give a section.
  intro h
  exact glueLift300_no_section
    ((h glueLift300 glueLift300_continuous).1 glueLift300_isQuotientMap)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace Topology

theorem Munkres_exercise_22_2a_corrected {X Y : Type*} [TopologicalSpace X]
  [TopologicalSpace Y] (p : X → Y) (h : Continuous p) :
  (∃ (f : Y → X), Continuous f ∧ p ∘ f = id) → IsQuotientMap p := by
  -- Step 0: Activate classical logic so we can freely use function extensionality lemmas.
  classical
  -- Step 1: Introduce the existence of a continuous right inverse for `p`.
  intro hf
  -- Step 1.1: Extract the specific map `f` together with its continuity and right-inverse equation.
  rcases hf with ⟨f, hf_cont, hf_comp⟩
  -- Step 1.2: Record the pointwise form `p (f y) = y`, which follows from `p ∘ f = id`.
  have hf_pointwise : ∀ y, p (f y) = y := by
    -- Step 1.2.1: Evaluate the functional equality at an arbitrary point `y`.
    intro y
    -- Step 1.2.2: Simplify the compositions to obtain the desired identity.
    have := congrArg (fun g : Y → Y => g y) hf_comp
    simpa [Function.comp] using this
  -- Step 2: Deduce that `p` is surjective by using the explicit preimage `f y` of each `y`.
  have h_surj : Function.Surjective p := by
    -- Step 2.1: For any `y`, exhibit `f y` as a preimage whose image is `y`.
    intro y
    exact ⟨f y, hf_pointwise y⟩
  -- Step 3: Show that the topology on `Y` coincides with the coinduced topology via `p`.
  have h_eq_coinduced :
      (inferInstance : TopologicalSpace Y) =
        (inferInstance : TopologicalSpace X).coinduced p := by
    -- Step 3.1: Compare open sets on both sides to establish equality of topologies.
    ext s
    constructor
    · -- Step 3.1.1: Use the continuity of `p` to send open sets forward to open preimages.
      intro hs
      -- Step 3.1.2: By definition of `coinduced`, this says `p ⁻¹' s` is open in `X`.
      change IsOpen (p ⁻¹' s)
      exact h.isOpen_preimage (s := s) hs
    · -- Step 3.2.1: Start from an open set in the coinduced topology.
      intro hs
      -- Step 3.2.2: Reinterpret the hypothesis as openness of `p ⁻¹' s` in `X`.
      have hs' : IsOpen (p ⁻¹' s) := by
        simpa using hs
      -- Step 3.2.3: Pull the set back along `f` using its continuity.
      have h_pre := hf_cont.isOpen_preimage (s := p ⁻¹' s) hs'
      -- Step 3.2.4: Identify the pulled-back set with `s` because `p ∘ f = id`.
      have h_preimage : f ⁻¹' (p ⁻¹' s) = s := by
        ext y
        simp [Set.preimage, hf_pointwise]
      -- Step 3.2.5: Rewrite the openness statement via the identified equality.
      simpa [h_preimage] using h_pre
  -- Step 4: Package the surjectivity and topology equality into the `IsQuotientMap` structure.
  exact ⟨h_surj, h_eq_coinduced⟩
