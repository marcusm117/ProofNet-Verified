import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

If $x$ is an element of infinite order in $G$, prove that the elements $x^{n}, n \in \mathbb{Z}$ are all distinct.
-/

/-Informal Proof

Solution: Suppose to the contrary that $x^a=x^b$ for some $0 \leq a<b \leq n-1$. Then we have $x^{b-a}=1$, with $1 \leq b-a<n$. However, recall that $n$ is by definition the least integer $k$ such that $x^k=1$, so we have a contradiction. Thus all the $x^i$, $0 \leq i \leq n-1$, are distinct. In particular, we have
$$
\left\{x^i \mid 0 \leq i \leq n-1\right\} \subseteq G,
$$
so that $|x|=n \leq|G|$
-/

theorem Dummit_Foote_exercise_1_1_34 {G : Type*} [Group G] {x : G}
  (hx_inf : orderOf x = 0) (n m : ℤ) :
  x ^ n ≠ x ^ m := by
  sorry

/-! ### Counterexample data

The formalization quantifies over `n m : ℤ` *independently* and concludes `x ^ n ≠ x ^ m`,
but never assumes `n ≠ m`.  Taking `n = m` makes the conclusion `x ^ n ≠ x ^ n`, which is
false for *every* group element.  So all we need is one group possessing an element of
infinite order (to satisfy the hypothesis `orderOf x = 0`).

We use `x = Multiplicative.ofAdd (1 : ℤ)` inside `Multiplicative ℤ`, transported to an
arbitrary universe via `ULift` (the negated statement is universe-polymorphic, so the group
must live in the ambient universe `u`).
-/

/-- Step 1: the generator of `Multiplicative ℤ` has infinite order (`orderOf = 0`). -/
theorem pn34_orderOf_ofAdd_one : orderOf (Multiplicative.ofAdd (1 : ℤ)) = 0 := by
  -- Step 1.1: `orderOf_eq_zero_iff'` reduces this to: no positive power is the identity.
  rw [orderOf_eq_zero_iff']
  intro n hn h
  -- Step 1.2: in `Multiplicative ℤ`, `(ofAdd 1) ^ n = ofAdd (n • 1) = ofAdd (n : ℤ)`,
  -- so `h` says `(n : ℤ) = 0`, contradicting `0 < n`.
  simp [← ofAdd_nsmul] at h
  omega

/-- Step 2: the same element, lifted into an arbitrary universe `u` through `ULift`,
still has infinite order — `MulEquiv.ulift : ULift α ≃* α` is an isomorphism and
`orderOf` is invariant under isomorphism. -/
theorem pn34_orderOf_up :
    orderOf (ULift.up.{u} (Multiplicative.ofAdd (1 : ℤ))) = 0 := by
  -- Step 2.1: transport along `MulEquiv.ulift`; note
  -- `MulEquiv.ulift (ULift.up a) = a` holds by `rfl`.
  have := MulEquiv.orderOf_eq (MulEquiv.ulift (α := Multiplicative ℤ))
    (ULift.up.{u} (Multiplicative.ofAdd (1 : ℤ)))
  -- Step 2.2: combine with Step 1.
  rw [← this]
  exact pn34_orderOf_ofAdd_one

/-! ## Refutation
The original statement `Dummit_Foote_exercise_1_1_34` is false: `Dummit_Foote_exercise_1_1_34_neg` proves the negation of its elaborated type. -/
theorem Dummit_Foote_exercise_1_1_34_neg : ¬ (type_of% @Dummit_Foote_exercise_1_1_34) := by
  -- Step 3: assume the (false) statement and instantiate it at the counterexample.
  intro h
  -- Step 3.1: `G := ULift (Multiplicative ℤ)`, `x := ULift.up (ofAdd 1)`, whose order is 0.
  -- Step 3.2: take `n = m = 0`; the conclusion becomes `x ^ (0:ℤ) ≠ x ^ (0:ℤ)`,
  -- which `rfl` refutes outright.
  exact h (G := ULift (Multiplicative ℤ))
    (x := ULift.up (Multiplicative.ofAdd (1 : ℤ))) pn34_orderOf_up 0 0 rfl

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_1_1_34_corrected {G : Type*} [Group G] {x : G}
  (hx_inf : orderOf x = 0) (n m : ℤ) (hnm : n ≠ m) :
  x ^ n ≠ x ^ m := by
  -- Step 1: Translate the hypothesis `orderOf x = 0` into the fact that `x` has infinite order.
  have hx_not_fin : ¬IsOfFinOrder x := by
    -- Step 1.1: Use the characterization of infinite order via `orderOf x = 0`.
    exact (orderOf_eq_zero_iff (x := x)).1 hx_inf
  -- Step 2: Deduce that the map `ℤ → G`, `n ↦ x ^ n`, is injective because `x` has infinite order.
  have hx_inj : Function.Injective fun k : ℤ => x ^ k :=
    -- Step 2.1: Apply the injectivity criterion that holds precisely when the element has infinite order.
    (injective_zpow_iff_not_isOfFinOrder (x := x)).2 hx_not_fin
  -- Step 3: Prove the desired inequality by contradiction.
  intro h_eq
  -- Step 3.1: Injectivity forces the exponents to coincide whenever the powers coincide.
  have h_nm : n = m := hx_inj h_eq
  -- Step 3.2: The obtained equality contradicts the initial assumption that `n` and `m` differ.
  exact hnm h_nm
