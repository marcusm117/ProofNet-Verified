import Mathlib


open Fintype Set Real Ideal Polynomial
open scoped BigOperators
noncomputable section

/-Informal Statement

If $G$ is a group and $a, x \in G$, prove that $C\left(x^{-1} a x\right)=x^{-1} C(a) x$
-/

/-Informal Proof

Note that
$$
C(a):=\{x \in G \mid x a=a x\} .
$$
Let us assume $p \in C\left(x^{-1} a x\right)$. Then,
$$
\begin{aligned}
& p\left(x^{-1} a x\right)=\left(x^{-1} a x\right) p \\
\Longrightarrow & \left(p x^{-1} a\right) x=x^{-1}(a x p) \\
\Longrightarrow & x\left(p x^{-1} a\right)=(a x p) x^{-1} \\
\Longrightarrow & \left(x p x^{-1}\right) a=a\left(x p x^{-1}\right) \\
\Longrightarrow & x p x^{-1} \in C(a) .
\end{aligned}
$$
Therefore,
$$
p \in C\left(x^{-1} a x\right) \Longrightarrow x p x^{-1} \in C(a) .
$$
Thus,
$$
C\left(x^{-1} a x\right) \subset x^{-1} C(a) x .
$$
Let us assume
$$
q \in x^{-1} C(a) x .
$$
Then there exists an element $y$ in $C(a)$ such that
$$
q=x^{-1} y x
$$
Now,
$$
y \in C(a) \Longrightarrow y a=a y .
$$
Also,
$$
q\left(x^{-1} a x\right)=\left(x^{-1} y x\right)\left(x^{-1} a x\right)=x^{-1}(y a) x=x^{-1}(y a) x=\left(x^{-1} y x\right)\left(x^{-1} a x\right)=\left(x^{-1} y x\right) q .
$$
Therefore,
$$
q\left(x^{-1} a x\right)=\left(x^{-1} y x\right) q
$$
So,
$$
q \in C\left(x^{-1} a x\right) .
$$
Consequently we have
$$
x^{-1} C(a) x \subset C\left(x^{-1} a x\right) .
$$
It follows from the aforesaid argument
$$
C\left(x^{-1} a x\right)=x^{-1} C(a) x .
$$
This completes the proof.
-/

theorem Herstein_exercise_2_3_17 {G : Type*} [Mul G] [Group G] (a x : G) :
  centralizer {x⁻¹*a*x} =
  (λ g : G => x⁻¹*g*x) '' (centralizer {a}) := by
  sorry

/-!
## Why the formalization is false

The statement carries **two** independent multiplicative structures on `G`: a bare
`[Mul G]` binder and a `[Group G]` binder.  Every occurrence of `*` (inside
`Set.centralizer`, inside `x⁻¹*a*x`, and inside the image map `fun g => x⁻¹*g*x`)
elaborates using the standalone `Mul G` instance, whereas `⁻¹` necessarily uses the
`Group G` instance.  Nothing forces the two to agree, so both the "centralizer" and
the "conjugation" map are computed with a multiplication that has no relation to the
group structure whatsoever.

Concrete counterexample: take the two-element group `Multiplicative (ZMod 2)`
(lifted with `ULift` into the ambient universe), with its standard `Group` instance,
but supply the *constant* `Mul` instance `fun _ _ => 1`.  Then:

* `Set.centralizer S = Set.univ` for every `S`, because `m * z = 1 = z * m` holds
  definitionally.  So the left-hand side is all of `G`.
* The map `fun g => x⁻¹ * g * x` is constantly `1`, so the right-hand side is
  contained in `{1}`.

Since the group has two elements, `Multiplicative.ofAdd 1 ≠ 1`, so the two sides
differ and the statement fails.
-/

/-- The base carrier of the counterexample: the two-element group. -/
abbrev PN74K : Type := Multiplicative (ZMod 2)

/-- A `Mul` structure on `ULift PN74K` totally unrelated to its group structure:
the constant function `1` (where `1` is the group identity from `ULift.group`). -/
def pn74BadMul : Mul (ULift.{v} PN74K) := ⟨fun _ _ => 1⟩

/-- The nontrivial element of `ULift PN74K` is different from the identity. -/
theorem pn74_ne_one :
    (ULift.up.{v} (Multiplicative.ofAdd (1 : ZMod 2))) ≠ (1 : ULift.{v} PN74K) := by
  -- Step 0.1: `ULift.down` of both sides gives `Multiplicative.ofAdd 1 = 1` in `PN74K`.
  intro hEq
  have hbase : (Multiplicative.ofAdd (1 : ZMod 2)) = (1 : PN74K) := congrArg ULift.down hEq
  -- Step 0.2: that is a decidable falsehood in the two-element group.
  exact absurd hbase (by decide)

theorem Herstein_exercise_2_3_17_neg : ¬ (type_of% @Herstein_exercise_2_3_17) := by
  -- Step 1: assume the statement holds for every `G`, every `Mul G` and every `Group G`.
  intro h
  -- Step 2: specialise to `G := ULift (Multiplicative (ZMod 2))` with the bogus `Mul`
  -- instance `pn74BadMul`, the standard `Group` instance, and `a = x = 1`.
  have H := @h (ULift PN74K) pn74BadMul ULift.group 1 1
  -- Step 3: the left-hand side, a centralizer taken w.r.t. `pn74BadMul`, is everything.
  -- Step 3.1: for the constant multiplication, `m * z = 1 = z * m` holds by `rfl`,
  -- so every element centralizes every set; in particular the nontrivial element
  -- `ULift.up (Multiplicative.ofAdd 1)` lies in the left-hand side.
  have hmem : (ULift.up (Multiplicative.ofAdd (1 : ZMod 2))) ∈
      @centralizer (ULift PN74K) (@singleton (ULift PN74K) (Set (ULift PN74K)) _
        (@HMul.hMul _ _ _ (@instHMul _ pn74BadMul)
          (@HMul.hMul _ _ _ (@instHMul _ pn74BadMul)
            (@Inv.inv _ (@ULift.group PN74K _).toInv 1) 1) 1))
        pn74BadMul :=
    fun m _ => rfl
  -- Step 4: rewriting with the assumed equality puts the element in the image of
  -- `fun g => x⁻¹ * g * x`, which for `pn74BadMul` is the constant map `1`.
  rw [H] at hmem
  obtain ⟨g, _, hg⟩ := hmem
  -- Step 5: hence `ULift.up (Multiplicative.ofAdd 1) = 1`, contradicting `pn74_ne_one`.
  exact pn74_ne_one hg.symm

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Set Real Ideal Polynomial
open scoped BigOperators

/--
Corrected version: when the multiplication is the one coming from the group structure (i.e. we
only assume `[Group G]`), the expected equality of centralizers holds. Detailed annotated proof
is given below. -/
theorem Herstein_exercise_2_3_17_corrected {G : Type*} [Group G] (a x : G) :
  centralizer {x⁻¹ * a * x} = (fun g : G => x⁻¹ * g * x) '' (centralizer {a}) := by
  -- Step 1: Use set extensionality to prove equality by mutual inclusion.
  ext g
  constructor
  · -- Step 2: Forward inclusion. Assume `g` centralizes `x⁻¹ * a * x`.
    intro hg
    -- Step 2.1: Define `y = x * g * x⁻¹`; then `g = x⁻¹ * y * x`.
    refine ⟨x * g * x⁻¹, ?_, ?_⟩
    · -- Step 2.1.1: Show `y` commutes with `a`, so `y ∈ centralizer {a}`.
      have hcomm : (x⁻¹ * a * x) * g = g * (x⁻¹ * a * x) := by
        -- Extract commutation from `hg` using the unique element of the singleton.
        have := hg (x⁻¹ * a * x) (by simp)
        simpa using this
      -- Conjugate the equality by multiplying with `x` on the left and `x⁻¹` on the right.
      have hcomm' : a * (x * g * x⁻¹) = (x * g * x⁻¹) * a := by
        calc
          a * (x * g * x⁻¹)
              = x * ((x⁻¹ * a * x) * g) * x⁻¹ := by simp [mul_assoc]
          _ = x * (g * (x⁻¹ * a * x)) * x⁻¹ := by
                simpa using congrArg (fun z => x * z * x⁻¹) hcomm
          _ = (x * g * x⁻¹) * a := by simp [mul_assoc]
      -- Package the commutation into the centralizer predicate.
      intro b hb
      have hb' : b = a := by simpa using hb
      subst hb'
      simpa using hcomm'
    · -- Step 2.2: Verify `x⁻¹ * y * x = g` for `y = x * g * x⁻¹`.
      simp [mul_assoc]
  · -- Step 3: Reverse inclusion. Start with `g` in the image, write `g = x⁻¹ * y * x`.
    intro hg
    rcases hg with ⟨y, hy, rfl⟩
    -- Step 3.1: From `y ∈ centralizer {a}` get `a * y = y * a`.
    have hya : a * y = y * a := by
      have := hy a (by simp)
      simpa using this
    -- Step 3.2: Show `x⁻¹ * y * x` commutes with `x⁻¹ * a * x`.
    intro b hb
    have hb' : b = x⁻¹ * a * x := by simpa using hb
    subst hb'
    calc
      (x⁻¹ * a * x) * (x⁻¹ * y * x)
          = x⁻¹ * a * x * x⁻¹ * y * x := by simp [mul_assoc]
      _ = x⁻¹ * a * y * x := by simp [mul_assoc]
      _ = x⁻¹ * y * a * x := by simp [hya, mul_assoc]
      _ = x⁻¹ * y * x * x⁻¹ * a * x := by simp [mul_assoc]
      _ = (x⁻¹ * y * x) * (x⁻¹ * a * x) := by simp [mul_assoc]
