import Mathlib

open Filter Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators


/-Informal Statement

Suppose $V$ is a real vector space and $T \in \mathcal{L}(V)$ has no eigenvalues. Prove that every subspace of $V$ invariant under $T$ has even dimension.
-/

/-Informal Proof

First off, let us assume that $U$ is a subspace of $V$ that is invariant under $T$. Therefore, $\left.T\right|_U \in \mathcal{L}(U)$. If $\operatorname{dim}$ $U$ were odd, then $\left.T\right|_U$ would have an eigenvalue $\lambda \in \mathbb{R}$, so there would exist a nonzero vector $u \in U$ such that
$$
\left.T\right|_U u=\lambda u .
$$
So, this would imply that $T_u=\lambda u$, which would imply that $\lambda$ is an eigenvalue of $T$. But $T$ has no eigenvalues, so $\operatorname{dim} U$ must be even.
-/

theorem Axler_exercise_5_24 {V : Type*} [AddCommGroup V]
  [Module ℝ V] [FiniteDimensional ℝ V] {T : End ℝ V}
  (hT : ∀ c : ℝ, eigenspace T c = ⊥) {U : Submodule ℝ V}
  (hU : Submodule.map T U = U) : Even (finrank U) := by
  sorry

/-!
## Why the formal statement is refutable

`Module.finrank` takes **two** explicit type arguments, `(R M : Type*)`.  The conclusion
`Even (finrank U)` supplies only the ring argument, so `finrank ↥U` is not a natural number but
the *function*

  `(M : Type u_2) → [Semiring ↥U] → [AddCommMonoid M] → [Module ↥U M] → ℕ`

and `Even` is taken in that Pi type via the pointwise `Pi.instAdd`.  So the conclusion asserts
that for **every** type `M`, **every** semiring structure on the carrier `↥U`, and every module
structure, the number `finrank ↥U M` is even — a far stronger (and false) claim than "`U` has
even real dimension".

To refute it we exhibit one point of that Pi where the value is `1`:

* `V := ULift ℂ` (a real vector space with no real eigenvalues for multiplication by `i`),
* `T := ` multiplication by `i`, `U := ⊤`, so `hT` and `hU` hold;
* on the carrier `↥(⊤ : Submodule ℝ (ULift ℂ))`, which is in bijection with `ℂ`, we install the
  field structure transported from `ℂ`;
* we evaluate the Pi at `M := ULift ℂ` (in the second universe) with the module structure
  transported along that same bijection, where the module is free of rank `1`.

`Even 1` is false, so the statement is refuted.
-/

/-- Step 0.  Two elements of `ULift α` agree as soon as their `down`s do.
(`ULift.up x.down` is definitionally `x` by structure eta, so `congrArg` suffices.) -/
lemma ulift_eq205 {α : Type*} {x y : ULift.{u} α} (h : x.down = y.down) : x = y :=
  congrArg ULift.up h

/-- Step 1.  Multiplication by `i` on `ULift ℂ`, as an `ℝ`-linear endomorphism.
We build it by conjugating `LinearMap.mulLeft ℝ Complex.I` with `ULift.moduleEquiv`, so that no
linearity obligation has to be discharged by hand. -/
noncomputable def T205 : Module.End ℝ (ULift.{u} ℂ) :=
  (ULift.moduleEquiv (R := ℝ) (M := ℂ)).symm.toLinearMap ∘ₗ
    (LinearMap.mulLeft ℝ Complex.I) ∘ₗ (ULift.moduleEquiv (R := ℝ) (M := ℂ)).toLinearMap

/-- Step 1.1.  The conjugation really is `z ↦ i * z`, on the nose. -/
lemma T205_apply (z : ULift.{u} ℂ) : T205 z = ULift.up (Complex.I * z.down) := rfl

/-- Step 2.  `T205` has no real eigenvalue: `i * z = c * z` with `c` real forces `z = 0`,
since `i ≠ c` for every real `c` (compare imaginary parts). -/
lemma T205_eigenspace (c : ℝ) : Module.End.eigenspace (T205.{u}) c = ⊥ := by
  rw [eq_bot_iff]
  intro x hx
  -- Step 2.1.  Membership in the `c`-eigenspace means `T205 x = c • x`.
  rw [Module.End.mem_eigenspace_iff] at hx
  -- Step 2.2.  Read that equation off in `ℂ`, turning the real `•` into multiplication by `↑c`.
  have hd : Complex.I * x.down = (c : ℂ) * x.down := by
    have h := congrArg ULift.down hx
    simpa [T205_apply, Complex.real_smul] using h
  -- Step 2.3.  Hence `(i - c) * x.down = 0`.
  have h0 : (Complex.I - (c : ℂ)) * x.down = 0 := by
    rw [sub_mul, hd, sub_self]
  rcases mul_eq_zero.mp h0 with h | h
  · -- Step 2.4.  The first factor cannot vanish: `i.im = 1` but `(↑c).im = 0`.
    exfalso
    have hI : Complex.I = (c : ℂ) := by linear_combination h
    have := congrArg Complex.im hI
    simp at this
  · -- Step 2.5.  So `x.down = 0`, i.e. `x = 0`, i.e. `x ∈ ⊥`.
    rw [Submodule.mem_bot]
    exact ulift_eq205 (by simpa using h)

/-- Step 3.  `T205` maps `⊤` onto `⊤`: it is surjective, with `w = T205 (-i * w)`. -/
lemma T205_map_top : Submodule.map (T205.{u}) ⊤ = ⊤ := by
  rw [Submodule.map_top, LinearMap.range_eq_top]
  intro w
  refine ⟨ULift.up (-Complex.I * w.down), ulift_eq205 ?_⟩
  -- Step 3.1.  `i * (-i * w) = -(i * i) * w = w`.
  rw [T205_apply, ← mul_assoc, mul_neg, Complex.I_mul_I, neg_neg, one_mul]

/-- Step 4.  The key refutation lemma.  If a type `A` is in bijection with `ℂ` and a type `B`
(in an arbitrary second universe) is too, then the Pi-valued `finrank A` is **not** even: at the
point `M := B`, equipped with the structures transported from `A`, its value is `1`. -/
lemma finrank_pi_not_even205 {A : Type u} {B : Type v} (eA : A ≃ ℂ) (eB : B ≃ ℂ) :
    ¬ Even (Module.finrank A :
      (M : Type v) → [Semiring A] → [AddCommMonoid M] → [Module A M] → ℕ) := by
  intro hEven
  -- Step 4.1.  Pointwise evenness gives a function `r` with `finrank A = r + r`.
  obtain ⟨r, hr⟩ := hEven
  -- Step 4.2.  Transport `ℂ`'s field structure onto `A` along `eA`.
  letI FA : Field A := eA.field
  -- Step 4.3.  `B` is in bijection with `A`; transport the `A`-module structure of `A` onto `B`.
  letI e : B ≃ A := eB.trans eA.symm
  letI ACB : AddCommMonoid B := Equiv.addCommMonoid e
  letI ModB : Module A B := Equiv.module A e
  -- Step 4.4.  For those structures `e` is an `A`-linear equivalence `B ≃ₗ[A] A`,
  -- so `B` has `A`-dimension `finrank A A = 1`.
  have hone : Module.finrank A B = 1 := by
    have h1 : Module.finrank A A = 1 := CommSemiring.finrank_self A
    have h2 : Module.finrank A B = Module.finrank A A :=
      (Equiv.linearEquiv A e).finrank_eq
    exact h2.trans h1
  -- Step 4.5.  Evaluate the functional identity `finrank A = r + r` at this point.
  have h2 := congrFun (congrFun (congrFun (congrFun hr B) (inferInstance : Semiring A)) ACB) ModB
  simp only [Pi.add_apply] at h2
  -- Step 4.6.  That says `1 = r ... + r ...`, which is absurd.
  rw [hone] at h2
  omega

/-! ## Negation of the original statement
`type_of% @Axler_exercise_5_24` is literally the elaborated type of the original theorem, so this
is its exact negation (with the Pi-valued conclusion `Even (Module.finrank ↥U)`). -/
theorem Axler_exercise_5_24_neg : ¬ (type_of% @Axler_exercise_5_24) := by
  intro h
  -- Step 5.  Instantiate: `V := ULift ℂ`, `T := T205`, `U := ⊤`.  Both hypotheses hold.
  have hEven := @h (ULift ℂ) _ _ _ T205 T205_eigenspace ⊤ T205_map_top
  -- Step 6.  The carrier `↥(⊤ : Submodule ℝ (ULift ℂ))` is in bijection with `ℂ`
  -- (via `Submodule.topEquiv` then `Equiv.ulift`), and so is `ULift ℂ` in the second
  -- universe.  Step 4 then contradicts `hEven`.
  exact finrank_pi_not_even205
    ((Submodule.topEquiv (R := ℝ) (M := ULift ℂ)).toEquiv.trans Equiv.ulift)
    Equiv.ulift hEven

/-! ## Corrected statement and its proof -/

/-- Step A.  Auxiliary form of "an odd-degree real polynomial has a real root", under the extra
assumption that the leading coefficient is nonnegative.

The proof is the intermediate value theorem: `P` tends to `+∞` at `+∞`, and (because the degree is
odd) to `-∞` at `-∞`, so it takes a nonnegative and a nonpositive value. -/
lemma exists_root_of_odd_natDegree_aux205 {P : Polynomial ℝ} (hodd : Odd P.natDegree)
    (hlc : 0 ≤ P.leadingCoeff) : ∃ x : ℝ, P.eval x = 0 := by
  -- Step A.1.  An odd natural degree is positive, hence `0 < P.degree`.
  have hdeg : 0 < P.degree := Polynomial.natDegree_pos_iff_degree_pos.mp hodd.pos
  -- Step A.2.  Since the leading coefficient is `≥ 0`, `P` tends to `+∞` along `atTop`;
  -- in particular it takes some nonnegative value `P.eval b`.
  obtain ⟨b, hb⟩ :=
    ((P.tendsto_atTop_of_leadingCoeff_nonneg hdeg hlc).eventually_ge_atTop 0).exists
  -- Step A.3.  Look at `Q := P(-X)`, which has the same degree and leading coefficient
  -- `(-1) ^ natDegree * leadingCoeff = - leadingCoeff ≤ 0`.
  have hQdeg : 0 < (P.comp (-Polynomial.X)).degree := by
    rwa [Polynomial.degree_comp_neg_X]
  have hQlc : (P.comp (-Polynomial.X)).leadingCoeff ≤ 0 := by
    rw [Polynomial.comp_neg_X_leadingCoeff_eq, hodd.neg_one_pow]
    linarith
  -- Step A.4.  Hence `Q` tends to `-∞` along `atTop`, so it takes some nonpositive value
  -- `Q.eval c = P.eval (-c)`.
  obtain ⟨c, hc⟩ :=
    (((P.comp (-Polynomial.X)).tendsto_atBot_of_leadingCoeff_nonpos hQdeg
      hQlc).eventually_le_atBot 0).exists
  have ha : P.eval (-c) ≤ 0 := by simpa [Polynomial.eval_comp] using hc
  -- Step A.5.  `P.eval` is continuous, and `0` lies between `P.eval (-c) ≤ 0` and `0 ≤ P.eval b`,
  -- so the intermediate value theorem produces a root.
  have hcont : ContinuousOn (fun x : ℝ => P.eval x) (Set.uIcc (-c) b) :=
    P.continuous.continuousOn
  have h0 : (0 : ℝ) ∈ Set.uIcc (P.eval (-c)) (P.eval b) := Set.mem_uIcc.mpr (Or.inl ⟨ha, hb⟩)
  obtain ⟨x, -, hx⟩ := intermediate_value_uIcc hcont h0
  exact ⟨x, hx⟩

/-- Step B.  Every real polynomial of odd degree has a real root.  The case of a negative leading
coefficient follows from Step A applied to `-P`, which has the same roots. -/
lemma exists_root_of_odd_natDegree205 {P : Polynomial ℝ} (hodd : Odd P.natDegree) :
    ∃ x : ℝ, P.eval x = 0 := by
  rcases le_total 0 P.leadingCoeff with h | h
  · exact exists_root_of_odd_natDegree_aux205 hodd h
  · obtain ⟨x, hx⟩ :=
      exists_root_of_odd_natDegree_aux205 (P := -P) (by simpa using hodd) (by simpa using h)
    exact ⟨x, by simpa using hx⟩

/-- Step C.  An endomorphism of a nonzero-dimensional **real** vector space whose dimension is odd
has an eigenvalue: its characteristic polynomial has degree `finrank ℝ W`, which is odd, hence has
a real root, and the roots of the characteristic polynomial are exactly the eigenvalues. -/
lemma exists_eigenvalue_of_odd_finrank205 {W : Type*} [AddCommGroup W] [Module ℝ W]
    [FiniteDimensional ℝ W] (f : Module.End ℝ W) (hodd : Odd (Module.finrank ℝ W)) :
    ∃ c : ℝ, Module.End.eigenspace f c ≠ ⊥ := by
  -- Step C.1.  `natDegree (charpoly f) = finrank ℝ W` is odd, so `charpoly f` has a real root `c`.
  have hdeg : (LinearMap.charpoly f).natDegree = Module.finrank ℝ W := f.charpoly_natDegree
  obtain ⟨c, hc⟩ := exists_root_of_odd_natDegree205 (P := LinearMap.charpoly f) (by rwa [hdeg])
  -- Step C.2.  A root of the characteristic polynomial is an eigenvalue.
  refine ⟨c, ?_⟩
  have : f.HasEigenvalue c := (Module.End.hasEigenvalue_iff_isRoot_charpoly f c).mpr hc
  exact Module.End.hasEigenvalue_iff.mp this



theorem Axler_exercise_5_24_corrected {V : Type*} [AddCommGroup V]
  [Module ℝ V] [FiniteDimensional ℝ V] {T : End ℝ V}
  (hT : ∀ c : ℝ, eigenspace T c = ⊥) {U : Submodule ℝ V}
  (hU : Submodule.map T U ≤ U) : Even (finrank ℝ U) := by
  -- Step 1.  Suppose, for contradiction, that `dim U` is odd.
  by_contra hnot
  rw [Nat.not_even_iff_odd] at hnot
  -- Step 2.  Invariance: `T` maps `U` into `U`, so `T` restricts to `T' ∈ End ℝ U`.
  have hmap : ∀ x ∈ U, T x ∈ U := fun _ hx => hU (Submodule.mem_map_of_mem hx)
  -- Step 3.  As `dim U` is odd, `T'` has a real eigenvalue `c` (Step C).
  obtain ⟨c, hc⟩ := exists_eigenvalue_of_odd_finrank205 (T.restrict hmap) hnot
  -- Step 3.1.  Extract a nonzero eigenvector `u : U` for `T'` with eigenvalue `c`.
  obtain ⟨u, hu, hu0⟩ := (Submodule.ne_bot_iff _).mp hc
  rw [Module.End.mem_eigenspace_iff] at hu
  -- Step 4.  Push the eigenvector down to `V`: `T u = c • u` in `V`, and `u ≠ 0` there too.
  have hV : T (u : V) = c • (u : V) := congrArg Subtype.val hu
  have hV0 : (u : V) ≠ 0 := fun h => hu0 (Subtype.ext h)
  -- Step 5.  So `c` is an eigenvalue of `T`, contradicting `hT c : eigenspace T c = ⊥`.
  have : (u : V) ∈ Module.End.eigenspace T c := Module.End.mem_eigenspace_iff.mpr hV
  rw [hT c, Submodule.mem_bot] at this
  exact hV0 this

/- Diagnosis:

The mathematics of the original formalization was right; the defect is purely a Lean
encoding mistake in the conclusion.

`Module.finrank` has signature `Module.finrank (R M : Type*) [Semiring R] [AddCommMonoid M]
[Module R M] : ℕ`, i.e. it takes TWO explicit type arguments.  The original conclusion

    Even (finrank U)

supplies only ONE argument, and — because `↥U` is a type — that argument is silently taken as
the RING argument `R := ↥U`, not as the module argument.  So `finrank ↥U` is not a natural
number at all: it is the partially applied function

    (M : Type _) → [Semiring ↥U] → [AddCommMonoid M] → [Module ↥U M] → ℕ

and `Even` is then interpreted in that Pi type via the pointwise `Pi.instAdd`.  The conclusion
therefore claims that for EVERY type `M`, EVERY semiring structure on the carrier `↥U` and
EVERY module structure, the number `finrank ↥U M` is even.  That is a strictly stronger — and
false — statement: `Axler_exercise_5_24_neg` above refutes it by taking `V := ULift ℂ`, `T :=`
multiplication by `i` (which has no real eigenvalue) and `U := ⊤`, transporting `ℂ`'s field
structure onto the carrier `↥(⊤ : Submodule ℝ (ULift ℂ))` and evaluating the Pi at a rank-one
module, where the value is `1`.  Note that the counterexample does NOT violate the informal
statement: there `U = V` has real dimension `2`, which is even.  Only the mis-elaborated
formal conclusion fails.

The fix is to give `finrank` its intended ring argument, `Even (finrank ℝ U)`, which is the
faithful rendering of "`U` has even dimension" (dimension over the base field `ℝ`).  The
hypotheses `[FiniteDimensional ℝ V]` (Axler's standing convention that `V` is finite-dimensional)
and `hT : ∀ c : ℝ, eigenspace T c = ⊥` ("`T` has no eigenvalues") are kept unchanged.
The corrected hypothesis `hU : Submodule.map T U ≤ U` directly expresses "`U` is invariant
under `T`"; under the other hypotheses `T` is injective, so it is equivalent here to the
original equality `map T U = U`.
-/
