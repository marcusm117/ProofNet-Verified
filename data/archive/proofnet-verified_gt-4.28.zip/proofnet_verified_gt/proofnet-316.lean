import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

abbrev I : Set ℝ := Icc 0 1

/-Informal Statement

Show that every locally compact Hausdorff space is completely regular.
-/

/-Informal Proof

$X$ is a subspace of a compact Hausdorff space $Y$, its one-point compactification. $Y$ is normal, and so by the Urysohn lemma $Y$ is completely regular. Therefore by corollary $X$ is completely regular.
-/

theorem Munkres_exercise_33_7 {X : Type*} [TopologicalSpace X]
  (hX : LocallyCompactSpace X) (hX' : T2Space X) :
  ∀ x A, IsClosed A ∧ ¬ x ∈ A →
  ∃ (f : X → I), Continuous f ∧ f x = 1 ∧ f '' A = {0} := by
  sorry

/-! ## Refutation
The original statement `Munkres_exercise_33_7` is false: `Munkres_exercise_33_7_neg` proves the negation of its elaborated type. -/
theorem Munkres_exercise_33_7_neg : ¬ (type_of% @Munkres_exercise_33_7) := by
  -- Step 1: assume the (universe-polymorphic) statement.
  intro h
  -- Step 2: specialise to the one-point space `PUnit` (in whatever universe the statement
  -- lives in), which is locally compact and Hausdorff, with `x = PUnit.unit` and `A = ∅`.
  -- `A = ∅` is closed and trivially does not contain `x`.
  obtain ⟨f, -, -, hf⟩ :=
    h (X := PUnit) inferInstance inferInstance PUnit.unit ∅ ⟨isClosed_empty, by simp⟩
  -- Step 3: the image of the empty set is empty, but the conclusion demands it equals `{0}`.
  rw [Set.image_empty] at hf
  -- Step 4: `∅ = {0}` is absurd since singletons are nonempty.
  exact (Set.singleton_ne_empty _) hf.symm

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace
open scoped Topology

theorem Munkres_exercise_33_7_corrected {X : Type*} [TopologicalSpace X]
  (hX : LocallyCompactSpace X) (hX' : T2Space X) :
  CompletelyRegularSpace X := by
  classical
  -- Step 1: Register that the one-point compactification inherits complete regularity.
  -- Step 1.1: A locally compact Hausdorff space yields a normal, hence completely regular,
  --           one-point compactification via existing Mathlib instances.
  have hOnePoint : CompletelyRegularSpace (OnePoint X) := by
    infer_instance
  -- Step 2: Record that the canonical inclusion `X → OnePoint X` is inducing.
  -- Step 2.1: This follows from the fact that the inclusion is an open embedding.
  have hInducing : Topology.IsInducing ((↑) : X → OnePoint X) := by
    simpa using OnePoint.isOpenEmbedding_coe.isInducing
  -- Step 3: Transport complete regularity along the inducing map.
  -- Step 3.1: Applying the general lemma for inducing maps finishes the job.
  haveI := hOnePoint
  exact hInducing.completelyRegularSpace
