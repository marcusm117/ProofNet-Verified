import Mathlib


open Complex Filter Function Metric Finset
open scoped BigOperators Topology

/-Informal Statement

Prove that the power series $\sum zn/n^2$ converges at every point of the unit circle.
-/

/-Informal Proof

Since $\left|z^n / n^2\right|=1 / n^2$ for all $|z|=1$, then $\sum z^n / n^2$ converges at every point in the unit circle as $\sum 1 / n^2$ does ( $p$-series $p=2$.)
-/

theorem Shakarchi_exercise_1_19b (z : ℂ) (hz : norm z = 1) (s : ℕ → ℂ)
    (h : s = (λ n => ∑ i ∈ (range n), i * z / i ^ 2)) :
    ∃ y, Tendsto s atTop (𝓝 y) := by
  sorry

/-! ## Helper: the formalized sum diverges for every `z` on the unit circle.

The formalization mistranscribes the summand. The informal problem is the power
series `∑ zⁿ / n²`, but the Lean statement sums `(i : ℂ) * z / (i : ℂ) ^ 2`,
which for `i ≠ 0` equals `z / i` and for `i = 0` equals `0`. Hence the partial
sums are `(∑ i ∈ range n, 1/i) * z`, i.e. `z` times the *harmonic* partial sums,
which diverge — not a convergent `p`-series with `p = 2`. -/
private theorem harmonic_partial_sums_diverge_178
    (z : ℂ) (hz : norm z = 1) (s : ℕ → ℂ)
    (h : s = (fun n => ∑ i ∈ (range n), i * z / i ^ 2)) :
    ¬ ∃ y, Tendsto s atTop (𝓝 y) := by
  -- Step 1: suppose the partial sums converged to some `y : ℂ`.
  rintro ⟨y, hy⟩
  -- Step 1.1: then their norms converge to `‖y‖` (the norm is continuous).
  have hnorm : Tendsto (fun n => ‖s n‖) atTop (𝓝 ‖y‖) := hy.norm
  -- Step 2: compute `‖s n‖` explicitly as the `n`-th harmonic partial sum.
  have key : ∀ n, ‖s n‖ = ∑ i ∈ range n, (1 / (i : ℝ)) := by
    intro n
    -- Step 2.1: rewrite `s n` as `(∑ i ∈ range n, 1/i : ℝ) * z`.
    have hrew : s n = ((∑ i ∈ range n, (1 / (i : ℝ)) : ℝ) : ℂ) * z := by
      rw [h]
      push_cast
      rw [Finset.sum_mul]
      refine Finset.sum_congr rfl ?_
      intro i _
      -- Step 2.2: termwise, `i * z / i ^ 2 = (1 / i) * z`, including the `i = 0`
      -- case where both sides are `0` (division by zero is `0` in Lean).
      rcases eq_or_ne (i : ℂ) 0 with h0 | h0
      · simp [h0]
      · field_simp
    -- Step 2.3: `‖z‖ = 1`, and the real harmonic partial sum is nonnegative.
    rw [hrew, norm_mul, hz, mul_one, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (by positivity)]
  -- Step 3: the harmonic partial sums tend to `atTop`, since `∑ 1/n` is not
  -- summable and its terms are nonnegative.
  have hdiv : Tendsto (fun n : ℕ => ∑ i ∈ range n, (1 / (i : ℝ))) atTop atTop := by
    rw [← not_summable_iff_tendsto_nat_atTop_of_nonneg (fun i => by positivity)]
    exact Real.not_summable_one_div_natCast
  -- Step 4: hence `‖s n‖ → ∞`, contradicting `‖s n‖ → ‖y‖`.
  have hstop : Tendsto (fun n => ‖s n‖) atTop atTop := by
    simpa only [key] using hdiv
  exact not_tendsto_nhds_of_tendsto_atTop hstop _ hnorm

/-! ## Refutation
The original statement `Shakarchi_exercise_1_19b` is false: `Shakarchi_exercise_1_19b_neg` proves the negation of its elaborated type. -/
theorem Shakarchi_exercise_1_19b_neg : ¬ (type_of% @Shakarchi_exercise_1_19b) := by
  -- Step 1: assume the (universally quantified) statement holds.
  intro H
  -- Step 2: instantiate it at the concrete counterexample `z = 1` (which lies on
  -- the unit circle) and `s` the partial sums prescribed by the hypothesis.
  have hz : norm (1 : ℂ) = 1 := norm_one
  have hcontra := H 1 hz (fun n => ∑ i ∈ (range n), i * (1 : ℂ) / i ^ 2) rfl
  -- Step 3: but those partial sums are the harmonic partial sums, which diverge.
  exact harmonic_partial_sums_diverge_178 1 hz _ rfl hcontra


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Complex Filter Function Metric Finset
open scoped BigOperators Topology

theorem Shakarchi_exercise_1_19b_corrected (z : ℂ) (hz : ‖z‖ = 1) (s : ℕ → ℂ)
    (h : s = (λ n => ∑ i ∈ (range n), z ^ (i + 1) / (i + 1) ^ 2)) :
    ∃ y, Tendsto s atTop (𝓝 y) := by
  -- Step 1: Introduce the function `f` capturing the summand of our series.
  classical
  set f : ℕ → ℂ := fun n => z ^ (n + 1) / (n + 1 : ℂ) ^ 2 with hfdef
  -- Step 2: Describe the norm of each summand explicitly using the hypothesis ‖z‖ = 1.
  have h_norm :
      (fun n : ℕ => ‖f n‖) =
        fun n : ℕ => (1 : ℝ) / (n + 1 : ℝ) ^ 2 := by
    -- Step 2.1: Expand `f` and simplify via `‖z‖ = 1`.
    funext n
    -- Step 2.2: Use explicit computations for the numerator and denominator norms.
    have hzpow : ‖z ^ (n + 1)‖ = 1 := by
      simp [hz, Complex.norm_pow z (n + 1)]
    -- Step 2.3: Identify the norm of the denominator `(n + 1 : ℂ)^2`.
    have hdenpow :
        ‖(n + 1 : ℂ) ^ 2‖ = (n + 1 : ℝ) ^ 2 := by
      have hden : ‖(n + 1 : ℂ)‖ = (n + 1 : ℝ) := by
        simpa [Nat.cast_add, Nat.cast_one] using (Complex.norm_natCast (n + 1))
      simp [pow_two, hden]
    -- Step 2.4: Combine the two calculations to obtain the desired equality.
    calc
      ‖f n‖ = ‖z ^ (n + 1)‖ / ‖(n + 1 : ℂ) ^ 2‖ := by
        simp [f]
      _ = 1 / ‖(n + 1 : ℂ) ^ 2‖ := by
        simp [hzpow]
      _ = (1 : ℝ) / (n + 1 : ℝ) ^ 2 := by
        simp [hdenpow]
  -- Step 3: Apply the classical p-series summability lemma to the norm sequence.
  have h_pSeries :
      Summable fun n : ℕ => (1 : ℝ) / (n + 1 : ℝ) ^ 2 := by
    -- Step 3.1: Produce the classical `p`-series with exponent `p = 2`.
    have h_base :
        Summable fun n : ℕ => (1 : ℝ) / (n : ℝ) ^ 2 :=
      (Real.summable_one_div_nat_pow (p := 2)).mpr one_lt_two
    -- Step 3.2: Shift the index by one to match the exact numerator in `f`.
    simpa [Nat.cast_add, Nat.cast_one] using (summable_nat_add_iff 1).2 h_base
  -- Step 3.3: Transfer summability across the function equality `h_norm`.
  have h_norm_summable :
      Summable fun n : ℕ => ‖f n‖ := by
    simpa [h_norm] using h_pSeries
  -- Step 4: Absolute convergence yields convergence of the complex series itself.
  have hfSummable : Summable f :=
    Summable.of_norm h_norm_summable
  -- Step 5: Extract the limit supplied by `HasSum` for the partial sums of `f`.
  refine ⟨∑' n, f n, ?_⟩
  have hy : HasSum f (∑' n, f n) := hfSummable.hasSum
  -- Step 6: Rewrite the target sequence `s` in terms of the partial sums of `f`.
  -- Step 6.1: Use the supplied equality `h` alongside `hy`.
  -- Step 6.2: Conclude by the convergence of partial sums furnished by `HasSum`.
  simpa [h, f] using hy.tendsto_sum_nat
