import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

/-Informal Statement

Show that if $X$ is an infinite set, it is connected in the finite complement topology.
-/

/-Informal Proof

Suppose that $A$ is a non-empty subset of $X$ that is both open and closed, i.e., $A$ and $X \backslash A$ are finite or all of $X$. Since $A$ is non-empty, $X \backslash A$ is finite. Thus $A$ cannot be finite as $X \backslash A$ is infinite, so $A$ is all of $X$. Therefore $X$ is connected.
-/

theorem Munkres_exercise_23_4 {X : Type*}
  (s : Set (CofiniteTopology X)) : Infinite s → IsConnected s := by
  -- Step 1: turn the `Infinite ↥s` hypothesis into `s.Infinite` (i.e. `¬ s.Finite`).
  intro hinf
  have hsinf : s.Infinite := Set.infinite_coe_iff.mp hinf
  -- Step 2: `IsConnected s` splits into nonemptiness and preconnectedness.
  -- An infinite set is in particular nonempty.
  refine ⟨hsinf.nonempty, ?_⟩
  -- Step 3: unfold preconnectedness: given opens `u`, `v` covering `s` and meeting `s`,
  -- we must show `u ∩ v` also meets `s`.
  rintro u v hu hv - ⟨a, has, hau⟩ ⟨b, hbs, hbv⟩
  -- Step 3.1: `u` meets `s`, hence `u` is nonempty, hence (by definition of the cofinite
  -- topology) its complement is finite.  Likewise for `v`.
  have hucf : uᶜ.Finite := CofiniteTopology.isOpen_iff.mp hu ⟨a, hau⟩
  have hvcf : vᶜ.Finite := CofiniteTopology.isOpen_iff.mp hv ⟨b, hbv⟩
  -- Step 4: suppose, for contradiction, that `s ∩ (u ∩ v)` is empty.
  by_contra hcon
  -- Step 4.1: then every point of `s` misses `u` or misses `v`, i.e. `s ⊆ uᶜ ∪ vᶜ`.
  have hsub : s ⊆ uᶜ ∪ vᶜ := by
    intro x hx
    by_contra hxc
    simp only [Set.mem_union, Set.mem_compl_iff, not_or, not_not] at hxc
    exact hcon ⟨x, hx, hxc.1, hxc.2⟩
  -- Step 4.2: `uᶜ ∪ vᶜ` is a union of two finite sets, hence finite, so `s` would be
  -- finite — contradicting Step 1.
  exact hsinf ((hucf.union hvcf).subset hsub)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace
open scoped Topology

set_option checkBinderAnnotations false

/-
Problems with the original formalization:

1. `[CofiniteTopology X]` does not mean “the existing topology on `X` is
   the cofinite topology”. `CofiniteTopology X` is a type synonym for `X`
   equipped with the cofinite topology. So the original statement still has an
   arbitrary `[TopologicalSpace X]`.

2. The exercise says that the whole infinite space `X` is connected in the
   finite-complement topology. The original statement instead says that every
   infinite subset `s : Set X` is connected.

3. Therefore the original statement is not a faithful formalization of the
   textbook claim.

The corrected statement is faithful because it puts the cofinite topology on
`X` by changing the ambient type to `CofiniteTopology X`, and then proves that
the whole space `Set.univ` is connected.
-/

theorem Munkres_exercise_23_4_corrected {X : Type*} [Infinite X] :
    IsConnected (Set.univ : Set (CofiniteTopology X)) := by
  classical
  -- Step 1: Transfer the `Infinite` instance to the type synonym `CofiniteTopology X`.
  haveI : Infinite (CofiniteTopology X) := ‹Infinite X›
  -- Step 1.1: The universe of an infinite type is infinite, hence nonempty.
  have hs : (Set.univ : Set (CofiniteTopology X)).Infinite := Set.infinite_univ
  have hne : (Set.univ : Set (CofiniteTopology X)).Nonempty := hs.nonempty
  -- Step 2: Reduce the goal to preconnectedness.
  refine ⟨hne, ?_⟩
  -- Step 3: Unfold the definition of `IsPreconnected`.
  intro u v hu hv _hcover hsu hsv
  -- Step 3.1: Each open set meeting the universe has finite complement in the cofinite topology.
  have hu_nonempty : u.Nonempty := by
    rcases hsu with ⟨x, hx⟩
    exact ⟨x, hx.2⟩
  have hv_nonempty : v.Nonempty := by
    rcases hsv with ⟨x, hx⟩
    exact ⟨x, hx.2⟩
  have hu_fin : uᶜ.Finite :=
    (CofiniteTopology.isOpen_iff (X := X) (s := u)).1 hu hu_nonempty
  have hv_fin : vᶜ.Finite :=
    (CofiniteTopology.isOpen_iff (X := X) (s := v)).1 hv hv_nonempty
  -- Step 3.2: Suppose the triple intersection were empty and derive a contradiction.
  by_contra h_empty
  -- Step 3.2.1: Then every point of the universe must miss at least one of `u` or `v`.
  have h_subset : (Set.univ : Set (CofiniteTopology X)) ⊆ uᶜ ∪ vᶜ := by
    intro x hx
    by_cases hxu : x ∈ u
    · by_cases hxv : x ∈ v
      · exact (h_empty ⟨x, hx, hxu, hxv⟩).elim
      · exact Or.inr hxv
    · exact Or.inl hxu
  -- Step 3.2.2: The complement union is finite, contradicting infinitude of the universe.
  have h_fin_union : (uᶜ ∪ vᶜ).Finite := hu_fin.union hv_fin
  have h_univ_fin : (Set.univ : Set (CofiniteTopology X)).Finite := h_fin_union.subset h_subset
  exact hs h_univ_fin
