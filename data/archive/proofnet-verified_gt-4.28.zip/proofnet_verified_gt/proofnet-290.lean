import Mathlib


open Filter Set TopologicalSpace
open Topology
noncomputable section

def is_topology (X : Type*) (T : Set (Set X)) :=
  univ ∈ T ∧
  (∀ s t, s ∈ T → t ∈ T → s ∩ t ∈ T) ∧
  (∀s, (∀t ∈ s, t ∈ T) → sUnion s ∈ T)

/-Informal Statement

If $\mathcal{T}_\alpha$ is a family of topologies on $X$, show that $\bigcup \mathcal{T}_\alpha$ does not need to be a topology on $X$.
-/

/-Informal Proof

On the other hand, the union $\bigcup_\alpha \mathcal{T}_\alpha$ is in general not a topology on $X$. For instance, let $X=\{a, b, c\}$. Then $\mathcal{T}_1=\{\emptyset, X,\{a\}\}$ and $\mathcal{T}_2=\{\emptyset, X,\{b\}\}$ are topologies on $X$ but $\mathcal{T}_1 \cup \mathcal{T}_2=$ $\{\emptyset, X,\{a\},\{b\}\}$ is not.
-/

theorem Munkres_exercise_13_4a2 :
  ∃ (X I : Type*) (T : I → Set (Set X)),
  (∀ i, is_topology X (T i)) ∧ ¬  is_topology X (⋂ i : I, T i) := by
  sorry

/-! ### Helper: an arbitrary intersection of topologies is a topology.

The informal exercise concerns the **union** of a family of topologies, which
indeed need not be a topology.  The formalization instead uses the
**intersection** `⋂ i : I, T i`, and an arbitrary intersection of topologies is
always a topology (for the empty index type `I` the intersection is all of
`Set (Set X)`, which trivially satisfies the three clauses).  Hence the
formal statement is false. -/
theorem iInter_is_topology {X : Type*} {I : Type*} (T : I → Set (Set X))
    (hT : ∀ i, is_topology X (T i)) : is_topology X (⋂ i : I, T i) := by
  refine ⟨?_, ?_, ?_⟩
  -- Step 1: `univ` lies in every `T i`, hence in the intersection.
  · exact mem_iInter.2 fun i => (hT i).1
  -- Step 2: closure under binary intersections, checked index by index.
  · intro s t hs ht
    refine mem_iInter.2 fun i => (hT i).2.1 s t ?_ ?_
    -- Step 2.1: `s ∈ ⋂ i, T i` gives `s ∈ T i`.
    · exact mem_iInter.1 hs i
    -- Step 2.2: likewise for `t`.
    · exact mem_iInter.1 ht i
  -- Step 3: closure under arbitrary unions, again checked index by index.
  · intro s hs
    refine mem_iInter.2 fun i => (hT i).2.2 s ?_
    -- Step 3.1: every member `t` of the family `s` lies in `T i`.
    intro t ht
    exact mem_iInter.1 (hs t ht) i

/-! ## Refutation
The original statement `Munkres_exercise_13_4a2` is false: `Munkres_exercise_13_4a2_neg` proves the negation of its elaborated type. -/
theorem Munkres_exercise_13_4a2_neg : ¬ (type_of% @Munkres_exercise_13_4a2) := by
  -- Step 1: assume such a family `T` of topologies on `X` exists whose
  -- intersection fails to be a topology.
  rintro ⟨X, I, T, hT, hneg⟩
  -- Step 2: but the intersection *is* a topology, contradicting `hneg`.
  exact hneg (iInter_is_topology T hT)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Filter Set TopologicalSpace
open scoped Topology

def is_topology_c (X : Type*) (T : Set (Set X)) :=
  univ ∈ T ∧
  (∀ s t, s ∈ T → t ∈ T → s ∩ t ∈ T) ∧
  (∀ s, (∀ t ∈ s, t ∈ T) → sUnion s ∈ T)

-- Universe-polymorphic version using ULift
-- We lift Fin 3 and Bool to arbitrary universes
universe u v

private def my_T_lifted : ULift.{v} Bool → Set (Set (ULift.{u} (Fin 3))) := fun ⟨b⟩ =>
  if b then {∅, Set.univ, {⟨1⟩}} else {∅, Set.univ, {⟨0⟩}}

private lemma my_T_lifted_is_topology (i : ULift.{v} Bool) :
    is_topology_c (ULift.{u} (Fin 3)) (my_T_lifted i) := by
  obtain ⟨i⟩ := i
  unfold is_topology_c my_T_lifted
  constructor
  -- univ ∈ T(i)
  · cases i <;> simp [Set.mem_insert_iff]
  constructor
  -- intersection closure
  · intro s t hs ht
    cases i
    · simp only [Bool.false_eq_true, ↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff] at hs ht ⊢
      rcases hs with rfl | rfl | rfl <;> rcases ht with rfl | rfl | rfl <;>
        simp only [Set.inter_self, Set.univ_inter, Set.inter_univ, Set.inter_empty,
          Set.empty_inter, true_or, or_true]
    · simp only [↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff] at hs ht ⊢
      rcases hs with rfl | rfl | rfl <;> rcases ht with rfl | rfl | rfl <;>
        simp only [Set.inter_self, Set.univ_inter, Set.inter_univ, Set.inter_empty,
          Set.empty_inter, true_or, or_true]
  -- sUnion closure
  · intro S hS
    cases i
    -- Case i = false: T(false) = {∅, univ, {⟨0⟩}}
    · simp only [Bool.false_eq_true, ↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff] at hS ⊢
      by_cases huniv : Set.univ ∈ S
      · right; left
        ext x
        simp only [Set.mem_sUnion, Set.mem_univ, iff_true]
        exact ⟨Set.univ, huniv, Set.mem_univ x⟩
      · by_cases h0 : ({⟨0⟩} : Set (ULift (Fin 3))) ∈ S
        · right; right
          ext x
          simp only [Set.mem_sUnion, Set.mem_singleton_iff]
          constructor
          · intro ⟨t, htS, hxt⟩
            have ht_mem := hS t htS
            rcases ht_mem with rfl | rfl | rfl
            · exact (Set.notMem_empty x hxt).elim
            · exact (huniv htS).elim
            · exact hxt
          · intro hx
            exact ⟨{⟨0⟩}, h0, hx⟩
        · left
          ext x
          constructor
          · intro ⟨t, htS, hxt⟩
            have ht_mem := hS t htS
            rcases ht_mem with rfl | rfl | rfl
            · exact hxt
            · exact (huniv htS).elim
            · exact (h0 htS).elim
          · intro h
            exact h.elim
    -- Case i = true: T(true) = {∅, univ, {⟨1⟩}}
    · simp only [↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff] at hS ⊢
      by_cases huniv : Set.univ ∈ S
      · right; left
        ext x
        simp only [Set.mem_sUnion, Set.mem_univ, iff_true]
        exact ⟨Set.univ, huniv, Set.mem_univ x⟩
      · by_cases h1 : ({⟨1⟩} : Set (ULift (Fin 3))) ∈ S
        · right; right
          ext x
          simp only [Set.mem_sUnion, Set.mem_singleton_iff]
          constructor
          · intro ⟨t, htS, hxt⟩
            have ht_mem := hS t htS
            rcases ht_mem with rfl | rfl | rfl
            · exact (Set.notMem_empty x hxt).elim
            · exact (huniv htS).elim
            · exact hxt
          · intro hx
            exact ⟨{⟨1⟩}, h1, hx⟩
        · left
          ext x
          constructor
          · intro ⟨t, htS, hxt⟩
            have ht_mem := hS t htS
            rcases ht_mem with rfl | rfl | rfl
            · exact hxt
            · exact (huniv htS).elim
            · exact (h1 htS).elim
          · intro h
            exact h.elim

private lemma my_T_lifted_union_not_topology :
    ¬ is_topology_c (ULift.{u} (Fin 3)) (⋃ i : ULift.{v} Bool, my_T_lifted i) := by
  intro h_is_top
  unfold is_topology_c at h_is_top
  obtain ⟨_, _, h_union⟩ := h_is_top

  let S : Set (Set (ULift (Fin 3))) := {{⟨0⟩}, {⟨1⟩}}

  have hS : ∀ t ∈ S, t ∈ ⋃ i : ULift Bool, my_T_lifted i := by
    intro t ht
    simp only [S, Set.mem_insert_iff, Set.mem_singleton_iff] at ht
    rcases ht with rfl | rfl
    · simp only [Set.mem_iUnion, my_T_lifted]
      use ⟨false⟩
      simp only [Bool.false_eq_true, ↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff, or_true]
    · simp only [Set.mem_iUnion, my_T_lifted]
      use ⟨true⟩
      simp only [↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff, or_true]

  have h_sUnion_in : ⋃₀ S ∈ ⋃ i : ULift Bool, my_T_lifted i := h_union S hS

  have h_sUnion_eq : ⋃₀ S = ({⟨0⟩, ⟨1⟩} : Set (ULift (Fin 3))) := by
    ext x
    simp only [S, Set.mem_sUnion, Set.mem_insert_iff, Set.mem_singleton_iff]
    constructor
    · intro ⟨t, ht, hxt⟩
      rcases ht with rfl | rfl
      · left; exact hxt
      · right; exact hxt
    · intro hx
      rcases hx with hx | hx
      · exact ⟨{⟨0⟩}, Or.inl rfl, hx⟩
      · exact ⟨{⟨1⟩}, Or.inr rfl, hx⟩

  rw [h_sUnion_eq] at h_sUnion_in

  simp only [Set.mem_iUnion, my_T_lifted] at h_sUnion_in
  obtain ⟨⟨i⟩, hi⟩ := h_sUnion_in

  cases i
  · simp only [Bool.false_eq_true, ↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff] at hi
    rcases hi with h_eq | h_eq | h_eq
    · have h0_in : (⟨0⟩ : ULift (Fin 3)) ∈ ({⟨0⟩, ⟨1⟩} : Set (ULift (Fin 3))) := by
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff, true_or]
      rw [h_eq] at h0_in
      exact h0_in
    · have h2_not_in : (⟨2⟩ : ULift (Fin 3)) ∉ ({⟨0⟩, ⟨1⟩} : Set (ULift (Fin 3))) := by
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff, ULift.ext_iff, Fin.reduceEq, or_self,
          not_false_eq_true]
      rw [h_eq] at h2_not_in
      exact h2_not_in (Set.mem_univ (⟨2⟩ : ULift (Fin 3)))
    · have h1_in : (⟨1⟩ : ULift (Fin 3)) ∈ ({⟨0⟩, ⟨1⟩} : Set (ULift (Fin 3))) := by
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff, or_true]
      rw [h_eq] at h1_in
      simp only [Set.mem_singleton_iff, ULift.ext_iff, Fin.reduceEq] at h1_in
  · simp only [↓reduceIte, Set.mem_insert_iff, Set.mem_singleton_iff] at hi
    rcases hi with h_eq | h_eq | h_eq
    · have h0_in : (⟨0⟩ : ULift (Fin 3)) ∈ ({⟨0⟩, ⟨1⟩} : Set (ULift (Fin 3))) := by
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff, true_or]
      rw [h_eq] at h0_in
      exact h0_in
    · have h2_not_in : (⟨2⟩ : ULift (Fin 3)) ∉ ({⟨0⟩, ⟨1⟩} : Set (ULift (Fin 3))) := by
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff, ULift.ext_iff, Fin.reduceEq, or_self,
          not_false_eq_true]
      rw [h_eq] at h2_not_in
      exact h2_not_in (Set.mem_univ (⟨2⟩ : ULift (Fin 3)))
    · have h0_in : (⟨0⟩ : ULift (Fin 3)) ∈ ({⟨0⟩, ⟨1⟩} : Set (ULift (Fin 3))) := by
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff, true_or]
      rw [h_eq] at h0_in
      simp only [Set.mem_singleton_iff, ULift.ext_iff, Fin.reduceEq] at h0_in

theorem Munkres_exercise_13_4a2_corrected :
  ∃ (X I : Type*) (T : I → Set (Set X)),
  (∀ i, is_topology_c X (T i)) ∧ ¬  is_topology_c X (⋃ i : I, T i) :=
  ⟨ULift (Fin 3), ULift Bool, my_T_lifted, my_T_lifted_is_topology, my_T_lifted_union_not_topology⟩
