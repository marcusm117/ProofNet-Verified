import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $x$ and $y$ be elements of $G$. Prove that $xy=yx$ if and only if $y^{-1}xy=x$ if and only if $x^{-1}y^{-1}xy=1$.
-/

/-Informal Proof

If $x y=y x$, then $y^{-1} x y=y^{-1} y x=1 x=x$. Multiplying by $x^{-1}$ then gives $x^{-1} y^{-1} x y=1$.

On the other hand, if $x^{-1} y^{-1} x y=1$, then we may multiply on the left by $x$ to get $y^{-1} x y=x$. Then multiplying on the left by $y$ gives $x y=y x$ as desired.
-/

theorem Dummit_Foote_exercise_1_1_18 {G : Type*} [Group G]
  (x y : G) : (x * y = y * x ↔ y⁻¹ * x * y = x) ↔ (x⁻¹ * y⁻¹ * x * y = 1) := by
  sorry

/-! ## Refutation
The original statement `Dummit_Foote_exercise_1_1_18` is false: `Dummit_Foote_exercise_1_1_18_neg` proves the negation of its elaborated type. -/

/-!
### Why the formalization is false

The informal exercise is a *three-way chain* of equivalences,
`A ↔ B`, `B ↔ C`, with
`A : x * y = y * x`, `B : y⁻¹ * x * y = x`, `C : x⁻¹ * y⁻¹ * x * y = 1`.
The formalization instead nests them as `(A ↔ B) ↔ C`.  But `A ↔ B` holds
unconditionally in every group, so `A ↔ B` is (equivalent to) `True` and the
whole statement collapses to `C` alone: it asserts that the commutator of any
two elements of any group is trivial, i.e. that every group is abelian.

So any non-commuting pair of elements refutes it.  We use the two
transpositions `(0 1)` and `(0 2)` in `Equiv.Perm (Fin 3) ≅ S₃`.  Since the
negated statement quantifies over `G : Type u_1` for a *fixed universe
variable* `u_1`, we cannot use `Equiv.Perm (Fin 3) : Type` directly; we lift it
with `ULift`, whose group structure is defined so that `ULift.down` commutes
with `*`, `⁻¹` and `1` definitionally (`ULift.mul_down`, `ULift.inv_down`,
`ULift.one_down` are all `rfl`).
-/
theorem Dummit_Foote_exercise_1_1_18_neg : ¬ (type_of% @Dummit_Foote_exercise_1_1_18) := by
  -- Step 1: assume the (universally quantified) statement.
  intro h
  -- Step 2: instantiate it at the counterexample
  --   G = ULift (Equiv.Perm (Fin 3)),  x = (0 1),  y = (0 2).
  have hiff := h (G := ULift (Equiv.Perm (Fin 3)))
      (ULift.up (Equiv.swap 0 1)) (ULift.up (Equiv.swap 0 2))
  -- Step 3: establish the left-hand side `A ↔ B` of the outer iff.
  -- For this particular pair both `A` and `B` are false, so the iff holds
  -- vacuously; we prove each direction by refuting its hypothesis.
  have hAB : (ULift.up (Equiv.swap (0:Fin 3) 1) * ULift.up (Equiv.swap (0:Fin 3) 2)
        = ULift.up (Equiv.swap (0:Fin 3) 2) * ULift.up (Equiv.swap (0:Fin 3) 1))
      ↔ ((ULift.up (Equiv.swap (0:Fin 3) 2))⁻¹ * ULift.up (Equiv.swap (0:Fin 3) 1)
          * ULift.up (Equiv.swap (0:Fin 3) 2) = ULift.up (Equiv.swap (0:Fin 3) 1)) := by
    constructor
    · -- Step 3.1: `A` is false: the two transpositions do not commute.
      intro hh
      -- Push the assumed equality down to `Equiv.Perm (Fin 3)`; the ULift
      -- group operations are definitionally the underlying ones.
      have hd : Equiv.swap (0:Fin 3) 1 * Equiv.swap (0:Fin 3) 2
              = Equiv.swap (0:Fin 3) 2 * Equiv.swap (0:Fin 3) 1 := congrArg ULift.down hh
      exact absurd hd (by decide)
    · -- Step 3.2: `B` is false: conjugating `(0 1)` by `(0 2)` gives `(1 2) ≠ (0 1)`.
      intro hh
      have hd : (Equiv.swap (0:Fin 3) 2)⁻¹ * Equiv.swap (0:Fin 3) 1 * Equiv.swap (0:Fin 3) 2
              = Equiv.swap (0:Fin 3) 1 := congrArg ULift.down hh
      exact absurd hd (by decide)
  -- Step 4: feeding `A ↔ B` into the outer equivalence yields `C`, i.e. the
  -- commutator of the two transpositions is trivial.
  have hC := hiff.mp hAB
  -- Step 5: push `C` down to `Equiv.Perm (Fin 3)` and refute it by computation:
  -- the commutator of `(0 1)` and `(0 2)` is the 3-cycle `(0 2 1) ≠ 1`.
  have hd : (Equiv.swap (0:Fin 3) 1)⁻¹ * (Equiv.swap (0:Fin 3) 2)⁻¹
          * Equiv.swap (0:Fin 3) 1 * Equiv.swap (0:Fin 3) 2 = 1 := congrArg ULift.down hC
  exact absurd hd (by decide)

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_1_1_18_corrected {G : Type*} [Group G]
  (x y : G) : (x * y = y * x ↔ y⁻¹ * x * y = x) ∧ (y⁻¹ * x * y = x ↔ x⁻¹ * y⁻¹ * x * y = 1) := by
  -- Step 1: Break the overall target into the conjunction of two equivalences.
  constructor
  · -- Step 1.1: Show `x * y = y * x` if and only if `y⁻¹ * x * y = x`.
    constructor
    · -- Step 1.1.1: Assume the commutativity relation and derive the conjugation equality.
      intro h_comm
      -- Step 1.1.1.1: Multiply both sides of the commutativity equation on the left by `y⁻¹`.
      have h_helper := congrArg (fun z => y⁻¹ * z) h_comm
      -- Step 1.1.1.2: Simplify to obtain `y⁻¹ * x * y = x`.
      simpa [mul_assoc] using h_helper
    · -- Step 1.1.2: Assume the conjugation equality and conclude commutativity.
      intro h_conj
      -- Step 1.1.2.1: Multiply both sides of the given equality on the left by `y`.
      have h_helper := congrArg (fun z => y * z) h_conj
      -- Step 1.1.2.2: Simplify to reach `x * y = y * x`.
      simpa [mul_assoc] using h_helper
  · -- Step 2: Show `y⁻¹ * x * y = x` if and only if `x⁻¹ * y⁻¹ * x * y = 1`.
    constructor
    · -- Step 2.1: Assume the conjugation equality and obtain the identity after multiplying by `x⁻¹`.
      intro h_conj
      -- Step 2.1.1: Multiply both sides on the left by `x⁻¹`.
      have h_helper := congrArg (fun z => x⁻¹ * z) h_conj
      -- Step 2.1.2: Simplify to deduce `x⁻¹ * y⁻¹ * x * y = 1`.
      simpa [mul_assoc] using h_helper
    · -- Step 2.2: Assume the identity statement and recover the conjugation equality.
      intro h_id
      -- Step 2.2.1: Multiply both sides on the left by `x`.
      have h_helper := congrArg (fun z => x * z) h_id
      -- Step 2.2.2: Simplify to conclude `y⁻¹ * x * y = x`.
      simpa [mul_assoc] using h_helper
