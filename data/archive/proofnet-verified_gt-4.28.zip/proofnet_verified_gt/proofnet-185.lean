import Mathlib


open Function Fintype Subgroup Ideal Polynomial Submodule Zsqrtd
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that the center of the product of two groups is the product of their centers.
-/

/-Informal Proof

We have that $(g_1, g_2)\cdot (h_1, h_2) = (h_1, h_2)\cdot (g_1, g_2)$ if and only if $g_1h_1 = h_1g_1$ and $g_2h_2 = h_2g_2$.
-/

/-- Step 1: As subgroups of `G × H`, the center of the product is literally the
product subgroup `(center G).prod (center H)`.

Step 1.1: Two subgroups are equal as soon as their underlying carrier sets agree,
so it suffices to check the statement at the level of `Set`s (`SetLike.coe_injective`).

Step 1.2: Unfolding the coercions turns the goal into
`Set.center (G × H) = Set.center G ×ˢ Set.center H`, which is `Set.center_prod`.
Concretely: `(g₁, g₂)` commutes with every `(h₁, h₂)` iff `g₁h₁ = h₁g₁` for all `h₁`
and `g₂h₂ = h₂g₂` for all `h₂`, since multiplication in a product is componentwise. -/
theorem Artin_exercise_2_8_6_center_eq {G H : Type*} [Group G] [Group H] :
    center (G × H) = (center G).prod (center H) :=
  SetLike.coe_injective <| by
    rw [Subgroup.coe_center, Subgroup.coe_prod, Subgroup.coe_center, Subgroup.coe_center]
    exact Set.center_prod

/-- Step 2: Assemble the isomorphism.

Step 2.1: `MulEquiv.subgroupCongr` upgrades the subgroup equality of Step 1 to a
multiplicative isomorphism `center (G × H) ≃* (center G).prod (center H)`.

Step 2.2: `Subgroup.prodEquiv` identifies the product subgroup with the product of
the two subgroups as groups: `(center G).prod (center H) ≃* center G × center H`.

Step 2.3: Composing the two with `MulEquiv.trans` gives the desired isomorphism. -/
instance Artin_exercise_2_8_6 {G H : Type*} [Group G] [Group H] :
  center (G × H) ≃* (center G) × (center H) := by
  exact (MulEquiv.subgroupCongr Artin_exercise_2_8_6_center_eq).trans
    (Subgroup.prodEquiv (center G) (center H))

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Function Fintype Subgroup Ideal Polynomial Submodule Zsqrtd
open scoped BigOperators

/-
## Faithfulness Issue

The original formalization above uses:

    Nonempty (center (G × H) ≃* (center G) × (center H))

This asserts only the existence of *some* abstract group isomorphism between
`center (G × H)` and `(center G) × (center H)`. However, the informal statement
says "the center of the product **is** the product of their centers," which is a
subgroup equality — not merely an abstract isomorphism.

The distinction matters: two subgroups of `G × H` can be abstractly isomorphic as
groups without being the same subgroup (the `MulEquiv` need not respect the
embeddings into `G × H`). So the Lean statement is strictly weaker than the
informal claim.

## Corrected Formalization

The faithful formalization uses `Subgroup.prod` to express the product of
subgroups as a subgroup of `G × H`, then asserts equality:

    Subgroup.center (G × H) = (Subgroup.center G).prod (Subgroup.center H)

This is exactly what Mathlib's `Set.center_prod` states at the set level.
-/

theorem Artin_exercise_2_8_6_corrected {G H : Type*} [Group G] [Group H] :
    Subgroup.center (G × H) = (Subgroup.center G).prod (Subgroup.center H) := by
  -- Step 1: reduce subgroup equality to pointwise membership equivalence via extensionality.
  ext ⟨g, h⟩
  -- Step 1.1: simplify both sides using the definitions of `mem_center_iff`, `mem_prod`,
  -- `Prod.forall`, and `Prod.ext_iff` so the goal becomes:
  -- `(∀ a b, g * a = a * g ∧ h * b = b * h) ↔ (∀ a, g * a = a * g) ∧ (∀ b, h * b = b * h)`
  simp [Subgroup.mem_center_iff, Subgroup.mem_prod, Prod.forall, Prod.ext_iff]
  -- Step 2: prove the biconditional by splitting into forward and backward directions.
  constructor
  -- Step 2.1 (forward): assume `(g, h)` is central in `G × H`, i.e.,
  -- `∀ a b, g * a = a * g ∧ h * b = b * h`. Show `g` is central in `G` and `h` is central in `H`.
  · intro hx
    -- Step 2.1.1: for centrality of `g`, specialize at `(a, 1)` and take the first component.
    -- Step 2.1.2: for centrality of `h`, specialize at `(1, b)` and take the second component.
    exact ⟨fun a => (hx a 1).1, fun b => (hx 1 b).2⟩
  -- Step 2.2 (backward): assume `g` is central in `G` and `h` is central in `H`.
  -- Show `(g, h)` commutes with every `(a, b)` in `G × H` componentwise.
  · intro ⟨hg, hh⟩ a b
    -- Step 2.2.1: the first component `g * a = a * g` follows from `hg a`.
    -- Step 2.2.2: the second component `h * b = b * h` follows from `hh b`.
    exact ⟨hg a, hh b⟩
