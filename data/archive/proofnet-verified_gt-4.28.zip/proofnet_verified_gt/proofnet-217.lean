import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that $A \times B$ is an abelian group if and only if both $A$ and $B$ are abelian.
-/

/-Informal Proof

$(\Rightarrow)$ Suppose $a_1, a_2 \in A$ and $b_1, b_2 \in B$. Then
$$
\left(a_1 a_2, b_1 b_2\right)=\left(a_1, b_1\right) \cdot\left(a_2, b_2\right)=\left(a_2, b_2\right) \cdot\left(a_1, b_1\right)=\left(a_2 a_1, b_2 b_1\right) .
$$
Since two pairs are equal precisely when their corresponding entries are equal, we have $a_1 a_2=a_2 a_1$ and $b_1 b_2=b_2 b_1$. Hence $A$ and $B$ are abelian.
$(\Leftarrow)$ Suppose $\left(a_1, b_1\right),\left(a_2, b_2\right) \in A \times B$. Then we have
$$
\left(a_1, b_1\right) \cdot\left(a_2, b_2\right)=\left(a_1 a_2, b_1 b_2\right)=\left(a_2 a_1, b_2 b_1\right)=\left(a_2, b_2\right) \cdot\left(a_1, b_1\right) .
$$
Hence $A \times B$ is abelian.
-/

theorem Dummit_Foote_exercise_1_1_29 {A B : Type*} [Group A] [Group B] :
  ∀ x y : A × B, x*y = y*x ↔ (∀ x y : A, x*y = y*x) ∧
  (∀ x y : B, x*y = y*x) := by
  sorry

/-- Helper: the symmetric group on three letters is not commutative.
We exhibit the two transpositions `(0 1)` and `(0 2)`, whose products in the two
orders disagree at the point `0`. -/
theorem perm3_not_comm_217 :
    ¬ (∀ x y : Equiv.Perm (Fin 3), x * y = y * x) := by
  intro hcomm
  -- Step 0.1: specialise the assumed commutativity to the two transpositions.
  have h : (Equiv.swap (0 : Fin 3) 1) * (Equiv.swap (0 : Fin 3) 2)
         = (Equiv.swap (0 : Fin 3) 2) * (Equiv.swap (0 : Fin 3) 1) :=
    hcomm _ _
  -- Step 0.2: evaluate both sides at `0`.  The left-hand product sends `0 ↦ 2`,
  -- the right-hand product sends `0 ↦ 1`, so `simp` closes the goal by `2 ≠ 1`.
  have h0 := congrArg (fun f : Equiv.Perm (Fin 3) => f (0 : Fin 3)) h
  simp [Equiv.Perm.mul_apply, Equiv.swap_apply_def] at h0

/-! ## Refutation
The original statement `Dummit_Foote_exercise_1_1_29` is false: `Dummit_Foote_exercise_1_1_29_neg` proves the negation of its elaborated type. -/
theorem Dummit_Foote_exercise_1_1_29_neg : ¬ (type_of% @Dummit_Foote_exercise_1_1_29) := by
  intro h
  -- The formal statement puts `∀ x y : A × B` OUTSIDE the `↔`, so it claims that for
  -- *every single* pair `x, y` of `A × B`, that one pair commuting is equivalent to both
  -- `A` and `B` being abelian.  Taking `x = y = 1` makes the left-hand side trivially
  -- true, so the statement forces *every* pair of groups to be abelian.
  -- Step 1: instantiate at `A = B = ULift (Equiv.Perm (Fin 3))`, the symmetric group on
  -- three letters (the `ULift` is only there to place it in the required universes).
  have key := h (A := ULift.{u_1} (Equiv.Perm (Fin 3)))
                (B := ULift.{u_2} (Equiv.Perm (Fin 3))) 1 1
  -- Step 2: the left-hand side of the iff at `x = y = 1` is `1 * 1 = 1 * 1`, i.e. `rfl`,
  -- so the forward direction hands us commutativity of `ULift (Equiv.Perm (Fin 3))`.
  have hA : ∀ x y : ULift.{u_1} (Equiv.Perm (Fin 3)), x * y = y * x := (key.mp rfl).1
  -- Step 3: transport that commutativity down through `ULift` and contradict Step 0.
  apply perm3_not_comm_217
  intro x y
  have hxy := hA (ULift.up x) (ULift.up y)
  exact congrArg ULift.down hxy

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_1_1_29_corrected {A B : Type*} [Group A] [Group B] :
  (∀ x y : A × B, x * y = y * x) ↔ (∀ x y : A, x * y = y * x) ∧
  (∀ x y : B, x * y = y * x) := by
  -- Step 1: Split the biconditional into the two required directions.
  constructor
  · -- Step 1.1: Assume the direct product is abelian and deduce that each factor is abelian.
    intro hAB
    -- Step 1.1.1: Build the pair of goals showing A and B are abelian.
    constructor
    · -- Step 1.1.1.1: Fix arbitrary elements of A.
      intro a₁ a₂
      -- Step 1.1.1.2: Apply commutativity in the product to specially chosen elements.
      have hProj := congrArg Prod.fst (hAB ⟨a₁, (1 : B)⟩ ⟨a₂, 1⟩)
      -- Step 1.1.1.3: Simplify the first projection to obtain commutativity in A.
      simpa using hProj
    · -- Step 1.1.2.1: Fix arbitrary elements of B.
      intro b₁ b₂
      -- Step 1.1.2.2: Use product commutativity on elements supported in the B-coordinate.
      have hProj := congrArg Prod.snd (hAB ⟨(1 : A), b₁⟩ ⟨1, b₂⟩)
      -- Step 1.1.2.3: Simplify the second projection to obtain commutativity in B.
      simpa using hProj
  · -- Step 2: Assume each factor is abelian and prove the product is abelian.
    intro hFactors
    -- Step 2.1: Unpack the hypotheses that A and B are abelian.
    rcases hFactors with ⟨hA, hB⟩
    -- Step 2.2: Consider arbitrary elements of the direct product.
    intro x y
    -- Step 2.3: Break the product elements into their coordinates.
    rcases x with ⟨a₁, b₁⟩
    rcases y with ⟨a₂, b₂⟩
    -- Step 2.4: Reduce the equality in the product to equalities in each coordinate.
    ext
    · -- Step 2.4.1: The equality of first coordinates follows from hA.
      simpa using hA a₁ a₂
    · -- Step 2.4.2: The equality of second coordinates follows from hB.
      simpa using hB b₁ b₂
