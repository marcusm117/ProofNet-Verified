import Mathlib


open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators
noncomputable section

/-Informal Statement

Prove that every closed set in a separable metric space is the union of a (possibly empty) perfect set and a set which is at most countable.
-/

/-Informal Proof

If $E$ is closed, it contains all its limit points, and hence certainly all its condensation points. Thus $E=P \cup(E \backslash P)$, where $P$ is perfect (the set of all condensation points of $E$ ), and $E \backslash P$ is at most countable.

Since a perfect set in a separable metric space has the same cardinality as the real numbers, the set $P$ must be empty if $E$ is countable. The at-most countable set $E \backslash P$ cannot be perfect, hence must have isolated points if it is nonempty.
-/

theorem Rudin_exercise_2_28 (X : Type*) [MetricSpace X] [SeparableSpace X]
  (A : Set X) (hA : IsClosed A) :
  ∃ P₁ P₂ : Set X, A = P₁ ∪ P₂ ∧
  IsClosed P₁ ∧ P₁ = {x | ClusterPt x (𝓟 P₁)} ∧
  Set.Countable P₂ := by
  -- Step 1: A separable metric space is second countable (`UniformSpace.secondCountable_of_separable`),
  -- so we may invoke the Cantor–Bendixson theorem from Mathlib.
  -- It decomposes the closed set `A` as `A = V ∪ D` with `V` countable and `D` perfect.
  obtain ⟨V, D, hVcount, hDperf, hAVD⟩ := exists_countable_union_perfect_of_isClosed hA
  -- Step 2: Take `P₁ := D` (the perfect part) and `P₂ := V` (the at most countable part).
  refine ⟨D, V, ?_, hDperf.closed, ?_, hVcount⟩
  · -- Step 2.1: `A = D ∪ V` follows from `A = V ∪ D` by commutativity of union.
    rw [hAVD, Set.union_comm]
  · -- Step 2.2: The set of cluster points of `𝓟 D` is exactly `closure D`, and `D` is closed,
    -- so `D = {x | ClusterPt x (𝓟 D)}`.
    -- (Note the formal statement only asks for this "closure" condition rather than the
    -- stronger accumulation-point condition, but `D` is genuinely perfect: `hDperf.acc`.)
    rw [← closure_eq_cluster_pts, hDperf.closed.closure_eq]

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Topology Filter Real Complex TopologicalSpace Finset
open scoped BigOperators

theorem Rudin_exercise_2_28_corrected (X : Type*) [MetricSpace X] [SeparableSpace X]
  (A : Set X) (hA : IsClosed A) :
  ∃ P₁ P₂ : Set X, A = P₁ ∪ P₂ ∧ Perfect P₁ ∧ Set.Countable P₂ := by
  -- Step 1: Switch to classical logic so that we can freely use choice when manipulating
  --         countable sets and perfect subsets.
  classical
  -- Step 2: Apply the Cantor–Bendixson theorem for closed sets inside second countable spaces.
  -- Step 2.1: Our separable metric hypotheses ensure `X` is second countable, so the theorem
  --           `exists_countable_union_perfect_of_isClosed` is available.
  obtain ⟨P₂, P₁, hP₂count, hP₁perf, hdecomp⟩ :=
    exists_countable_union_perfect_of_isClosed (α := X) (C := A) hA
  -- Step 3: Repackage the decomposition so that the perfect component is listed first.
  refine ⟨P₁, P₂, ?_, hP₁perf, hP₂count⟩
  -- Step 3.1: Use the commutativity of union to match the order requested in the statement.
  simpa [Set.union_comm] using hdecomp
