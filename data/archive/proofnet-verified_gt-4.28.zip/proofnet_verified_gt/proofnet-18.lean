import Mathlib


open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators InnerProductSpace

/-Informal Statement

Suppose $p \in \mathcal{P}(\mathbf{C})$ has degree $m$. Prove that $p$ has $m$ distinct roots if and only if $p$ and its derivative $p^{\prime}$ have no roots in common.
-/

/-Informal Proof

First, let $p$ have $m$ distinct roots. Since $p$ has the degree of $m$, then this could imply that $p$ can be actually written in the form of $p(z)=c\left(z-\lambda_1\right) \ldots\left(z-\lambda_m\right)$, which you have $\lambda_1, \ldots, \lambda_m$ being distinct.
To prove that both $p$ and $p^{\prime}$ have no roots in commons, we must now show that $p^{\prime}\left(\lambda_j\right) \neq 0$ for every $j$. So, to do so, just fix $j$. The previous expression for $p$ shows that we can now write $p$ in the form of $p(z)=\left(z-\lambda_j\right) q(z)$, which $q$ is a polynomial such that $q\left(\lambda_j\right) \neq 0$.

When you differentiate both sides of the previous equation, then you would then have $p^{\prime}(z)=(z-$ $\left.\lambda_j\right) q^{\prime}(z)+q(z)$

Therefore: $\left.=p^{\prime}\left(\lambda_j\right)=q \lambda_j\right)$
Equals: $p^{\prime}\left(\lambda_j\right) \neq 0$

Now, to prove the other direction, we would now prove the contrapositive, which means that we will be proving that if $p$ has actually less than $m$ distinct roots, then both $p$ and $p^{\prime}$ have at least one root in common.

Now, for some root of $\lambda$ of $p$, we can write $p$ is in the form of $\left.p(z)=(z-\lambda)^n q(z)\right)$, which is where both $n \geq 2$ and $q$ is a polynomial. When differentiating both sides of the previous equations, we would then have $p^{\prime}(z)=(z-\lambda)^n q^{\prime}(z)+n(z-\lambda)^{n-1} q(z)$.
Therefore, $p^{\prime}(\lambda)=0$, which would make $\lambda$ is a common root of both $p$ and $p^{\prime}$.
-/

theorem Axler_exercise_4_4 (p : Polynomial ℂ) :
  p.degree = @card (rootSet p ℂ) (rootSetFintype p ℂ) ↔
  Disjoint
  (@card (rootSet (derivative p) ℂ) (rootSetFintype (derivative p) ℂ))
  (@card (rootSet p ℂ) (rootSetFintype p ℂ)) := by
  sorry

/-! ## Refutation
The original statement `Axler_exercise_4_4` is false: `Axler_exercise_4_4_neg` proves the negation of its elaborated type. -/

/-! ## Counterexample: `p = X ^ 2 - 1` over `ℂ`

The formalization applies `Disjoint` to two *natural numbers* (the cardinalities of the
root sets), not to the two root sets themselves.  In the lattice structure on `ℕ`
(`⊥ = 0`, `⊓ = min`), `Disjoint a b` says `min a b = 0`, i.e. "`p'` has no root or `p` has
no root" — nothing at all like "`p` and `p'` have no root in common".

For `p = X ^ 2 - 1` the left-hand side holds (`degree p = 2` and `p` has exactly the two
distinct roots `1, -1`), while the right-hand side fails: `p' = 2X` has the root `0`, so
both cardinalities are nonzero and `min 1 2 = 1 ≠ 0`. -/

/-- Step 1: `X ^ 2 - 1` is separable over `ℂ`, since `(2 : ℂ) ≠ 0`. -/
theorem refute_18_sep : (X ^ 2 - 1 : Polynomial ℂ).Separable :=
  X_pow_sub_one_separable_iff.mpr (by norm_num)

/-- Step 2: therefore the root set of `X ^ 2 - 1` in `ℂ` has exactly `natDegree = 2`
elements (`ℂ` is algebraically closed, so the polynomial splits). -/
theorem refute_18_card :
    @card (rootSet (X ^ 2 - 1 : Polynomial ℂ) ℂ) (rootSetFintype _ ℂ) = 2 := by
  -- Step 2.1: for a separable, split polynomial the root set has `natDegree` elements.
  have h := card_rootSet_eq_natDegree (K := ℂ) refute_18_sep (IsAlgClosed.splits _)
  -- Step 2.2: and `natDegree (X ^ 2 - 1) = 2`.
  have hnd : (X ^ 2 - 1 : Polynomial ℂ).natDegree = 2 := by
    compute_degree!
  rw [h, hnd]

/-- Step 3: the derivative of `X ^ 2 - 1` is `C 2 * X`. -/
theorem refute_18_deriv :
    derivative (X ^ 2 - 1 : Polynomial ℂ) = C 2 * X := by
  rw [derivative_sub, derivative_one, derivative_X_pow]
  norm_num

/-- Step 4: hence `0` is a root of the derivative, so its root set is nonempty. -/
theorem refute_18_card_deriv_pos :
    0 < @card (rootSet (derivative (X ^ 2 - 1 : Polynomial ℂ)) ℂ)
        (rootSetFintype _ ℂ) := by
  -- Step 4.1: `C 2 * X ≠ 0` in the domain `ℂ[X]`.
  have hne : derivative (X ^ 2 - 1 : Polynomial ℂ) ≠ 0 := by
    rw [refute_18_deriv]
    exact mul_ne_zero (by simp) X_ne_zero
  -- Step 4.2: `aeval 0 (C 2 * X) = 2 * 0 = 0`.
  have hmem : (0 : ℂ) ∈ rootSet (derivative (X ^ 2 - 1 : Polynomial ℂ)) ℂ := by
    rw [mem_rootSet_of_ne hne, refute_18_deriv]
    simp
  -- Step 4.3: a nonempty finite type has positive cardinality.
  exact Fintype.card_pos_iff.mpr ⟨⟨0, hmem⟩⟩

theorem Axler_exercise_4_4_neg : ¬ (type_of% @Axler_exercise_4_4) := by
  -- Step 5: assume the statement and instantiate it at `p = X ^ 2 - 1`.
  intro h
  have hiff := h (X ^ 2 - 1)
  -- Step 6: the left-hand side holds: `degree (X ^ 2 - 1) = 2 = card (rootSet _)`.
  have hL : (X ^ 2 - 1 : Polynomial ℂ).degree
      = (@card (rootSet (X ^ 2 - 1 : Polynomial ℂ) ℂ) (rootSetFintype _ ℂ) : WithBot ℕ) := by
    rw [refute_18_card]
    compute_degree!
  -- Step 7: so the right-hand side must hold: `Disjoint (card p'-roots) (card p-roots)`.
  have hR := hiff.mp hL
  -- Step 8: but `Disjoint` on `ℕ` means `min = ⊥ = 0`; testing it at `x = 1` gives `1 ≤ 0`.
  have h1 : (1 : ℕ) ≤ @card (rootSet (derivative (X ^ 2 - 1 : Polynomial ℂ)) ℂ)
      (rootSetFintype _ ℂ) := refute_18_card_deriv_pos
  have h2 : (1 : ℕ) ≤ @card (rootSet (X ^ 2 - 1 : Polynomial ℂ) ℂ) (rootSetFintype _ ℂ) := by
    rw [refute_18_card]; norm_num
  have hbot := hR h1 h2
  simp at hbot


/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Complex Polynomial LinearMap FiniteDimensional Module Module.End
open scoped BigOperators

private lemma degree_eq_card_rootSet_iff_separable
    (p : Polynomial ℂ) (hp : p ≠ 0) :
    p.degree =
        @card (p.rootSet ℂ) (rootSetFintype p ℂ) ↔
      p.Separable := by
  classical
  -- Step 1: Record that every complex polynomial splits over ℂ.
  have hsplit :
      (p.map (algebraMap ℂ ℂ)).Splits :=
    IsAlgClosed.splits_domain p
  constructor
  · -- Step 2: Assume the degree equals the cardinality and deduce separability.
    intro hdeg
    -- Step 2.1: Move to natural degrees using `degree_eq_natDegree`.
    have h_withTop :
        (p.natDegree : WithTop ℕ) =
          (@card (p.rootSet ℂ) (rootSetFintype p ℂ) : WithTop ℕ) := by
      simpa [Polynomial.degree_eq_natDegree hp] using hdeg
    -- Step 2.2: Extract the plain natural-number equality.
    have h_nat :
        Fintype.card (p.rootSet ℂ) = p.natDegree :=
      (WithTop.coe_eq_coe.mp h_withTop).symm
    -- Step 2.3: Apply the standard cardinality-versus-separability equivalence.
    exact
      (Polynomial.card_rootSet_eq_natDegree_iff_of_splits
          (F := ℂ) (K := ℂ) (f := p) hp hsplit).mp h_nat
  · -- Step 3: Show that separability forces the cardinality/degree equality.
    intro hsep
    -- Step 3.1: Use the same lemma in the forward direction.
    have h_nat :
        Fintype.card (p.rootSet ℂ) = p.natDegree :=
      (Polynomial.card_rootSet_eq_natDegree_iff_of_splits
          (F := ℂ) (K := ℂ) (f := p) hp hsplit).mpr hsep
    -- Step 3.2: Lift the natural-number equality back to `WithTop`.
    have h_withTop :
        (@card (p.rootSet ℂ) (rootSetFintype p ℂ) : WithTop ℕ) =
          (p.natDegree : WithTop ℕ) :=
      by simpa using congrArg (fun n : ℕ => (n : WithTop ℕ)) h_nat
    -- Step 3.3: Translate `natDegree` into `degree`.
    simp [Polynomial.degree_eq_natDegree hp, h_withTop]

private lemma separable_iff_root_sets_disjoint
    (p : Polynomial ℂ) (hp : p ≠ 0) :
    p.Separable ↔
      Disjoint (p.rootSet ℂ) ((Polynomial.derivative p).rootSet ℂ) := by
  classical
  constructor
  · -- Step 1: Prove that separability forbids common roots.
    intro hsep
    -- Step 1.1: Use the characterization of disjointness via membership.
    refine Set.disjoint_left.2 ?_
    intro z hz hz'
    -- Step 1.2: Convert set membership to the statement that `z` is a root.
    have hz_root :
        p.IsRoot z :=
      by
        -- Step 1.2.1: Evaluate the polynomial at the root via `mem_rootSet_of_ne`.
        have hz_eval :=
          (Polynomial.mem_rootSet_of_ne (S := ℂ) (p := p) hp).1 hz
        simpa [Polynomial.IsRoot, Polynomial.aeval_def] using hz_eval
    have hz'_root :
        (Polynomial.derivative p).IsRoot z :=
      by
        -- Step 1.2.2: Establish that the derivative is nonzero at the root.
        have hderiv_ne :
            Polynomial.derivative p ≠ 0 :=
          by
            -- If the derivative vanished, its root set would be empty.
            intro hzero
            have : z ∈ (Polynomial.derivative p).rootSet ℂ := hz'
            simp [hzero, Polynomial.rootSet_zero] at this
        -- Step 1.2.3: Evaluate the derivative at the root.
        have hz_eval :=
          (Polynomial.mem_rootSet_of_ne
              (S := ℂ) (p := Polynomial.derivative p) hderiv_ne).1 hz'
        simpa [Polynomial.IsRoot, Polynomial.aeval_def] using hz_eval
    -- Step 1.3: Translate the simultaneous roots into multiplicity information.
    have hmult :
        1 < p.rootMultiplicity z :=
      (Polynomial.one_lt_rootMultiplicity_iff_isRoot (p := p) (t := z) hp).2
        ⟨hz_root, hz'_root⟩
    -- Step 1.4: Separability forces every root multiplicity to be ≤ 1, contradiction.
    have h_le_one :=
      Polynomial.rootMultiplicity_le_one_of_separable hsep z
    have hcontr := lt_of_lt_of_le hmult h_le_one
    exact (lt_irrefl (1 : ℕ)) hcontr
  · -- Step 2: Show that disjoint root sets imply separability.
    intro hdis
    -- Step 2.1: Prove the contrapositive by assuming `p` is not separable.
    by_contra hsep
    have hnotcoprime :
        ¬ IsCoprime p (Polynomial.derivative p) := by
      -- Step 2.1.1: Unfold the definition of separability.
      simpa [Polynomial.Separable] using hsep
    -- Step 2.2: Define the gcd of `p` and its derivative.
    set g : Polynomial ℂ := EuclideanDomain.gcd p (Polynomial.derivative p)
    -- Step 2.3: Record that the gcd is not a unit (else the polynomials are coprime).
    have hg_not_unit :
        ¬IsUnit g :=
      by
        have : IsUnit g ↔ IsCoprime p (Polynomial.derivative p) :=
          by
            simpa [g] using
              (EuclideanDomain.gcd_isUnit_iff
                (α := Polynomial ℂ) (x := p)
                (y := Polynomial.derivative p))
        exact (not_congr this).mpr hnotcoprime
    -- Step 2.4: Show that the gcd is nonzero, since it divides the nonzero polynomial `p`.
    have hg_ne_zero : g ≠ 0 := by
      intro hg
      have hg_dvd :
          g ∣ p :=
        EuclideanDomain.gcd_dvd_left p (Polynomial.derivative p)
      obtain ⟨q, hq⟩ := hg_dvd
      have : p = 0 := by simpa [g, hg] using hq
      exact hp this
    -- Step 2.5: A non-unit polynomial in `ℂ[X]` must have positive degree.
    have hg_deg_ne_zero :
        g.degree ≠ 0 :=
      by
        intro hdeg
        have : IsUnit g :=
          (Polynomial.isUnit_iff_degree_eq_zero).2 hdeg
        exact hg_not_unit this
    -- Step 2.6: Because ℂ is algebraically closed, the gcd has a complex root.
    obtain ⟨z, hz⟩ :=
      IsAlgClosed.exists_root (p := g) hg_deg_ne_zero
    -- Step 2.7: Convert this root of the gcd into roots of `p` and its derivative.
    have hz_root : p.IsRoot z := by
      -- `g` divides `p`, so any root of `g` is a root of `p`.
      exact hz.dvd (EuclideanDomain.gcd_dvd_left p (Polynomial.derivative p))
    have hz_deriv_root : (Polynomial.derivative p).IsRoot z := by
      -- `g` also divides the derivative, giving the second root condition.
      exact hz.dvd (EuclideanDomain.gcd_dvd_right p (Polynomial.derivative p))
    -- Step 2.8: Deduce that the root has multiplicity strictly greater than `1`.
    have hmult :
        1 < p.rootMultiplicity z :=
      (Polynomial.one_lt_rootMultiplicity_iff_isRoot
          (p := p) (t := z) hp).2 ⟨hz_root, hz_deriv_root⟩
    -- Step 2.9: Upgrade the `IsRoot` statements to membership in the respective root sets.
    have hz_eval : Polynomial.eval z p = 0 := hz_root.eq_zero
    have hz_mem :
        z ∈ p.rootSet ℂ :=
      (Polynomial.mem_rootSet_of_ne (S := ℂ) (p := p) hp).2
        (by
          -- Convert evaluation into the `aeval` formulation (which coincides with evaluation).
          simpa using hz_eval)
    have hz_deriv_eval :
        Polynomial.eval z (Polynomial.derivative p) = 0 :=
      hz_deriv_root.eq_zero
    have hderiv_ne :
        Polynomial.derivative p ≠ 0 :=
      by
        intro hzero
        have hp_const :
            p = Polynomial.C (Polynomial.coeff p 0) :=
          Polynomial.eq_C_of_derivative_eq_zero hzero
        have hcoeff_zero :
            Polynomial.coeff p 0 = 0 := by
          -- Evaluate the constant polynomial at the repeated root.
          have hz_const := hz_eval
          -- Rewrite the evaluation of the constant polynomial explicitly.
          rw [hp_const, Polynomial.eval_C] at hz_const
          simpa using hz_const
        have hp_zero : p = 0 := by
          -- Replace the constant polynomial with the zero polynomial.
          have hp_C0 : p = Polynomial.C 0 := by
            simpa [hcoeff_zero] using hp_const
          simpa [Polynomial.C_0] using hp_C0
        exact hp hp_zero
    have hz_mem_deriv :
        z ∈ (Polynomial.derivative p).rootSet ℂ :=
      (Polynomial.mem_rootSet_of_ne (S := ℂ)
          (p := Polynomial.derivative p) hderiv_ne).2
        (by
          -- Convert the evaluation of the derivative to the `aeval` format.
          simpa using hz_deriv_eval)
    -- Step 2.10: The disjointness hypothesis forbids such a common root.
    exact
      (Set.disjoint_left.mp hdis hz_mem hz_mem_deriv)

theorem Axler_exercise_4_4_corrected (p : Polynomial ℂ) (m : ℕ) (hp : p ≠ 0) (hm : m = p.degree) :
    @card (p.rootSet ℂ) (rootSetFintype p ℂ) = m ↔
    Disjoint (p.rootSet ℂ) ((Polynomial.derivative p).rootSet ℂ) := by
  -- Step 0: Switch to classical logic so that all cardinality lemmas are directly available.
  classical
  -- Step 1: Combine the standard Mathlib equivalences that translate the equality of degrees
  --         into separability and finally into disjoint root sets.
  have h :=
    (degree_eq_card_rootSet_iff_separable p hp).trans
      (separable_iff_root_sets_disjoint p hp)
  -- Step 2: Prove the forward direction of the equivalence.
  constructor
  · intro hcard
    -- Step 2.1: Lift the natural-number equality to `WithTop ℕ`, matching the codomain of `degree`.
    have hcard_coe :
        ((@card (p.rootSet ℂ) (rootSetFintype p ℂ) : ℕ) : WithTop ℕ) = m :=
      congrArg (fun n : ℕ => (n : WithTop ℕ)) hcard
    -- Step 2.2: Use `hm` to rewrite the degree equality so it matches the shape expected by `h`.
    have hdeg :
        p.degree =
          ((@card (p.rootSet ℂ) (rootSetFintype p ℂ) : ℕ) : WithTop ℕ) := by
      simpa [hcard_coe] using hm.symm
    -- Step 2.3: Apply the composed equivalence to obtain the disjointness statement.
    exact h.mp hdeg
  · intro hdis
    -- Step 3: Prove the reverse direction of the equivalence.
    -- Step 3.1: Push the disjointness hypothesis through the equivalence `h` to recover the
    --           degree/cardinality equality in `WithTop ℕ`.
    have hdeg :
        p.degree =
          ((@card (p.rootSet ℂ) (rootSetFintype p ℂ) : ℕ) : WithTop ℕ) :=
      h.mpr hdis
    -- Step 3.2: Combine the result with `hm` to compare the coerced natural numbers.
    have hcoe :
        (m : WithTop ℕ) =
          ((@card (p.rootSet ℂ) (rootSetFintype p ℂ) : ℕ) : WithTop ℕ) :=
      hm.trans hdeg
    -- Step 3.3: Remove the coercions, giving the pure natural-number equality.
    have hm_nat :
        m = @card (p.rootSet ℂ) (rootSetFintype p ℂ) :=
      WithTop.coe_eq_coe.mp hcoe
    -- Step 3.4: Reorient the equality to match the statement of the theorem.
    exact hm_nat.symm
