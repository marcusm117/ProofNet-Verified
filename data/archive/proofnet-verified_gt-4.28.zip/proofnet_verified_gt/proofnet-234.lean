import Mathlib


open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators
noncomputable section

/-Informal Statement

Let $G$ be a group with subgroups $H$ and $K$ with $H \leq K$. Prove that if $H$ is characteristic in $K$ and $K$ is normal in $G$ then $H$ is normal in $G$.
-/

/-Informal Proof

We prove that $H$ is invariant under every inner automorphism of $G$. Consider a inner automorphism $\phi_g$ of $G$. Now, $\left.\phi_g\right|_K$ is a automorphism of $K$ because $K$ is normal in $G$. But $H$ is a characteristic subgroup of $K$, so $\left.\phi_g\right|_K(H) \subset H$, so in general $\phi_g(H) \subset H$. Hence $H$ is characteristic in $G$.
-/

theorem Dummit_Foote_exercise_4_4_8a {G : Type*} [Group G] (H K : Subgroup G)
  (hHK : H ≤ K) [hHK1 : (H.subgroupOf K).Normal] [hK : K.Normal] :
  H.Normal := by
  sorry

/-!
## Refutation

The formalization replaces the hypothesis "`H` is *characteristic* in `K`" by the strictly
weaker "`H` is *normal* in `K`" (`[(H.subgroupOf K).Normal]`).  What is stated is therefore
"normal in normal implies normal", which is a classical non-theorem.

The standard counterexample is the dihedral group of order 8:

* `G = DihedralGroup 4`  (elements `r i`, `sr i` for `i : ZMod 4`),
* `K = {r 0, r 2, sr 0, sr 2}`, a Klein four subgroup.  It has index 2, hence is normal
  in `G`, and it is abelian, so *every* subgroup of it is normal in it,
* `H = {r 0, sr 0}`, an order-two subgroup of `K`.

All hypotheses hold, yet `H` is not normal in `G`:
`(r 1) * (sr 0) * (r 1)⁻¹ = sr 2 ∉ H`.

The negated statement lives in an arbitrary universe `u_1`, so the concrete group
`DihedralGroup 4 : Type` is transported to `ULift (DihedralGroup 4) : Type u_1` by
`transport234` below, which only needs a multiplicative equivalence onto `DihedralGroup 4`.
-/

/-- **Step 1.** The Klein four subgroup `K = {r 0, r 2, sr 0, sr 2}` of `D₄`.
Closure under multiplication/inverse is a finite check, discharged by `decide`. -/
def K234 : Subgroup (DihedralGroup 4) where
  carrier := {x | x = DihedralGroup.r 0 ∨ x = DihedralGroup.r 2 ∨
                  x = DihedralGroup.sr 0 ∨ x = DihedralGroup.sr 2}
  mul_mem' := by intro a b ha hb; revert ha hb; revert a b; decide
  one_mem' := by decide
  inv_mem' := by intro a ha; revert ha; revert a; decide

/-- **Step 2.** The order-two subgroup `H = {r 0, sr 0}` of `D₄` (a reflection together
with the identity). -/
def H234 : Subgroup (DihedralGroup 4) where
  carrier := {x | x = DihedralGroup.r 0 ∨ x = DihedralGroup.sr 0}
  mul_mem' := by intro a b ha hb; revert ha hb; revert a b; decide
  one_mem' := by decide
  inv_mem' := by intro a ha; revert ha; revert a; decide

/-- **Step 2.1.** Unfolding lemma for membership in `K234` (true by `rfl`). -/
theorem memK234 (x : DihedralGroup 4) :
    x ∈ K234 ↔ (x = DihedralGroup.r 0 ∨ x = DihedralGroup.r 2 ∨
                x = DihedralGroup.sr 0 ∨ x = DihedralGroup.sr 2) := Iff.rfl

/-- **Step 2.2.** Unfolding lemma for membership in `H234` (true by `rfl`). -/
theorem memH234 (x : DihedralGroup 4) :
    x ∈ H234 ↔ (x = DihedralGroup.r 0 ∨ x = DihedralGroup.sr 0) := Iff.rfl

/-- **Step 3.** `H ≤ K`: the first hypothesis of the exercise. -/
theorem hle234 : H234 ≤ K234 := by
  intro x hx; rw [memH234] at hx; rw [memK234]; revert hx; revert x; decide

/-- **Step 4.** `H` is normal *in* `K`: conjugating an element of `H` by an element of `K`
stays in `H`.  (Indeed `K` is abelian, so this conjugation is trivial.)  Stated in unfolded
form so that it can be reused after transporting along a group isomorphism. -/
theorem key234 : ∀ x y : DihedralGroup 4,
    (x = DihedralGroup.r 0 ∨ x = DihedralGroup.r 2 ∨
     x = DihedralGroup.sr 0 ∨ x = DihedralGroup.sr 2) →
    (y = DihedralGroup.r 0 ∨ y = DihedralGroup.sr 0) →
    (x * y * x⁻¹ = DihedralGroup.r 0 ∨ x * y * x⁻¹ = DihedralGroup.sr 0) := by decide

/-- **Step 5.** `K` is normal in `G = D₄` (it has index two); again a finite check. -/
theorem normK234 : K234.Normal := by
  constructor
  intro n hn g
  rw [memK234] at hn ⊢
  revert hn; revert n; revert g; decide

/-- **Step 6.** `H` is *not* normal in `G`: `(r 1) * (sr 0) * (r 1)⁻¹ = sr 2 ∉ H`. -/
theorem notNormH234 : ¬ H234.Normal := by
  intro hcon
  -- Step 6.1: conjugate `sr 0 ∈ H` by the rotation `r 1`.
  have h2 := hcon.conj_mem (DihedralGroup.sr 0) (by rw [memH234]; decide) (DihedralGroup.r 1)
  -- Step 6.2: the result would have to be `r 0` or `sr 0`; it is `sr 2`.
  rw [memH234] at h2
  revert h2
  decide

/-- **Step 7.** Transport of the counterexample to an arbitrary universe.

Given *any* group `G` isomorphic to `D₄` and the statement of the exercise for that `G`,
we derive `False`.  We feed the statement the pullbacks `H234.comap f` and `K234.comap f`
along the isomorphism `f = e : G ≃* D₄`; all three hypotheses transfer, and the conclusion
`(H234.comap f).Normal` pushes back to the false `H234.Normal`. -/
theorem transport234 {G : Type*} [Group G] (e : G ≃* DihedralGroup 4)
    (hstmt : ∀ (H K : Subgroup G), H ≤ K →
      ∀ [hHK1 : (H.subgroupOf K).Normal] [hK : K.Normal], H.Normal) : False := by
  -- Step 7.1: name the isomorphism as a monoid hom, and pull `H`, `K` back along it.
  set f : G →* DihedralGroup 4 := e.toMonoidHom with hf
  -- Step 7.2: `H ≤ K` is preserved by `comap`.
  have hle : H234.comap f ≤ K234.comap f := Subgroup.comap_mono hle234
  -- Step 7.3: normality of `K` is preserved by `comap`.
  have hKn : (K234.comap f).Normal := normK234.comap f
  -- Step 7.4: `H.comap f` is normal in `K.comap f`, by Step 4 applied to the images.
  have hHKn : ((H234.comap f).subgroupOf (K234.comap f)).Normal := by
    constructor
    intro n hn g
    -- membership in `subgroupOf` unfolds to membership of the coercion in `H234.comap f`,
    -- i.e. to membership of the `f`-image in `H234`.
    rw [Subgroup.mem_subgroupOf, Subgroup.mem_comap] at hn ⊢
    have hg : f (g : G) ∈ K234 := g.2
    -- `f` is a homomorphism, so it turns the conjugate into a conjugate.
    simp only [Subgroup.coe_mul, Subgroup.coe_inv, map_mul, map_inv]
    exact (memH234 _).2 (key234 _ _ ((memK234 _).1 hg) ((memH234 _).1 hn))
  -- Step 7.5: the (false) statement now yields normality of `H234.comap f` in `G`.
  have hHn : (H234.comap f).Normal := hstmt _ _ hle (hHK1 := hHKn) (hK := hKn)
  -- Step 7.6: push it back along `e.symm` to contradict Step 6.
  refine notNormH234 ⟨?_⟩
  intro n hn g
  have h2 := hHn.conj_mem (e.symm n) (by simpa [hf] using hn) (e.symm g)
  rw [Subgroup.mem_comap] at h2
  simpa [hf] using h2

/-! ## Refutation
The original statement `Dummit_Foote_exercise_4_4_8a` is false: `Dummit_Foote_exercise_4_4_8a_neg` proves the negation of its elaborated type. -/
theorem Dummit_Foote_exercise_4_4_8a_neg : ¬ (type_of% @Dummit_Foote_exercise_4_4_8a) := by
  -- Step 8: assume the statement, instantiated at the universe-lifted dihedral group
  -- `ULift (DihedralGroup 4)`, which is isomorphic to `DihedralGroup 4` via `MulEquiv.ulift`.
  intro h
  refine transport234 (G := ULift (DihedralGroup 4)) MulEquiv.ulift ?_
  -- Step 8.1: discharge the hypothesis of `transport234` by the assumed statement,
  -- turning the instance-implicit binders into explicit ones.
  intro H K hHK _ _
  exact h H K hHK

end

/-! ## Corrected statement (as released in ProofNet-Verified) -/
open Fintype Subgroup Set Polynomial Ideal
open scoped BigOperators

theorem Dummit_Foote_exercise_4_4_8a_corrected {G : Type*} [Group G] (H K : Subgroup G)
  (hHK : H ≤ K) [hHK1 : (H.subgroupOf K).Characteristic] [hK : K.Normal] :
  H.Normal := by
  -- Step 1: Work in the classical logic setting so that `simp` can unfold subtype equalities.
  classical
  -- Step 2: View `H` inside `K`, use characteristic + normality to conclude that its image in `G` is normal.
  -- Step 2.1: The general instance `normal_of_characteristic_of_normal` supplies this normality automatically.
  have hImageNormal : ((H.subgroupOf K).map K.subtype).Normal := inferInstance
  -- Step 3: Invoke the canonical lemma `map_subgroupOf_eq_of_le` to identify this image with `H`.
  -- Step 3.1: This lemma rewrites the map along the inclusion `H ≤ K` straight back to `H`.
  have hImage_eq_H : ((H.subgroupOf K).map K.subtype) = H :=
    (Subgroup.map_subgroupOf_eq_of_le hHK)
  -- Step 4: Rewrite the normality from Step 2 along the equality from Step 3 to obtain `H.Normal` directly.
  simpa [hImage_eq_H] using hImageNormal
